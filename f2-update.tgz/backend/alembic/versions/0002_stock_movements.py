"""Fase 2: lotti, ingressi, movimenti immutabili, operazioni idempotenti, pulizie, allegati.

NB: nessun carattere percento nelle istruzioni SQL (driver psycopg, nessun parametro).

Revision ID: 0002
Revises: 0001
"""

from alembic import op

from app.models import Base

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

APP_ROLE = "feedtrace_app"

F2_TABLES = {
    "lot", "goods_receipt", "movement", "operation", "lot_counter", "cleaning", "attachment",
}


def upgrade() -> None:
    bind = op.get_bind()

    def run(sql: str) -> None:
        bind.exec_driver_sql(sql)

    f2 = [t for t in Base.metadata.sorted_tables if t.name in F2_TABLES]
    Base.metadata.create_all(bind=bind, tables=f2)

    for table in f2:
        run(f"ALTER TABLE {table.name} ENABLE ROW LEVEL SECURITY")
        run(f"ALTER TABLE {table.name} FORCE ROW LEVEL SECURITY")
        run(
            f"CREATE POLICY tenant_isolation ON {table.name} "
            "USING (tenant_id = app_current_tenant()) "
            "WITH CHECK (tenant_id = app_current_tenant())"
        )
        run(f"GRANT SELECT, INSERT, UPDATE ON {table.name} TO {APP_ROLE}")

    # Movimenti immutabili (RF-14): nessun UPDATE/DELETE, nemmeno per il proprietario.
    run(f"REVOKE UPDATE ON movement FROM {APP_ROLE}")
    run(f"REVOKE UPDATE ON operation FROM {APP_ROLE}")
    run(
        "CREATE TRIGGER movement_immutable BEFORE UPDATE OR DELETE ON movement "
        "FOR EACH ROW EXECUTE FUNCTION prevent_mutation()"
    )


def downgrade() -> None:
    raise NotImplementedError("Downgrade non supportato")
