"""Inventario/rettifica e svuotamento (RF-03). Decisioni: ADR D4, D7."""

from collections.abc import Hashable, Sequence
from dataclasses import dataclass
from decimal import Decimal

from domain.consumption import ZERO, LotStock, consume
from domain.enums import ConsumptionPolicy


@dataclass(frozen=True)
class InventoryPlan:
    # (lotto, quantità con segno). `None` = lotto NON ALLOCATO del contenitore.
    lines: tuple[tuple[Hashable | None, Decimal], ...]
    closes_epoch: bool
    difference: Decimal


def plan_inventory_adjustment(
    policy: ConsumptionPolicy, stocks: Sequence[LotStock], measured: Decimal
) -> InventoryPlan:
    """Differenza tra giacenza misurata e teorica.

    - misurata = 0: azzera ogni lotto (anche i negativi) e chiude la catena POSSIBILE;
    - in meno: ripartita secondo la politica del contenitore (eccedenza su NON ALLOCATO);
    - in più: attribuita al lotto NON ALLOCATO (origine ignota).
    """
    if measured < 0:
        raise ValueError("La giacenza misurata non può essere negativa")
    theoretical = sum((s.quantity for s in stocks), ZERO)
    difference = measured - theoretical

    if measured == 0:
        lines = tuple((s.lot_id, -s.quantity) for s in stocks if s.quantity != 0)
        return InventoryPlan(lines, True, difference)
    if difference == 0:
        return InventoryPlan((), False, difference)
    if difference > 0:
        return InventoryPlan(((None, difference),), False, difference)

    result = consume(policy, stocks, -difference)
    lines_list: list[tuple[Hashable | None, Decimal]] = [
        (a.lot_id, -a.quantity) for a in result.allocations
    ]
    if result.shortfall > 0:
        lines_list.append((None, -result.shortfall))
    return InventoryPlan(tuple(lines_list), False, difference)


def plan_emptying(stocks: Sequence[LotStock]) -> list[tuple[Hashable, Decimal]]:
    """Svuotamento: ogni residuo (positivo o negativo) viene riportato a zero."""
    return [(s.lot_id, -s.quantity) for s in stocks if s.quantity != 0]
