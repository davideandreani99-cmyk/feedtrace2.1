"""Conversioni di unità: kg nel DB, conversioni solo ai bordi (CLAUDE.md)."""

from decimal import ROUND_HALF_UP, Decimal
from enum import StrEnum


class InputUnit(StrEnum):
    KG = "kg"
    T = "t"
    L = "l"


def convert_to_kg(
    quantity: Decimal, unit: InputUnit, density_kg_l: Decimal | None
) -> Decimal:
    if quantity <= 0:
        raise ValueError("La quantità deve essere positiva")
    if unit == InputUnit.KG:
        kg = quantity
    elif unit == InputUnit.T:
        kg = quantity * 1000
    elif unit == InputUnit.L:
        if density_kg_l is None or density_kg_l <= 0:
            raise ValueError("Densità (kg/l) necessaria per convertire i litri")
        kg = quantity * density_kg_l
    else:
        raise ValueError(f"Unità non supportata: {unit}")
    return kg.quantize(Decimal("0.001"), rounding=ROUND_HALF_UP)
