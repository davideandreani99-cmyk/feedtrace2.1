"""Politiche di consumo dei contenitori (RF-03, SPEC §6.3 e §7).

Funzioni pure: ricevono la giacenza per lotto e la quantità da prelevare, restituiscono
da quali lotti esce il materiale. Decisioni: ADR D3-D5, D7.
"""

from collections.abc import Hashable, Sequence
from dataclasses import dataclass
from decimal import ROUND_DOWN, Decimal, localcontext

from domain.enums import ConsumptionPolicy

QUANTUM = Decimal("0.001")  # kg con 3 decimali
ZERO = Decimal("0")


@dataclass(frozen=True)
class LotStock:
    """Giacenza di un lotto in un contenitore.

    `entry_order`: ordine di carico nel contenitore (FIFO, D3).
    `entered_since_epoch`: kg complessivamente entrati dall'ultimo svuotamento (D4).
    """

    lot_id: Hashable
    quantity: Decimal
    entry_order: int
    entered_since_epoch: Decimal = ZERO


@dataclass(frozen=True)
class Allocation:
    lot_id: Hashable
    quantity: Decimal


@dataclass(frozen=True)
class ConsumptionResult:
    allocations: tuple[Allocation, ...]  # consumo effettivo per lotto (legami CERTI)
    possible_links: tuple[Allocation, ...]  # legami POSSIBILI (solo TUTTI_PRESENTI)
    shortfall: Decimal  # quantità non coperta dai lotti (va sul lotto NON ALLOCATO, D7)


def quantize(value: Decimal) -> Decimal:
    return value.quantize(QUANTUM, rounding=ROUND_DOWN)


def split_proportionally(
    total: Decimal,
    weights: Sequence[tuple[Hashable, Decimal]],
    caps: dict[Hashable, Decimal] | None = None,
) -> list[Allocation]:
    """Ripartisce `total` in proporzione ai pesi, a 3 decimali.

    Il resto dell'arrotondamento va al lotto con la quota maggiore (D5); a parità, al
    primo in elenco. Con `caps` nessun lotto supera il proprio massimo (il resto passa
    al successivo per quota).
    """
    total_weight = sum((w for _, w in weights), ZERO)
    if total <= 0 or total_weight <= 0:
        return []
    with localcontext() as context:
        context.prec = 60
        shares = {key: quantize(total * weight / total_weight) for key, weight in weights}
    remainder = total - sum(shares.values(), ZERO)
    ranking = sorted(range(len(weights)), key=lambda i: (-weights[i][1], i))
    for index in ranking:
        if remainder <= 0:
            break
        key = weights[index][0]
        room = remainder if caps is None else caps[key] - shares[key]
        extra = min(room, remainder)
        if extra > 0:
            shares[key] += extra
            remainder -= extra
    if remainder != 0:
        raise ValueError("Impossibile ripartire la quantità")
    return [Allocation(key, shares[key]) for key, _ in weights if shares[key] > 0]


def consume(
    policy: ConsumptionPolicy, stocks: Sequence[LotStock], quantity: Decimal
) -> ConsumptionResult:
    if quantity <= 0:
        raise ValueError("La quantità da prelevare deve essere positiva")
    if quantity != quantity.quantize(QUANTUM):
        raise ValueError("La quantità ammette al massimo 3 decimali")

    positive = sorted((s for s in stocks if s.quantity > 0), key=lambda s: s.entry_order)
    available = sum((s.quantity for s in positive), ZERO)
    covered = min(quantity, available)
    shortfall = quantity - covered

    allocations: list[Allocation]
    if policy == ConsumptionPolicy.FIFO:
        allocations = []
        left = covered
        for stock in positive:
            if left <= 0:
                break
            take = min(stock.quantity, left)
            allocations.append(Allocation(stock.lot_id, take))
            left -= take
    elif policy in (ConsumptionPolicy.PROPORZIONALE, ConsumptionPolicy.TUTTI_PRESENTI):
        if covered == available:
            allocations = [Allocation(s.lot_id, s.quantity) for s in positive]
        else:
            allocations = split_proportionally(
                covered,
                [(s.lot_id, s.quantity) for s in positive],
                caps={s.lot_id: s.quantity for s in positive},
            )
    else:
        raise ValueError(f"Politica di consumo non supportata: {policy}")

    possible: list[Allocation] = []
    if policy == ConsumptionPolicy.TUTTI_PRESENTI:
        entered = sorted(
            (s for s in stocks if s.entered_since_epoch > 0), key=lambda s: s.entry_order
        )
        possible = split_proportionally(
            quantity, [(s.lot_id, s.entered_since_epoch) for s in entered]
        )

    return ConsumptionResult(tuple(allocations), tuple(possible), shortfall)
