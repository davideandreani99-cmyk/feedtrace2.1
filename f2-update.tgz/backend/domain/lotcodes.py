"""Codici lotto interni (SPEC §6.2): formato configurabile, default MP-{AAAA}{MM}{GG}-{progressivo}."""

from datetime import date

DEFAULT_LOT_CODE_FORMAT = "MP-{AAAA}{MM}{GG}-{progressivo}"


def format_lot_code(fmt: str, day: date, progressive: int, width: int = 3) -> str:
    if "{progressivo}" not in fmt:
        raise ValueError("Il formato del codice lotto deve contenere {progressivo}")
    if progressive < 1:
        raise ValueError("Il progressivo parte da 1")
    return (
        fmt.replace("{AAAA}", f"{day.year:04d}")
        .replace("{MM}", f"{day.month:02d}")
        .replace("{GG}", f"{day.day:02d}")
        .replace("{progressivo}", str(progressive).zfill(width))
    )
