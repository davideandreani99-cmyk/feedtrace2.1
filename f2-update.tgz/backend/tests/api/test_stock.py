"""Fase 2 (RF-02, RF-03, RF-14): ingressi, giacenze per lotto, politiche, inventari, storni."""

import uuid
from datetime import UTC, datetime, timedelta
from decimal import Decimal as D
from zoneinfo import ZoneInfo

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session

from app.db import SessionLocal, admin_engine
from app.models import Tenant
from tests.api.conftest import API, create_material, create_site


# --- helper ------------------------------------------------------------------------
def create_container(client, acc, site, code=None, policy="FIFO", **extra):
    body = {
        "site_id": site["id"], "code": code or f"S-{uuid.uuid4().hex[:6]}", "type": "SILO",
        "consumption_policy": policy, **extra,
    }
    r = client.post(f"{API}/containers", json=body, headers=acc.headers)
    assert r.status_code == 201, r.text
    return r.json()


def create_supplier(client, acc, reg="IT-REG-1"):
    r = client.post(
        f"{API}/suppliers",
        json={"name": f"Fornitore {uuid.uuid4().hex[:5]}", "reg_183_number": reg},
        headers=acc.headers,
    )
    assert r.status_code == 201, r.text
    return r.json()


def post_receipt(client, acc, site, container, material, qty, supplier=None, unit="kg",
                 occurred_at=None, op=None, **line_extra):
    body = {
        "site_id": site["id"],
        "supplier_id": supplier["id"] if supplier else None,
        "ddt_number": "DDT-1",
        "operation_id": op or str(uuid.uuid4()),
        "lines": [{
            "material_id": material["id"], "unit": unit,
            "allocations": [{"container_id": container["id"], "quantity": str(qty)}],
            **({} if supplier else {"self_produced": True}),
            **line_extra,
        }],
    }
    if occurred_at:
        body["occurred_at"] = occurred_at
    return client.post(f"{API}/receipts", json=body, headers=acc.headers)


def get_stock(client, acc, container, at=None):
    params = {"at": at} if at else None
    r = client.get(f"{API}/containers/{container['id']}/stock", params=params, headers=acc.headers)
    assert r.status_code == 200, r.text
    return r.json()


def qty_by_code(stock_json):
    return {lot["internal_code"]: D(lot["quantity"]) for lot in stock_json["lots"]}


def post_op(client, acc, path, body):
    return client.post(f"{API}{path}", json=body, headers=acc.headers)


def outflow(client, acc, container, kg, reason="Vendita di prova", **extra):
    return post_op(client, acc, "/outflows", {
        "container_id": container["id"], "quantity": str(kg), "reason": reason, **extra})


@pytest.fixture
def farm(client, make_account):
    """Azienda con un sito, un fornitore in regola e una materia prima."""
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    return {
        "acc": acc, "site": site, "supplier": create_supplier(client, acc),
        "mais": create_material(client, acc, code="MAIS"),
    }


def two_lots(client, farm, policy):
    """Silo con lotto A 10 t (entrato prima) e lotto B 5 t (caso base del §7)."""
    acc, site, supplier, mais = farm["acc"], farm["site"], farm["supplier"], farm["mais"]
    silo = create_container(client, acc, site, policy=policy)
    assert post_receipt(client, acc, site, silo, mais, "10000", supplier).status_code == 201
    assert post_receipt(client, acc, site, silo, mais, "5000", supplier).status_code == 201
    return silo


# --- RF-02: ingresso ---------------------------------------------------------------
def test_ingresso_crea_lotto_movimento_e_giacenza(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site, capacity="20000")
    r = post_receipt(client, acc, site, silo, farm["mais"], "10", farm["supplier"], unit="t",
                     supplier_lot="LF-77", price_eur_t="250.5")
    assert r.status_code == 201, r.text
    lot = r.json()["lots"][0]
    today = datetime.now(ZoneInfo("Europe/Rome")).strftime("%Y%m%d")
    assert lot["internal_code"] == f"MP-{today}-001"
    assert lot["status"] == "DISPONIBILE"
    assert D(lot["initial_qty"]) == D("10000")
    assert D(lot["price_eur_t"]) == D("250.5")
    stock = get_stock(client, acc, silo)
    assert D(stock["total"]) == D("10000")
    assert D(stock["fill_pct"]) == D("50.0")
    assert qty_by_code(stock) == {lot["internal_code"]: D("10000")}


def test_progressivo_codice_lotto_per_sito_e_per_giorno(client, farm, make_account):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    codes = [
        post_receipt(client, acc, site, silo, farm["mais"], "100", farm["supplier"])
        .json()["lots"][0]["internal_code"]
        for _ in range(3)
    ]
    assert [c.rsplit("-", 1)[1] for c in codes] == ["001", "002", "003"]
    # un altro sito riparte da 001
    site2 = create_site(client, acc)
    silo2 = create_container(client, acc, site2)
    other = post_receipt(client, acc, site2, silo2, farm["mais"], "100", farm["supplier"])
    assert other.json()["lots"][0]["internal_code"].endswith("-001")


def test_riga_ddt_suddivisa_su_piu_contenitori(client, farm):
    acc, site = farm["acc"], farm["site"]
    s1, s2 = create_container(client, acc, site), create_container(client, acc, site)
    body = {
        "site_id": site["id"], "supplier_id": farm["supplier"]["id"],
        "lines": [{"material_id": farm["mais"]["id"], "allocations": [
            {"container_id": s1["id"], "quantity": "6000"},
            {"container_id": s2["id"], "quantity": "4000"}]}],
    }
    r = client.post(f"{API}/receipts", json=body, headers=acc.headers)
    assert r.status_code == 201, r.text
    assert D(r.json()["lots"][0]["initial_qty"]) == D("10000")
    assert D(get_stock(client, acc, s1)["total"]) == D("6000")
    assert D(get_stock(client, acc, s2)["total"]) == D("4000")


def test_litri_convertiti_in_kg_con_la_densita(client, farm):
    acc, site = farm["acc"], farm["site"]
    siero = create_material(client, acc, code="SIERO", type="LIQUIDO", unit="l",
                            density_kg_l="1.025")
    tank = create_container(client, acc, site, type="CISTERNA")
    r = post_receipt(client, acc, site, tank, siero, "1000", farm["supplier"], unit="l")
    assert r.status_code == 201, r.text
    assert D(get_stock(client, acc, tank)["total"]) == D("1025")


def test_materia_prima_in_quarantena_se_richiede_analisi(client, farm):
    acc, site = farm["acc"], farm["site"]
    soia = create_material(client, acc, code="SOIA", requires_analysis=True)
    silo = create_container(client, acc, site)
    r = post_receipt(client, acc, site, silo, soia, "1000", farm["supplier"])
    assert r.json()["lots"][0]["status"] == "IN_QUARANTENA"
    assert "LOT_IN_QUARANTINE" in [w["code"] for w in r.json()["warnings"]]


def test_materia_non_ammessa_nel_contenitore_blocca(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    orzo = create_material(client, acc, code="ORZO")
    client.put(f"{API}/containers/{silo['id']}/allowed-materials", json=[orzo["id"]],
               headers=acc.headers)
    r = post_receipt(client, acc, site, silo, farm["mais"], "100", farm["supplier"])
    assert r.status_code == 422 and "non è ammessa" in r.json()["detail"]
    assert get_stock(client, acc, silo)["lots"] == []
    assert post_receipt(client, acc, site, silo, orzo, "100", farm["supplier"]).status_code == 201


def test_capacita_superata_e_solo_un_avviso(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site, capacity="1000")
    r = post_receipt(client, acc, site, silo, farm["mais"], "1500", farm["supplier"])
    assert r.status_code == 201
    assert "CAPACITY_EXCEEDED" in [w["code"] for w in r.json()["warnings"]]


def test_fornitore_senza_registrazione_183_avviso_o_blocco(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    no183 = client.post(f"{API}/suppliers", json={"name": "Senza reg"}, headers=acc.headers).json()
    r = post_receipt(client, acc, site, silo, farm["mais"], "100", no183)
    assert r.status_code == 201
    assert "SUPPLIER_NO_183" in [w["code"] for w in r.json()["warnings"]]
    with Session(admin_engine) as db:  # configurazione del tenant: bloccante
        tenant = db.get(Tenant, acc.tenant_id)
        tenant.settings = {"block_supplier_without_183": True}
        db.commit()
    assert post_receipt(client, acc, site, silo, farm["mais"], "100", no183).status_code == 422


def test_fornitore_obbligatorio_salvo_autoprodotta(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    body = {"site_id": site["id"], "lines": [{
        "material_id": farm["mais"]["id"],
        "allocations": [{"container_id": silo["id"], "quantity": "500"}]}]}
    assert client.post(f"{API}/receipts", json=body, headers=acc.headers).status_code == 422
    body["lines"][0]["self_produced"] = True
    r = client.post(f"{API}/receipts", json=body, headers=acc.headers)
    assert r.status_code == 201
    assert r.json()["lots"][0]["self_produced"] is True


def test_formato_codice_lotto_configurabile(client, farm):
    acc, site = farm["acc"], farm["site"]
    with Session(admin_engine) as db:
        tenant = db.get(Tenant, acc.tenant_id)
        tenant.settings = {"lot_code_format": "L{GG}{MM}-{progressivo}"}
        db.commit()
    silo = create_container(client, acc, site)
    r = post_receipt(client, acc, site, silo, farm["mais"], "100", farm["supplier"])
    assert r.json()["lots"][0]["internal_code"].startswith("L")
    assert r.json()["lots"][0]["internal_code"].endswith("-001")


# --- idempotenza -------------------------------------------------------------------
def test_ingresso_idempotente_stesso_operation_id_nessun_duplicato(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    op = str(uuid.uuid4())
    first = post_receipt(client, acc, site, silo, farm["mais"], "1000", farm["supplier"], op=op)
    second = post_receipt(client, acc, site, silo, farm["mais"], "1000", farm["supplier"], op=op)
    assert first.status_code == 201 and second.status_code == 200
    assert second.json() == first.json()
    assert D(get_stock(client, acc, silo)["total"]) == D("1000")
    lots = client.get(f"{API}/lots", headers=acc.headers).json()
    assert len(lots) == 1


def test_uscita_idempotente(client, farm):
    acc = farm["acc"]
    silo = two_lots(client, farm, "FIFO")
    op = str(uuid.uuid4())
    assert outflow(client, acc, silo, "1000", operation_id=op).status_code == 201
    assert outflow(client, acc, silo, "1000", operation_id=op).status_code == 200
    assert D(get_stock(client, acc, silo)["total"]) == D("14000")


def test_stesso_operation_id_in_tenant_diversi_non_interferisce(client, make_account):
    a, b = make_account("ADMIN"), make_account("ADMIN")
    op = str(uuid.uuid4())
    for acc in (a, b):
        site = create_site(client, acc)
        silo = create_container(client, acc, site)
        mais = create_material(client, acc, code="MAIS")
        sup = create_supplier(client, acc)
        assert post_receipt(client, acc, site, silo, mais, "100", sup, op=op).status_code == 201


# --- §7: politiche di consumo end-to-end -------------------------------------------
def test_fifo_scarico_12t_A_azzerato_B_3t(client, farm):
    acc = farm["acc"]
    silo = two_lots(client, farm, "FIFO")
    r = outflow(client, acc, silo, "12000")
    assert r.status_code == 201, r.text
    stock = get_stock(client, acc, silo)
    assert len(stock["lots"]) == 1 and D(stock["lots"][0]["quantity"]) == D("3000")
    taken = sorted(D(m["quantity"]) for m in r.json()["movements"])
    assert taken == [D("-10000"), D("-2000")]
    assert D(stock["total"]) == D("3000")


def test_proporzionale_scarico_6t_A_meno_4t_B_meno_2t(client, farm):
    acc = farm["acc"]
    silo = two_lots(client, farm, "PROPORZIONALE")
    outflow(client, acc, silo, "6000")
    quantities = [D(lot["quantity"]) for lot in get_stock(client, acc, silo)["lots"]]
    assert quantities == [D("6000"), D("3000")]


def test_tutti_presenti_scala_in_proporzione(client, farm):
    acc = farm["acc"]
    silo = two_lots(client, farm, "TUTTI_PRESENTI")
    outflow(client, acc, silo, "6000")
    quantities = [D(lot["quantity"]) for lot in get_stock(client, acc, silo)["lots"]]
    assert quantities == [D("6000"), D("3000")]


# --- giacenza negativa (D7) --------------------------------------------------------
def test_giacenza_negativa_consentita_con_avviso_su_lotto_non_allocato(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    r = outflow(client, acc, silo, "2000")
    assert r.status_code == 201
    assert "NEGATIVE_STOCK" in [w["code"] for w in r.json()["warnings"]]
    stock = get_stock(client, acc, silo)
    assert stock["negative"] is True and D(stock["total"]) == D("-2000")
    assert stock["lots"][0]["kind"] == "NON_ALLOCATO"
    anomalies = client.get(f"{API}/anomalies", headers=acc.headers).json()
    assert any(a["container_id"] == silo["id"] for a in anomalies)


def test_carico_dopo_giacenza_negativa_totale_corretto(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    outflow(client, acc, silo, "2000")
    post_receipt(client, acc, site, silo, farm["mais"], "5000", farm["supplier"])
    assert D(get_stock(client, acc, silo)["total"]) == D("3000")


# --- ricostruzione storica (RF-03) -------------------------------------------------
def test_giacenza_a_data_passata_somma_dei_movimenti_fino_a_quella_data(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    now = datetime.now(UTC)
    day3, day2 = (now - timedelta(days=3)), (now - timedelta(days=2))
    assert post_receipt(client, acc, site, silo, farm["mais"], "10000", farm["supplier"],
                        occurred_at=day3.isoformat()).status_code == 201
    assert post_receipt(client, acc, site, silo, farm["mais"], "5000", farm["supplier"],
                        occurred_at=day2.isoformat()).status_code == 201
    outflow(client, acc, silo, "4000")  # oggi

    mid = (now - timedelta(days=2, hours=12)).isoformat()
    assert D(get_stock(client, acc, silo, at=mid)["total"]) == D("10000")
    after = (now - timedelta(days=1)).isoformat()
    assert D(get_stock(client, acc, silo, at=after)["total"]) == D("15000")
    assert D(get_stock(client, acc, silo)["total"]) == D("11000")
    before_all = (now - timedelta(days=5)).isoformat()
    assert get_stock(client, acc, silo, at=before_all)["lots"] == []


def test_data_passata_oltre_7_giorni_solo_responsabile(client, farm, make_account):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    old = (datetime.now(UTC) - timedelta(days=10)).isoformat()
    operatore = make_account("OPERATORE", acc.tenant_id)
    r = post_receipt(client, operatore, site, silo, farm["mais"], "100", farm["supplier"],
                     occurred_at=old)
    assert r.status_code == 403
    responsabile = make_account("RESPONSABILE", acc.tenant_id)
    r = post_receipt(client, responsabile, site, silo, farm["mais"], "100", farm["supplier"],
                     occurred_at=old)
    assert r.status_code == 201, r.text


def test_data_passata_con_movimenti_successivi_rifiutata(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    post_receipt(client, acc, site, silo, farm["mais"], "100", farm["supplier"])
    yesterday = (datetime.now(UTC) - timedelta(days=1)).isoformat()
    r = post_receipt(client, acc, site, silo, farm["mais"], "100", farm["supplier"],
                     occurred_at=yesterday)
    assert r.status_code == 409 and "storno" in r.json()["detail"]


def test_data_nel_futuro_rifiutata(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    future = (datetime.now(UTC) + timedelta(days=2)).isoformat()
    r = post_receipt(client, acc, site, silo, farm["mais"], "100", farm["supplier"],
                     occurred_at=future)
    assert r.status_code == 422


# --- travaso (D6) ------------------------------------------------------------------
def test_travaso_sposta_gli_stessi_lotti(client, farm):
    acc, site = farm["acc"], farm["site"]
    source = two_lots(client, farm, "FIFO")
    target = create_container(client, acc, site)
    r = post_op(client, acc, "/transfers", {
        "from_container_id": source["id"], "to_container_id": target["id"], "quantity": "11000"})
    assert r.status_code == 201, r.text
    assert D(get_stock(client, acc, source)["total"]) == D("4000")
    moved = qty_by_code(get_stock(client, acc, target))
    assert sorted(moved.values()) == [D("1000"), D("10000")]


def test_travaso_verso_contenitore_con_materia_non_ammessa_annullato(client, farm):
    acc, site = farm["acc"], farm["site"]
    source = two_lots(client, farm, "FIFO")
    target = create_container(client, acc, site)
    orzo = create_material(client, acc, code="ORZO")
    client.put(f"{API}/containers/{target['id']}/allowed-materials", json=[orzo["id"]],
               headers=acc.headers)
    r = post_op(client, acc, "/transfers", {
        "from_container_id": source["id"], "to_container_id": target["id"], "quantity": "100"})
    assert r.status_code == 422
    assert D(get_stock(client, acc, source)["total"]) == D("15000")
    assert D(get_stock(client, acc, target)["total"]) == D("0")


def test_travaso_stesso_contenitore_non_valido(client, farm):
    silo = two_lots(client, farm, "FIFO")
    r = post_op(client, farm["acc"], "/transfers", {
        "from_container_id": silo["id"], "to_container_id": silo["id"], "quantity": "1"})
    assert r.status_code == 422


# --- inventario / rettifica (RF-03) ------------------------------------------------
def inventory(client, acc, container, measured, reason="Conteggio di fine mese", **extra):
    return post_op(client, acc, f"/containers/{container['id']}/inventory",
                   {"measured_quantity": str(measured), "reason": reason, **extra})


def test_inventario_in_meno_ripartito_secondo_la_politica(client, farm):
    acc = farm["acc"]
    silo = two_lots(client, farm, "PROPORZIONALE")
    r = inventory(client, acc, silo, "12000")
    assert r.status_code == 201, r.text
    assert D(r.json()["details"]["difference"]) == D("-3000")
    assert [D(lot["quantity"]) for lot in get_stock(client, acc, silo)["lots"]] == [
        D("8000"), D("4000")]
    assert {m["type"] for m in r.json()["movements"]} == {"RETTIFICA_INVENTARIO"}


def test_inventario_in_piu_va_al_lotto_non_allocato(client, farm):
    acc = farm["acc"]
    silo = two_lots(client, farm, "FIFO")
    inventory(client, acc, silo, "16000")
    stock = get_stock(client, acc, silo)
    assert D(stock["total"]) == D("16000")
    assert [lot["kind"] for lot in stock["lots"]].count("NON_ALLOCATO") == 1


def test_inventario_richiede_motivazione_e_ruolo(client, farm, make_account):
    acc = farm["acc"]
    silo = two_lots(client, farm, "FIFO")
    assert inventory(client, acc, silo, "100", reason="").status_code == 422
    operatore = make_account("OPERATORE", acc.tenant_id)
    assert inventory(client, operatore, silo, "100").status_code == 403


def test_inventario_a_zero_azzera_il_contenitore(client, farm):
    acc = farm["acc"]
    silo = two_lots(client, farm, "TUTTI_PRESENTI")
    inventory(client, acc, silo, "0")
    assert get_stock(client, acc, silo)["lots"] == []


# --- svuotamento / pulizia ---------------------------------------------------------
def test_svuotamento_azzera_composizione_e_registra_la_pulizia(client, farm):
    acc = farm["acc"]
    silo = two_lots(client, farm, "FIFO")
    r = post_op(client, acc, f"/containers/{silo['id']}/cleanings",
                {"type": "SVUOTAMENTO", "notes": "Pulizia di fine ciclo"})
    assert r.status_code == 201, r.text
    assert get_stock(client, acc, silo)["lots"] == []
    assert any(m["closes_epoch"] for m in r.json()["movements"])
    # un nuovo carico riparte da zero
    post_receipt(client, acc, farm["site"], silo, farm["mais"], "700", farm["supplier"])
    assert D(get_stock(client, acc, silo)["total"]) == D("700")


def test_flushing_non_svuota(client, farm):
    acc = farm["acc"]
    silo = two_lots(client, farm, "FIFO")
    r = post_op(client, acc, f"/containers/{silo['id']}/cleanings", {"type": "FLUSHING"})
    assert r.status_code == 201 and r.json()["movements"] == []
    assert D(get_stock(client, acc, silo)["total"]) == D("15000")


# --- storno (RF-14) ----------------------------------------------------------------
def movements_of(client, acc, op_id):
    r = client.get(f"{API}/movements", params={"operation_id": op_id}, headers=acc.headers)
    assert r.status_code == 200
    return r.json()


def test_storno_di_un_movimento_di_carico(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    op = str(uuid.uuid4())
    post_receipt(client, acc, site, silo, farm["mais"], "1000", farm["supplier"], op=op)
    original = movements_of(client, acc, op)[0]
    r = post_op(client, acc, f"/movements/{original['id']}/storno", {"reason": "DDT errato"})
    assert r.status_code == 201, r.text
    reversal = r.json()["movements"][0]
    assert reversal["type"] == "STORNO" and D(reversal["quantity"]) == D("-1000")
    assert reversal["reverses_movement_id"] == original["id"]
    assert get_stock(client, acc, silo)["lots"] == []
    # il movimento originale è ancora lì, non modificato
    assert D(original["quantity"]) == D("1000")
    again = post_op(client, acc, f"/movements/{original['id']}/storno", {"reason": "di nuovo"})
    assert again.status_code == 409
    storno_of_storno = post_op(client, acc, f"/movements/{reversal['id']}/storno",
                               {"reason": "storno dello storno"})
    assert storno_of_storno.status_code == 422


def test_storno_di_un_intera_operazione(client, farm):
    acc = farm["acc"]
    silo = two_lots(client, farm, "FIFO")
    op = str(uuid.uuid4())
    outflow(client, acc, silo, "12000", operation_id=op)
    assert D(get_stock(client, acc, silo)["total"]) == D("3000")
    r = post_op(client, acc, f"/operations/{op}/storno", {"reason": "Uscita registrata per errore"})
    assert r.status_code == 201, r.text
    assert len(r.json()["movements"]) == 2
    assert D(get_stock(client, acc, silo)["total"]) == D("15000")
    assert post_op(client, acc, f"/operations/{op}/storno",
                   {"reason": "ancora"}).status_code == 409


def test_storno_richiede_motivazione_e_ruolo(client, farm, make_account):
    acc = farm["acc"]
    silo = two_lots(client, farm, "FIFO")
    op = str(uuid.uuid4())
    outflow(client, acc, silo, "100", operation_id=op)
    operatore = make_account("OPERATORE", acc.tenant_id)
    assert post_op(client, operatore, f"/operations/{op}/storno",
                   {"reason": "errore"}).status_code == 403
    assert post_op(client, acc, f"/operations/{op}/storno", {"reason": ""}).status_code == 422


# --- movimenti immutabili (RF-14) --------------------------------------------------
def test_movimenti_immutabili_per_ruolo_applicativo_e_proprietario(client, farm):
    acc = farm["acc"]
    two_lots(client, farm, "FIFO")
    for statement in ("update movement set quantity = 1", "delete from movement"):
        with SessionLocal() as db:
            db.execute(text("select set_config('app.tenant_id', :t, true)"),
                       {"t": str(acc.tenant_id)})
            with pytest.raises(DBAPIError):
                db.execute(text(statement))
        with admin_engine.connect() as conn, pytest.raises(DBAPIError):
            conn.exec_driver_sql(statement)


def test_non_si_puo_inserire_quantita_zero_se_non_svuotamento(client, farm):
    acc = farm["acc"]
    silo = two_lots(client, farm, "FIFO")
    movement = client.get(f"{API}/movements", headers=acc.headers).json()[0]
    with SessionLocal() as db:
        db.execute(text("select set_config('app.tenant_id', :t, true)"), {"t": str(acc.tenant_id)})
        with pytest.raises(DBAPIError):
            db.execute(text(
                "insert into movement (id, tenant_id, site_id, occurred_at, type, container_id, "
                "lot_id, quantity, operation_id) values (:i, :t, :s, now(), 'USCITA_ALTRO', :c, "
                ":l, 0, :o)"),
                {"i": str(uuid.uuid4()), "t": str(acc.tenant_id), "s": farm["site"]["id"],
                 "c": silo["id"], "l": movement["lot_id"], "o": str(uuid.uuid4())})


# --- isolamento tra aziende --------------------------------------------------------
def test_stock_e_lotti_non_attraversano_i_tenant(client, farm, make_account):
    acc = farm["acc"]
    silo = two_lots(client, farm, "FIFO")
    intruder = make_account("ADMIN")
    assert client.get(f"{API}/containers/{silo['id']}/stock",
                      headers=intruder.headers).status_code == 404
    assert client.get(f"{API}/lots", headers=intruder.headers).json() == []
    assert client.get(f"{API}/movements", headers=intruder.headers).json() == []
    lot_id = client.get(f"{API}/lots", headers=acc.headers).json()[0]["id"]
    assert client.get(f"{API}/lots/{lot_id}", headers=intruder.headers).status_code == 404
    # nessuna operazione su contenitori altrui
    assert outflow(client, intruder, silo, "100").status_code == 422
    assert post_op(client, intruder, "/transfers", {
        "from_container_id": silo["id"], "to_container_id": silo["id"], "quantity": "1"
    }).status_code == 422
    assert D(get_stock(client, acc, silo)["total"]) == D("15000")


def test_ingresso_con_sito_o_contenitore_di_altro_tenant_rifiutato(client, farm, make_account):
    intruder = make_account("ADMIN")
    silo = two_lots(client, farm, "FIFO")
    site_i = create_site(client, intruder)
    mais_i = create_material(client, intruder, code="MAIS")
    sup_i = create_supplier(client, intruder)
    r = post_receipt(client, intruder, site_i, silo, mais_i, "100", sup_i)
    assert r.status_code == 422
    r = post_receipt(client, intruder, farm["site"], silo, mais_i, "100", sup_i)
    assert r.status_code == 422


# --- permessi ----------------------------------------------------------------------
def test_auditor_legge_ma_non_registra_movimenti(client, farm, make_account):
    acc, site = farm["acc"], farm["site"]
    silo = two_lots(client, farm, "FIFO")
    auditor = make_account("AUDITOR", acc.tenant_id)
    assert client.get(f"{API}/stock/containers", headers=auditor.headers).status_code == 200
    assert post_receipt(client, auditor, site, silo, farm["mais"], "1",
                        farm["supplier"]).status_code == 403
    assert outflow(client, auditor, silo, "1").status_code == 403
    operatore = make_account("OPERATORE", acc.tenant_id)
    assert outflow(client, operatore, silo, "1").status_code == 201


def test_elenco_contenitori_con_riempimento_e_lotti(client, farm):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site, capacity="30000")
    post_receipt(client, acc, site, silo, farm["mais"], "15000", farm["supplier"])
    rows = client.get(f"{API}/stock/containers", headers=acc.headers).json()
    row = next(r for r in rows if r["container_id"] == silo["id"])
    assert D(row["total"]) == D("15000") and D(row["fill_pct"]) == D("50.0")
    assert row["lots_count"] == 1 and row["negative"] is False


# --- allegati ----------------------------------------------------------------------
def test_allegato_a_un_ingresso(client, farm, make_account):
    acc, site = farm["acc"], farm["site"]
    silo = create_container(client, acc, site)
    receipt = post_receipt(client, acc, site, silo, farm["mais"], "100", farm["supplier"]).json()
    pdf = b"%PDF-1.4 contenuto di prova"
    r = client.post(
        f"{API}/attachments", data={"target_type": "receipt", "target_id": receipt["id"]},
        files={"file": ("ddt.pdf", pdf, "application/pdf")}, headers=acc.headers)
    assert r.status_code == 201, r.text
    attachment_id = r.json()["id"]
    listed = client.get(f"{API}/attachments", headers=acc.headers,
                        params={"target_type": "receipt", "target_id": receipt["id"]}).json()
    assert [a["filename"] for a in listed] == ["ddt.pdf"]
    download = client.get(f"{API}/attachments/{attachment_id}/download", headers=acc.headers)
    assert download.status_code == 200 and download.content == pdf
    bad = client.post(
        f"{API}/attachments", data={"target_type": "receipt", "target_id": receipt["id"]},
        files={"file": ("note.txt", b"x", "text/plain")}, headers=acc.headers)
    assert bad.status_code == 415
    other = make_account("ADMIN")
    assert client.get(f"{API}/attachments/{attachment_id}/download",
                      headers=other.headers).status_code == 404


def test_dettaglio_lotto_con_ubicazioni(client, farm):
    acc, site = farm["acc"], farm["site"]
    s1, s2 = create_container(client, acc, site), create_container(client, acc, site)
    body = {"site_id": site["id"], "supplier_id": farm["supplier"]["id"],
            "lines": [{"material_id": farm["mais"]["id"], "allocations": [
                {"container_id": s1["id"], "quantity": "300"},
                {"container_id": s2["id"], "quantity": "200"}]}]}
    lot_id = client.post(f"{API}/receipts", json=body, headers=acc.headers).json()["lots"][0]["id"]
    detail = client.get(f"{API}/lots/{lot_id}", headers=acc.headers).json()
    assert D(detail["total"]) == D("500")
    assert sorted(D(c["quantity"]) for c in detail["containers"]) == [D("200"), D("300")]
