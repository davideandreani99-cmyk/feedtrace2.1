"""Casi di calcolo del §7 della SPEC: FIFO, PROPORZIONALE, TUTTI_PRESENTI (RF-03)."""

from decimal import Decimal as D

import pytest

from domain.consumption import LotStock, consume
from domain.enums import ConsumptionPolicy as P


def stocks_ab():
    # Lotto A 10 t (entrato prima), lotto B 5 t. Quantità in kg.
    return [
        LotStock("A", D("10000"), entry_order=1),
        LotStock("B", D("5000"), entry_order=2),
    ]


def as_dict(allocations):
    return {a.lot_id: a.quantity for a in allocations}


# --- §7 FIFO -----------------------------------------------------------------------
def test_fifo_scarico_12t_A_azzerato_B_resta_3t():
    result = consume(P.FIFO, stocks_ab(), D("12000"))
    assert as_dict(result.allocations) == {"A": D("10000"), "B": D("2000")}
    assert result.shortfall == 0
    assert result.possible_links == ()


def test_fifo_rispetta_entry_order_non_la_posizione_in_lista():
    stocks = [LotStock("B", D("5000"), 2), LotStock("A", D("10000"), 1)]
    result = consume(P.FIFO, stocks, D("3000"))
    assert as_dict(result.allocations) == {"A": D("3000")}


# --- §7 PROPORZIONALE --------------------------------------------------------------
def test_proporzionale_scarico_6t_A_meno_4t_B_meno_2t():
    result = consume(P.PROPORZIONALE, stocks_ab(), D("6000"))
    assert as_dict(result.allocations) == {"A": D("4000"), "B": D("2000")}
    assert result.possible_links == ()


def test_proporzionale_resto_al_lotto_con_quota_maggiore():
    result = consume(P.PROPORZIONALE, stocks_ab(), D("0.001"))
    assert as_dict(result.allocations) == {"A": D("0.001")}


def test_proporzionale_somma_sempre_uguale_alla_quantita():
    stocks = [
        LotStock("A", D("3333.333"), 1),
        LotStock("B", D("1111.111"), 2),
        LotStock("C", D("7.777"), 3),
    ]
    for quantity in ("1", "0.002", "999.999", "1234.567", "4452.221"):
        result = consume(P.PROPORZIONALE, stocks, D(quantity))
        assert sum(a.quantity for a in result.allocations) == D(quantity)
        by_lot = as_dict(result.allocations)
        for stock in stocks:
            assert by_lot.get(stock.lot_id, D(0)) <= stock.quantity


def test_proporzionale_consumo_totale_azzera_tutti_i_lotti_esattamente():
    stocks = [LotStock("A", D("3.333"), 1), LotStock("B", D("6.667"), 2)]
    result = consume(P.PROPORZIONALE, stocks, D("10"))
    assert as_dict(result.allocations) == {"A": D("3.333"), "B": D("6.667")}
    assert result.shortfall == 0


# --- giacenza insufficiente (giacenza negativa, lotto NON ALLOCATO) -----------------
@pytest.mark.parametrize("policy", [P.FIFO, P.PROPORZIONALE, P.TUTTI_PRESENTI])
def test_eccedenza_diventa_shortfall(policy):
    result = consume(policy, stocks_ab(), D("20000"))
    assert sum(a.quantity for a in result.allocations) == D("15000")
    assert result.shortfall == D("5000")


def test_contenitore_vuoto_tutto_shortfall():
    result = consume(P.FIFO, [], D("100"))
    assert result.allocations == ()
    assert result.shortfall == D("100")


def test_lotti_a_giacenza_zero_o_negativa_non_vengono_consumati():
    stocks = [
        LotStock("NA", D("-50"), 0),
        LotStock("A", D("0"), 1),
        LotStock("B", D("100"), 2),
    ]
    result = consume(P.FIFO, stocks, D("30"))
    assert as_dict(result.allocations) == {"B": D("30")}


@pytest.mark.parametrize("bad", ["0", "-1", "1.0001"])
def test_quantita_non_valide(bad):
    with pytest.raises(ValueError):
        consume(P.FIFO, stocks_ab(), D(bad))


# --- §7 TUTTI_PRESENTI -------------------------------------------------------------
class Silo:
    """Piccolo simulatore del contenitore per verificare le catene di legami."""

    def __init__(self, policy):
        self.policy = policy
        self.qty = {}
        self.order = {}
        self.entered = {}

    def load(self, lot, quantity):
        self.qty[lot] = self.qty.get(lot, D(0)) + D(quantity)
        self.order.setdefault(lot, len(self.order) + 1)
        self.entered[lot] = self.entered.get(lot, D(0)) + D(quantity)

    def discharge(self, quantity):
        stocks = [
            LotStock(lot, q, self.order[lot], self.entered.get(lot, D(0)))
            for lot, q in self.qty.items()
        ]
        result = consume(self.policy, stocks, D(quantity))
        for allocation in result.allocations:
            self.qty[allocation.lot_id] -= allocation.quantity
        return result

    def empty(self):
        self.qty = {lot: D(0) for lot in self.qty}
        self.entered = {}  # chiude la catena dei legami POSSIBILI


def test_tutti_presenti_secondo_scarico_legato_ad_A_B_C():
    silo = Silo(P.TUTTI_PRESENTI)
    silo.load("A", "10")
    silo.load("B", "5")
    silo.discharge("6")
    silo.load("C", "5")
    second = silo.discharge("4")
    assert as_dict(second.possible_links) == {"A": D("2"), "B": D("1"), "C": D("1")}
    assert sum(a.quantity for a in second.possible_links) == D("4")


def test_tutti_presenti_quantita_scalate_in_proporzione_alla_giacenza():
    silo = Silo(P.TUTTI_PRESENTI)
    silo.load("A", "10")
    silo.load("B", "5")
    result = silo.discharge("6")
    assert as_dict(result.allocations) == {"A": D("4"), "B": D("2")}


def test_tutti_presenti_dopo_svuotamento_e_carico_D_solo_D():
    silo = Silo(P.TUTTI_PRESENTI)
    silo.load("A", "10")
    silo.load("B", "5")
    silo.discharge("3")
    silo.empty()
    silo.load("D", "8")
    result = silo.discharge("2")
    assert as_dict(result.possible_links) == {"D": D("2")}


def test_tutti_presenti_include_lotti_gia_esauriti_dall_ultimo_svuotamento():
    silo = Silo(P.TUTTI_PRESENTI)
    silo.load("A", "10")
    silo.discharge("10")  # A esaurito, catena ancora aperta
    silo.load("B", "5")
    result = silo.discharge("1")
    assert set(as_dict(result.possible_links)) == {"A", "B"}
    assert sum(a.quantity for a in result.possible_links) == D("1")
    assert as_dict(result.allocations) == {"B": D("1")}


def test_tutti_presenti_contenitore_vuoto_nessun_legame():
    result = consume(P.TUTTI_PRESENTI, [], D("5"))
    assert result.possible_links == ()
    assert result.shortfall == D("5")


def test_fifo_e_proporzionale_non_producono_legami_possibili():
    assert consume(P.FIFO, stocks_ab(), D("1")).possible_links == ()
    assert consume(P.PROPORZIONALE, stocks_ab(), D("1")).possible_links == ()
