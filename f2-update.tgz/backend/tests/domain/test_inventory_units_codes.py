from datetime import date
from decimal import Decimal as D

import pytest

from domain.consumption import LotStock
from domain.enums import ConsumptionPolicy as P
from domain.inventory import plan_emptying, plan_inventory_adjustment
from domain.lotcodes import DEFAULT_LOT_CODE_FORMAT, format_lot_code
from domain.units import InputUnit, convert_to_kg


def stocks():
    return [LotStock("A", D("10"), 1), LotStock("B", D("5"), 2)]


# --- inventario / rettifica (RF-03) ------------------------------------------------
def test_rettifica_in_meno_ripartita_secondo_la_politica_fifo():
    plan = plan_inventory_adjustment(P.FIFO, stocks(), D("12"))
    assert dict(plan.lines) == {"A": D("-3")}
    assert plan.difference == D("-3")
    assert plan.closes_epoch is False


def test_rettifica_in_meno_ripartita_secondo_la_politica_proporzionale():
    plan = plan_inventory_adjustment(P.PROPORZIONALE, stocks(), D("12"))
    assert dict(plan.lines) == {"A": D("-2"), "B": D("-1")}


def test_rettifica_in_piu_va_al_lotto_non_allocato():
    plan = plan_inventory_adjustment(P.FIFO, stocks(), D("20"))
    assert plan.lines == ((None, D("5")),)


def test_rettifica_senza_differenza_non_genera_movimenti():
    plan = plan_inventory_adjustment(P.FIFO, stocks(), D("15"))
    assert plan.lines == ()
    assert plan.difference == D("0")


def test_rettifica_oltre_la_giacenza_residuo_su_non_allocato():
    plan = plan_inventory_adjustment(P.FIFO, [LotStock("A", D("2"), 1)], D("0.5"))
    assert dict(plan.lines) == {"A": D("-1.5")}
    # misurato 0 con giacenza teorica negativa: l'inventario a zero azzera tutto
    zero = plan_inventory_adjustment(P.FIFO, [LotStock("NA", D("-4"), 1)], D("0"))
    assert dict(zero.lines) == {"NA": D("4")}


def test_inventario_a_zero_azzera_tutti_i_lotti_e_chiude_la_catena():
    plan = plan_inventory_adjustment(P.TUTTI_PRESENTI, stocks(), D("0"))
    assert dict(plan.lines) == {"A": D("-10"), "B": D("-5")}
    assert plan.closes_epoch is True


def test_rettifica_quantita_misurata_negativa_non_valida():
    with pytest.raises(ValueError):
        plan_inventory_adjustment(P.FIFO, stocks(), D("-1"))


def test_svuotamento_azzera_la_composizione():
    plan = plan_emptying([*stocks(), LotStock("C", D("0"), 3), LotStock("NA", D("-2"), 0)])
    assert dict(plan) == {"A": D("-10"), "B": D("-5"), "NA": D("2")}


# --- conversioni di unità (solo ai bordi) ------------------------------------------
def test_conversioni_unita():
    assert convert_to_kg(D("1.5"), InputUnit.T, None) == D("1500.000")
    assert convert_to_kg(D("120"), InputUnit.KG, None) == D("120.000")
    assert convert_to_kg(D("100"), InputUnit.L, D("1.025")) == D("102.500")


def test_litri_senza_densita_errore():
    with pytest.raises(ValueError):
        convert_to_kg(D("10"), InputUnit.L, None)


def test_quantita_non_positiva_errore():
    with pytest.raises(ValueError):
        convert_to_kg(D("0"), InputUnit.KG, None)


def test_arrotondamento_a_tre_decimali():
    assert convert_to_kg(D("1"), InputUnit.L, D("1.0005")) == D("1.001")  # half up


# --- codici lotto (SPEC §6.2) ------------------------------------------------------
def test_codice_lotto_default():
    code = format_lot_code(DEFAULT_LOT_CODE_FORMAT, date(2026, 10, 2), 7)
    assert code == "MP-20261002-007"


def test_codice_lotto_formato_personalizzato():
    assert format_lot_code("L{GG}{MM}{AAAA}/{progressivo}", date(2026, 1, 5), 12) == "L05012026/012"


def test_codice_lotto_senza_progressivo_non_valido():
    with pytest.raises(ValueError):
        format_lot_code("MP-{AAAA}", date(2026, 1, 1), 1)
    with pytest.raises(ValueError):
        format_lot_code(DEFAULT_LOT_CODE_FORMAT, date(2026, 1, 1), 0)
