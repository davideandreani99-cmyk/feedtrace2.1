"""Operazioni sui contenitori: travaso, uscite, inventario, svuotamento, storno (RF-03, RF-14)."""

import uuid
from datetime import UTC, datetime
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import func, select

from app import audit
from app.deps import Ctx
from app.models import Cleaning, ContainerAllowedMaterial, Lot, Movement, RawMaterial
from app.schemas_stock import (
    CleaningIn,
    InventoryIn,
    MovementOut,
    OperationOut,
    OutflowIn,
    StornoIn,
    TransferIn,
    WarningOut,
)
from app.services import stock
from domain.consumption import ZERO
from domain.enums import CleaningType, ConsumptionPolicy, MovementType
from domain.inventory import plan_emptying, plan_inventory_adjustment


def _kg(quantity: Decimal, unit: str) -> Decimal:
    return (quantity * 1000 if unit == "t" else quantity).quantize(Decimal("0.001"))


def _out(
    ctx: Ctx,
    operation_id: uuid.UUID,
    kind: str,
    movements: list[Movement],
    warnings: list[WarningOut],
    details: dict[str, str] | None = None,
    reason: str | None = None,
) -> OperationOut:
    ctx.db.flush()
    out = OperationOut(
        operation_id=operation_id,
        movements=[MovementOut.model_validate(m) for m in movements],
        warnings=warnings,
        details=details or {},
    )
    audit.record(
        ctx,
        "operations",
        operation_id,
        kind,
        None,
        {"movements": len(movements), "reason": reason, **(details or {})},
    )
    return out


def _warn(container, total_after: Decimal, shortfall: Decimal) -> list[WarningOut]:
    warning = stock.negative_warning(container, total_after, shortfall)
    return [WarningOut(**warning)] if warning else []


def transfer(ctx: Ctx, payload: TransferIn, operation_id: uuid.UUID) -> OperationOut:
    if payload.from_container_id == payload.to_container_id:
        raise HTTPException(status_code=422, detail="Contenitore di origine e destinazione uguali")
    containers = stock.lock_containers(ctx, [payload.from_container_id, payload.to_container_id])
    source, target = containers[payload.from_container_id], containers[payload.to_container_id]
    if source.site_id != target.site_id:
        raise HTTPException(status_code=422, detail="I travasi sono ammessi solo nello stesso sito")
    occurred_at = stock.resolve_occurred_at(ctx, payload.occurred_at, list(containers))
    kg = _kg(payload.quantity, payload.unit)

    outcome = stock.consume_from_container(
        ctx, source, kg, MovementType.TRASFERIMENTO, occurred_at, operation_id,
        reason=payload.reason,
    )
    restriction = {
        m_id
        for (m_id,) in ctx.db.execute(
            select(ContainerAllowedMaterial.material_id).where(
                ContainerAllowedMaterial.container_id == target.id,
                ContainerAllowedMaterial.tenant_id == ctx.tenant_id,
            )
        )
    }
    movements = list(outcome.movements)
    for out_movement in outcome.movements:
        lot = ctx.db.get(Lot, out_movement.lot_id)
        if restriction and lot is not None and lot.material_id not in restriction | {None}:
            material = ctx.db.get(RawMaterial, lot.material_id)
            raise HTTPException(
                status_code=422,
                detail=f"La materia prima {material.code if material else ''} non è ammessa "
                f"nel contenitore {target.code}",
            )
        lot_id = out_movement.lot_id
        if lot is not None and lot.kind == "NON_ALLOCATO":
            lot_id = stock.get_na_lot(ctx, target).id  # l'eccedenza resta "non allocata"
        movements.append(
            stock.add_movement(
                ctx, container=target, lot_id=lot_id, quantity=-out_movement.quantity,
                mtype=MovementType.TRASFERIMENTO, occurred_at=occurred_at,
                operation_id=operation_id, reason=payload.reason,
            )
        )
    warnings = _warn(source, outcome.total_before - kg, outcome.shortfall)
    ctx.db.flush()
    if target.capacity is not None and target.unit == "kg":
        total_target = stock.total_of(stock.load_stock(ctx.db, ctx.tenant_id, target.id))
        if total_target > target.capacity:
            warnings.append(
                WarningOut(
                    code="CAPACITY_EXCEEDED",
                    message=f"Capacità superata nel contenitore {target.code} "
                    f"({total_target} kg su {target.capacity})",
                )
            )
    return _out(ctx, operation_id, "TRANSFER", movements, warnings, reason=payload.reason)


def outflow(ctx: Ctx, payload: OutflowIn, operation_id: uuid.UUID) -> OperationOut:
    containers = stock.lock_containers(ctx, [payload.container_id])
    container = containers[payload.container_id]
    occurred_at = stock.resolve_occurred_at(ctx, payload.occurred_at, [container.id])
    kg = _kg(payload.quantity, payload.unit)
    outcome = stock.consume_from_container(
        ctx, container, kg, MovementType.USCITA_ALTRO, occurred_at, operation_id,
        reason=payload.reason,
    )
    warnings = _warn(container, outcome.total_before - kg, outcome.shortfall)
    return _out(ctx, operation_id, "OUTFLOW", outcome.movements, warnings, reason=payload.reason)


def inventory(
    ctx: Ctx, container_id: uuid.UUID, payload: InventoryIn, operation_id: uuid.UUID
) -> OperationOut:
    container = stock.lock_containers(ctx, [container_id])[container_id]
    occurred_at = stock.resolve_occurred_at(ctx, payload.occurred_at, [container.id])
    measured = _kg(payload.measured_quantity, payload.unit)
    rows = stock.load_stock(ctx.db, ctx.tenant_id, container.id)
    plan = plan_inventory_adjustment(
        ConsumptionPolicy(container.consumption_policy), stock.to_domain(rows), measured
    )
    movements: list[Movement] = []
    for lot_id, quantity in plan.lines:
        target_lot = lot_id if lot_id is not None else stock.get_na_lot(ctx, container).id
        movements.append(
            stock.add_movement(
                ctx, container=container, lot_id=target_lot, quantity=quantity,
                mtype=MovementType.RETTIFICA_INVENTARIO, occurred_at=occurred_at,
                operation_id=operation_id, reason=payload.reason,
                closes_epoch=plan.closes_epoch,
            )
        )
    if plan.closes_epoch and not movements:  # già a zero: serve comunque il marcatore
        movements.append(
            stock.add_movement(
                ctx, container=container, lot_id=stock.get_na_lot(ctx, container).id,
                quantity=ZERO, mtype=MovementType.SVUOTAMENTO, occurred_at=occurred_at,
                operation_id=operation_id, reason=payload.reason, closes_epoch=True,
            )
        )
    details = {
        "theoretical": str(stock.total_of(rows)),
        "measured": str(measured),
        "difference": str(plan.difference),
    }
    return _out(
        ctx, operation_id, "INVENTORY", movements, [], details=details, reason=payload.reason
    )


def cleaning(
    ctx: Ctx, container_id: uuid.UUID, payload: CleaningIn, operation_id: uuid.UUID
) -> OperationOut:
    container = stock.lock_containers(ctx, [container_id])[container_id]
    occurred_at = stock.resolve_occurred_at(ctx, payload.occurred_at, [container.id])
    movements: list[Movement] = []
    if payload.type in (CleaningType.SVUOTAMENTO, CleaningType.PULIZIA):
        rows = stock.load_stock(ctx.db, ctx.tenant_id, container.id)
        for lot_id, quantity in plan_emptying(stock.to_domain(rows)):
            movements.append(
                stock.add_movement(
                    ctx, container=container, lot_id=lot_id, quantity=quantity,
                    mtype=MovementType.SVUOTAMENTO, occurred_at=occurred_at,
                    operation_id=operation_id, reason=payload.notes, closes_epoch=True,
                )
            )
        # marcatore finale: chiude la catena dei legami POSSIBILI anche a contenitore vuoto
        movements.append(
            stock.add_movement(
                ctx, container=container, lot_id=stock.get_na_lot(ctx, container).id,
                quantity=ZERO, mtype=MovementType.SVUOTAMENTO, occurred_at=occurred_at,
                operation_id=operation_id, reason=payload.notes, closes_epoch=True,
            )
        )
    ctx.db.add(
        Cleaning(
            tenant_id=ctx.tenant_id, container_id=container.id, type=payload.type.value,
            after_medicated=payload.after_medicated, occurred_at=occurred_at,
            operation_id=operation_id, notes=payload.notes, user_id=ctx.user.id,
        )
    )
    return _out(ctx, operation_id, f"CLEANING_{payload.type.value}", movements, [],
                reason=payload.notes)


def _reverse(
    ctx: Ctx, original: Movement, container, operation_id: uuid.UUID, reason: str,
    occurred_at: datetime,
) -> Movement:
    return stock.add_movement(
        ctx, container=container, lot_id=original.lot_id, quantity=-original.quantity,
        mtype=MovementType.STORNO, occurred_at=occurred_at, operation_id=operation_id,
        doc_type="storno", doc_id=original.id, reason=reason, reverses=original.id,
    )


def _already_reversed(ctx: Ctx, movement_ids: list[uuid.UUID]) -> set[uuid.UUID]:
    return {
        r
        for (r,) in ctx.db.execute(
            select(Movement.reverses_movement_id).where(
                Movement.tenant_id == ctx.tenant_id,
                Movement.reverses_movement_id.in_(movement_ids),
            )
        )
    }


def storno_movement(
    ctx: Ctx, movement_id: uuid.UUID, payload: StornoIn, operation_id: uuid.UUID
) -> OperationOut:
    original = ctx.db.scalar(
        select(Movement).where(Movement.id == movement_id, Movement.tenant_id == ctx.tenant_id)
    )
    if original is None:
        raise HTTPException(status_code=404, detail="Movimento non trovato")
    if original.type == MovementType.STORNO.value:
        raise HTTPException(status_code=422, detail="Uno storno non si storna: registra un nuovo movimento")
    if original.quantity == 0:
        raise HTTPException(status_code=422, detail="Movimento a quantità zero: non stornabile")
    if movement_id in _already_reversed(ctx, [movement_id]):
        raise HTTPException(status_code=409, detail="Movimento già stornato")
    container = stock.lock_containers(ctx, [original.container_id])[original.container_id]
    reverse = _reverse(ctx, original, container, operation_id, payload.reason, datetime.now(UTC))
    return _out(ctx, operation_id, "STORNO", [reverse], [], reason=payload.reason)


def storno_operation(
    ctx: Ctx, target_operation_id: uuid.UUID, payload: StornoIn, operation_id: uuid.UUID
) -> OperationOut:
    originals = list(
        ctx.db.scalars(
            select(Movement)
            .where(
                Movement.tenant_id == ctx.tenant_id,
                Movement.operation_id == target_operation_id,
                Movement.type != MovementType.STORNO.value,
                Movement.quantity != 0,
            )
            .order_by(Movement.seq)
        )
    )
    if not originals:
        raise HTTPException(status_code=404, detail="Operazione non trovata o non stornabile")
    done = _already_reversed(ctx, [m.id for m in originals])
    pending = [m for m in originals if m.id not in done]
    if not pending:
        raise HTTPException(status_code=409, detail="Operazione già stornata")
    containers = stock.lock_containers(ctx, [m.container_id for m in pending])
    now = datetime.now(UTC)
    reversals = [
        _reverse(ctx, m, containers[m.container_id], operation_id, payload.reason, now)
        for m in pending
    ]
    return _out(ctx, operation_id, "STORNO_OPERATION", reversals, [], reason=payload.reason)


def count_movements(ctx: Ctx) -> int:
    return ctx.db.scalar(
        select(func.count()).select_from(Movement).where(Movement.tenant_id == ctx.tenant_id)
    ) or 0
