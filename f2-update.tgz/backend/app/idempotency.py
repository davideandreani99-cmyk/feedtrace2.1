"""Operazioni idempotenti: id generato dal client, risposta riproposta ai tentativi ripetuti."""

import uuid
from collections.abc import Callable

from fastapi import HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from sqlalchemy.exc import IntegrityError

from app.deps import Ctx
from app.models import Operation


def run_idempotent(
    ctx: Ctx,
    operation_id: uuid.UUID | None,
    kind: str,
    build: Callable[[uuid.UUID], BaseModel],
):
    """Esegue `build(operation_id)` una sola volta per (tenant, operation_id).

    Un secondo invio con lo stesso id restituisce la risposta già prodotta (200),
    senza creare nuovi movimenti.
    """
    op_id = operation_id or uuid.uuid4()
    prior = ctx.db.get(Operation, (ctx.tenant_id, op_id))
    if prior is not None:
        return JSONResponse(prior.result, status_code=200)

    result = build(op_id)
    ctx.db.add(
        Operation(
            tenant_id=ctx.tenant_id,
            id=op_id,
            kind=kind,
            user_id=ctx.user.id,
            result=result.model_dump(mode="json"),
        )
    )
    try:
        ctx.db.flush()
    except IntegrityError as exc:  # richiesta gemella in corso
        ctx.db.rollback()
        raise HTTPException(
            status_code=409, detail="Operazione già in corso: riprova tra un istante"
        ) from exc
    ctx.db.commit()
    return result
