"""Schemi della Fase 2: ingressi, lotti, giacenze, movimenti, operazioni (RF-02, RF-03)."""

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field

from domain.enums import (
    CleaningType,
    ConsumptionPolicy,
    LotKind,
    LotStatus,
    MovementType,
)
from domain.units import InputUnit

Qty = Annotated[Decimal, Field(gt=0, max_digits=18, decimal_places=3)]
Reason = Annotated[str, Field(min_length=3, max_length=500)]


class WarningOut(BaseModel):
    code: str
    message: str


# --- lotti e ingressi --------------------------------------------------------------
class LotOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    kind: LotKind
    site_id: uuid.UUID
    internal_code: str
    material_id: uuid.UUID | None
    supplier_id: uuid.UUID | None
    supplier_lot: str | None
    entry_date: date | None
    ddt_number: str | None
    ddt_date: date | None
    plate: str | None
    initial_qty: Decimal | None
    price_eur_t: Decimal | None
    origin_country: str | None
    origin_region: str | None
    origin_province: str | None
    self_produced: bool
    typical_zone: bool
    expiry_date: date | None
    status: LotStatus
    receipt_id: uuid.UUID | None


class LotLocationOut(BaseModel):
    container_id: uuid.UUID
    container_code: str
    quantity: Decimal


class LotDetailOut(LotOut):
    containers: list[LotLocationOut]
    total: Decimal


class AllocationIn(BaseModel):
    container_id: uuid.UUID
    quantity: Qty


class ReceiptLineIn(BaseModel):
    material_id: uuid.UUID
    supplier_lot: str | None = Field(None, max_length=60)
    unit: InputUnit = InputUnit.KG
    allocations: list[AllocationIn] = Field(min_length=1)  # una riga DDT su più contenitori
    price_eur_t: Decimal | None = Field(None, ge=0, max_digits=18, decimal_places=4)
    origin_country: str | None = Field(None, max_length=60)
    origin_region: str | None = Field(None, max_length=60)
    origin_province: str | None = Field(None, max_length=60)
    self_produced: bool = False  # autoprodotta: ingresso senza fornitore, origine = sito
    typical_zone: bool = False
    expiry_date: date | None = None


class ReceiptIn(BaseModel):
    operation_id: uuid.UUID | None = None  # id generato dal client (idempotenza)
    site_id: uuid.UUID
    supplier_id: uuid.UUID | None = None
    ddt_number: str | None = Field(None, max_length=40)
    ddt_date: date | None = None
    plate: str | None = Field(None, max_length=20)
    occurred_at: datetime | None = None
    notes: str | None = Field(None, max_length=500)
    lines: list[ReceiptLineIn] = Field(min_length=1)


class ReceiptOut(BaseModel):
    id: uuid.UUID
    operation_id: uuid.UUID
    site_id: uuid.UUID
    supplier_id: uuid.UUID | None
    ddt_number: str | None
    ddt_date: date | None
    plate: str | None
    received_at: datetime
    notes: str | None
    lots: list[LotOut]
    warnings: list[WarningOut] = []


# --- movimenti e operazioni --------------------------------------------------------
class MovementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    occurred_at: datetime
    type: MovementType
    container_id: uuid.UUID
    lot_id: uuid.UUID
    quantity: Decimal
    operation_id: uuid.UUID
    doc_type: str | None
    doc_id: uuid.UUID | None
    reason: str | None
    closes_epoch: bool
    reverses_movement_id: uuid.UUID | None
    user_id: uuid.UUID | None


class MovementListOut(MovementOut):
    seq: int
    recorded_at: datetime


class OperationOut(BaseModel):
    operation_id: uuid.UUID
    movements: list[MovementOut]
    warnings: list[WarningOut] = []
    details: dict[str, str] = {}


class TransferIn(BaseModel):
    operation_id: uuid.UUID | None = None
    from_container_id: uuid.UUID
    to_container_id: uuid.UUID
    quantity: Qty
    unit: Literal["kg", "t"] = "kg"
    occurred_at: datetime | None = None
    reason: str | None = Field(None, max_length=500)


class OutflowIn(BaseModel):
    """Uscita non verso lotti di destinazione: vendita, reso, scarto (D6)."""

    operation_id: uuid.UUID | None = None
    container_id: uuid.UUID
    quantity: Qty
    unit: Literal["kg", "t"] = "kg"
    occurred_at: datetime | None = None
    reason: Reason


class InventoryIn(BaseModel):
    operation_id: uuid.UUID | None = None
    measured_quantity: Annotated[Decimal, Field(ge=0, max_digits=18, decimal_places=3)]
    unit: Literal["kg", "t"] = "kg"
    occurred_at: datetime | None = None
    reason: Reason  # la rettifica richiede motivazione


class CleaningIn(BaseModel):
    operation_id: uuid.UUID | None = None
    type: CleaningType
    after_medicated: bool = False
    occurred_at: datetime | None = None
    notes: str | None = Field(None, max_length=500)


class StornoIn(BaseModel):
    operation_id: uuid.UUID | None = None
    reason: Reason


# --- giacenze ----------------------------------------------------------------------
class StockLotOut(BaseModel):
    lot_id: uuid.UUID
    internal_code: str
    kind: LotKind
    material_id: uuid.UUID | None
    material_code: str | None
    material_name: str | None
    status: LotStatus
    quantity: Decimal


class StockOut(BaseModel):
    container_id: uuid.UUID
    code: str
    at: datetime | None
    unit: str
    capacity: Decimal | None
    consumption_policy: ConsumptionPolicy
    total: Decimal
    fill_pct: Decimal | None
    negative: bool
    medicated_contaminated: bool
    lots: list[StockLotOut]


class ContainerSummaryOut(BaseModel):
    container_id: uuid.UUID
    site_id: uuid.UUID
    code: str
    type: str
    unit: str
    capacity: Decimal | None
    consumption_policy: ConsumptionPolicy
    active: bool
    total: Decimal
    fill_pct: Decimal | None
    lots_count: int
    negative: bool
    medicated_contaminated: bool


class AnomalyOut(BaseModel):
    kind: str
    container_id: uuid.UUID
    container_code: str
    lot_id: uuid.UUID
    lot_code: str
    quantity: Decimal


class AttachmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    target_type: str
    target_id: uuid.UUID
    filename: str
    content_type: str
    size: int
