import { FormEvent, useCallback, useEffect, useState } from "react";
import { api } from "./api";

type Row = Record<string, unknown>;
type Warning = { code: string; message: string };

const fmt = (value: unknown): string => {
  const n = Number(value);
  return Number.isFinite(n)
    ? n.toLocaleString("it-IT", { minimumFractionDigits: 0, maximumFractionDigits: 3 })
    : "";
};
const dec = (text: string): string => text.trim().replace(",", ".");
const newId = (): string => crypto.randomUUID(); // id generato dal client: operazioni idempotenti
const errText = (e: unknown): string => (e instanceof Error ? e.message : "Errore");

function Warnings({ items }: { items: Warning[] }) {
  if (items.length === 0) return null;
  return (
    <ul className="warnings">
      {items.map((w, i) => (
        <li key={i}>⚠ {w.message}</li>
      ))}
    </ul>
  );
}

// ---------------------------------------------------------------- ingressi
interface LineForm {
  material_id: string;
  supplier_lot: string;
  unit: string;
  price_eur_t: string;
  origin_country: string;
  self_produced: boolean;
  allocations: { container_id: string; quantity: string }[];
}

const emptyLine = (): LineForm => ({
  material_id: "",
  supplier_lot: "",
  unit: "kg",
  price_eur_t: "",
  origin_country: "",
  self_produced: false,
  allocations: [{ container_id: "", quantity: "" }],
});

export function ReceiptsPage({ canWrite }: { canWrite: boolean }) {
  const [sites, setSites] = useState<Row[]>([]);
  const [suppliers, setSuppliers] = useState<Row[]>([]);
  const [materials, setMaterials] = useState<Row[]>([]);
  const [containers, setContainers] = useState<Row[]>([]);
  const [receipts, setReceipts] = useState<Row[]>([]);
  const [siteId, setSiteId] = useState("");
  const [supplierId, setSupplierId] = useState("");
  const [ddt, setDdt] = useState("");
  const [ddtDate, setDdtDate] = useState("");
  const [plate, setPlate] = useState("");
  const [lines, setLines] = useState<LineForm[]>([emptyLine()]);
  const [operationId, setOperationId] = useState(newId());
  const [warnings, setWarnings] = useState<Warning[]>([]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try {
      setSites(await api<Row[]>("/sites?active=true"));
      setSuppliers(await api<Row[]>("/suppliers?active=true"));
      setMaterials(await api<Row[]>("/raw-materials?active=true"));
      setContainers(await api<Row[]>("/containers?active=true"));
      setReceipts(await api<Row[]>("/receipts?limit=20"));
    } catch (e) {
      setError(errText(e));
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  const siteContainers = containers.filter((c) => c.site_id === siteId);
  const patchLine = (i: number, patch: Partial<LineForm>) =>
    setLines(lines.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setMessage("");
    const body = {
      operation_id: operationId,
      site_id: siteId,
      supplier_id: supplierId || null,
      ddt_number: ddt || null,
      ddt_date: ddtDate || null,
      plate: plate || null,
      lines: lines.map((l) => ({
        material_id: l.material_id,
        supplier_lot: l.supplier_lot || null,
        unit: l.unit,
        price_eur_t: l.price_eur_t ? dec(l.price_eur_t) : null,
        origin_country: l.origin_country || null,
        self_produced: l.self_produced,
        allocations: l.allocations.map((a) => ({
          container_id: a.container_id,
          quantity: dec(a.quantity),
        })),
      })),
    };
    try {
      const out = await api<{ lots: { internal_code: string }[]; warnings: Warning[] }>(
        "/receipts",
        { method: "POST", body: JSON.stringify(body) },
      );
      setWarnings(out.warnings);
      setMessage(`Ingresso registrato. Lotti: ${out.lots.map((l) => l.internal_code).join(", ")}`);
      setLines([emptyLine()]);
      setDdt("");
      setDdtDate("");
      setPlate("");
      setOperationId(newId()); // nuovo id solo dopo il successo: un nuovo invio non duplica
      await load();
    } catch (err) {
      setError(errText(err));
    }
  }

  const label = (rows: Row[], id: unknown, field: string) =>
    String(rows.find((r) => r.id === id)?.[field] ?? "");

  return (
    <section>
      <h2>Ingressi materie prime</h2>
      {error && <p className="error">{error}</p>}
      {message && <p className="ok">{message}</p>}
      <Warnings items={warnings} />
      {canWrite && (
        <form className="card" onSubmit={submit}>
          <div className="grid">
            <label>Sito
              <select value={siteId} required onChange={(e) => setSiteId(e.target.value)}>
                <option value="">Seleziona…</option>
                {sites.map((s) => <option key={String(s.id)} value={String(s.id)}>{String(s.name)}</option>)}
              </select>
            </label>
            <label>Fornitore
              <select value={supplierId} onChange={(e) => setSupplierId(e.target.value)}>
                <option value="">(autoprodotta)</option>
                {suppliers.map((s) => <option key={String(s.id)} value={String(s.id)}>{String(s.name)}</option>)}
              </select>
            </label>
            <label>N. DDT<input value={ddt} onChange={(e) => setDdt(e.target.value)} /></label>
            <label>Data DDT<input type="date" value={ddtDate} onChange={(e) => setDdtDate(e.target.value)} /></label>
            <label>Targa<input value={plate} onChange={(e) => setPlate(e.target.value)} /></label>
          </div>
          {lines.map((line, i) => (
            <fieldset key={i}>
              <legend>Riga {i + 1}</legend>
              <div className="grid">
                <label>Materia prima
                  <select value={line.material_id} required onChange={(e) => patchLine(i, { material_id: e.target.value })}>
                    <option value="">Seleziona…</option>
                    {materials.map((m) => <option key={String(m.id)} value={String(m.id)}>{String(m.code)} - {String(m.name)}</option>)}
                  </select>
                </label>
                <label>Lotto fornitore<input value={line.supplier_lot} onChange={(e) => patchLine(i, { supplier_lot: e.target.value })} /></label>
                <label>Unità
                  <select value={line.unit} onChange={(e) => patchLine(i, { unit: e.target.value })}>
                    <option>kg</option><option>t</option><option>l</option>
                  </select>
                </label>
                <label>Prezzo €/t<input inputMode="decimal" value={line.price_eur_t} onChange={(e) => patchLine(i, { price_eur_t: e.target.value })} /></label>
                <label>Paese di origine<input value={line.origin_country} onChange={(e) => patchLine(i, { origin_country: e.target.value })} /></label>
                <label>Autoprodotta
                  <input type="checkbox" checked={line.self_produced} onChange={(e) => patchLine(i, { self_produced: e.target.checked })} />
                </label>
              </div>
              {line.allocations.map((a, j) => (
                <div className="grid" key={j}>
                  <label>Contenitore
                    <select value={a.container_id} required onChange={(e) => patchLine(i, {
                      allocations: line.allocations.map((x, k) => (k === j ? { ...x, container_id: e.target.value } : x)),
                    })}>
                      <option value="">Seleziona…</option>
                      {siteContainers.map((c) => <option key={String(c.id)} value={String(c.id)}>{String(c.code)}</option>)}
                    </select>
                  </label>
                  <label>Quantità ({line.unit})
                    <input inputMode="decimal" required value={a.quantity} onChange={(e) => patchLine(i, {
                      allocations: line.allocations.map((x, k) => (k === j ? { ...x, quantity: e.target.value } : x)),
                    })} />
                  </label>
                </div>
              ))}
              <div className="row">
                <button type="button" className="secondary" onClick={() => patchLine(i, { allocations: [...line.allocations, { container_id: "", quantity: "" }] })}>
                  + Dividi su un altro contenitore
                </button>
                {lines.length > 1 && (
                  <button type="button" className="secondary" onClick={() => setLines(lines.filter((_, k) => k !== i))}>Rimuovi riga</button>
                )}
              </div>
            </fieldset>
          ))}
          <div className="row">
            <button type="button" className="secondary" onClick={() => setLines([...lines, emptyLine()])}>+ Aggiungi riga</button>
            <button type="submit">Registra ingresso</button>
          </div>
        </form>
      )}
      <h3>Ultimi ingressi</h3>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Data</th><th>DDT</th><th>Fornitore</th><th>Lotti</th></tr></thead>
          <tbody>
            {receipts.map((r) => (
              <tr key={String(r.id)}>
                <td>{String(r.received_at).slice(0, 16).replace("T", " ")}</td>
                <td>{String(r.ddt_number ?? "")}</td>
                <td>{label(suppliers, r.supplier_id, "name") || "autoprodotta"}</td>
                <td>{(r.lots as Row[]).map((l) => `${l.internal_code} (${l.status})`).join(", ")}</td>
              </tr>
            ))}
            {receipts.length === 0 && <tr><td colSpan={4}>Nessun ingresso.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------- contenitori
type Action = "" | "inventory" | "cleaning" | "transfer" | "outflow";

function ContainerDetail({
  container, perms, onChanged,
}: { container: Row; perms: string[]; onChanged: () => void }) {
  const id = String(container.container_id);
  const [at, setAt] = useState("");
  const [stock, setStock] = useState<Row | null>(null);
  const [moves, setMoves] = useState<Row[]>([]);
  const [others, setOthers] = useState<Row[]>([]);
  const [action, setAction] = useState<Action>("");
  const [operationId, setOperationId] = useState(newId());
  const [quantity, setQuantity] = useState("");
  const [reason, setReason] = useState("");
  const [cleanType, setCleanType] = useState("SVUOTAMENTO");
  const [target, setTarget] = useState("");
  const [warnings, setWarnings] = useState<Warning[]>([]);
  const [error, setError] = useState("");
  const canMove = perms.includes("movements:write");
  const canInventory = perms.includes("inventory:write");

  const load = useCallback(async () => {
    setError("");
    try {
      const query = at ? `?at=${encodeURIComponent(new Date(at).toISOString())}` : "";
      setStock(await api<Row>(`/containers/${id}/stock${query}`));
      setMoves(await api<Row[]>(`/movements?container_id=${id}&limit=15`));
      const all = await api<Row[]>("/stock/containers");
      setOthers(all.filter((c) => c.container_id !== id && c.site_id === container.site_id));
    } catch (e) {
      setError(errText(e));
    }
  }, [id, at, container.site_id]);
  useEffect(() => {
    void load();
  }, [load]);

  function open(next: Action) {
    setAction(next);
    setOperationId(newId());
    setQuantity("");
    setReason("");
    setWarnings([]);
    setError("");
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    let path = "";
    let body: Record<string, unknown> = { operation_id: operationId };
    if (action === "inventory") {
      path = `/containers/${id}/inventory`;
      body = { ...body, measured_quantity: dec(quantity), reason };
    } else if (action === "cleaning") {
      path = `/containers/${id}/cleanings`;
      body = { ...body, type: cleanType, notes: reason || null };
    } else if (action === "transfer") {
      path = "/transfers";
      body = { ...body, from_container_id: id, to_container_id: target, quantity: dec(quantity), reason: reason || null };
    } else if (action === "outflow") {
      path = "/outflows";
      body = { ...body, container_id: id, quantity: dec(quantity), reason };
    }
    try {
      const out = await api<{ warnings: Warning[] }>(path, { method: "POST", body: JSON.stringify(body) });
      setWarnings(out.warnings);
      setAction("");
      await load();
      onChanged();
    } catch (err) {
      setError(errText(err));
    }
  }

  async function storno(movementId: string) {
    const why = window.prompt("Motivazione dello storno (obbligatoria):");
    if (!why) return;
    try {
      await api(`/movements/${movementId}/storno`, {
        method: "POST",
        body: JSON.stringify({ operation_id: newId(), reason: why }),
      });
      await load();
      onChanged();
    } catch (err) {
      setError(errText(err));
    }
  }

  const lots = (stock?.lots as Row[] | undefined) ?? [];
  return (
    <div className="card">
      <h3>{String(container.code)} — {String(container.consumption_policy)}</h3>
      {error && <p className="error">{error}</p>}
      <Warnings items={warnings} />
      <label>Giacenza a una data (vuoto = adesso)
        <input type="datetime-local" value={at} onChange={(e) => setAt(e.target.value)} />
      </label>
      <p>Totale: <strong>{fmt(stock?.total)} kg</strong>{stock?.negative ? " ⚠ giacenza negativa" : ""}</p>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Lotto</th><th>Materia prima</th><th>Stato</th><th>kg</th></tr></thead>
          <tbody>
            {lots.map((l) => (
              <tr key={String(l.lot_id)}>
                <td>{String(l.internal_code)}</td>
                <td>{l.kind === "MISCELA" ? "miscela" : String(l.material_code ?? "non allocato")}</td>
                <td>{String(l.status)}</td>
                <td className={Number(l.quantity) < 0 ? "error" : ""}>{fmt(l.quantity)}</td>
              </tr>
            ))}
            {lots.length === 0 && <tr><td colSpan={4}>Vuoto.</td></tr>}
          </tbody>
        </table>
      </div>
      {!at && (canMove || canInventory) && (
        <div className="row">
          {canMove && <button className="secondary" onClick={() => open("outflow")}>Uscita (vendita/scarto)</button>}
          {canMove && <button className="secondary" onClick={() => open("transfer")}>Travaso</button>}
          {canInventory && <button className="secondary" onClick={() => open("inventory")}>Inventario</button>}
          {canInventory && <button className="secondary" onClick={() => open("cleaning")}>Svuota / pulisci</button>}
        </div>
      )}
      {action && (
        <form className="grid" onSubmit={submit}>
          {action === "cleaning" ? (
            <label>Tipo
              <select value={cleanType} onChange={(e) => setCleanType(e.target.value)}>
                <option>SVUOTAMENTO</option><option>PULIZIA</option><option>FLUSHING</option>
              </select>
            </label>
          ) : (
            <label>{action === "inventory" ? "Giacenza misurata (kg)" : "Quantità (kg)"}
              <input inputMode="decimal" required value={quantity} onChange={(e) => setQuantity(e.target.value)} />
            </label>
          )}
          {action === "transfer" && (
            <label>Verso
              <select value={target} required onChange={(e) => setTarget(e.target.value)}>
                <option value="">Seleziona…</option>
                {others.map((c) => <option key={String(c.container_id)} value={String(c.container_id)}>{String(c.code)}</option>)}
              </select>
            </label>
          )}
          <label>{action === "inventory" || action === "outflow" ? "Motivazione (obbligatoria)" : "Note"}
            <input value={reason} required={action === "inventory" || action === "outflow"} onChange={(e) => setReason(e.target.value)} />
          </label>
          <button type="submit">Conferma</button>
          <button type="button" className="secondary" onClick={() => setAction("")}>Annulla</button>
        </form>
      )}
      <h4>Ultimi movimenti</h4>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Data</th><th>Tipo</th><th>kg</th><th>Motivo</th><th /></tr></thead>
          <tbody>
            {moves.map((m) => (
              <tr key={String(m.id)}>
                <td>{String(m.occurred_at).slice(0, 16).replace("T", " ")}</td>
                <td>{String(m.type)}</td>
                <td>{fmt(m.quantity)}</td>
                <td>{String(m.reason ?? "")}</td>
                <td>
                  {canInventory && m.type !== "STORNO" && Number(m.quantity) !== 0 && (
                    <button className="secondary" onClick={() => void storno(String(m.id))}>Storna</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function ContainersPage({ perms }: { perms: string[] }) {
  const [rows, setRows] = useState<Row[]>([]);
  const [selected, setSelected] = useState<string>("");
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    try {
      setRows(await api<Row[]>("/stock/containers"));
    } catch (e) {
      setError(errText(e));
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  const current = rows.find((r) => r.container_id === selected);
  return (
    <section>
      <h2>Contenitori e giacenze</h2>
      {error && <p className="error">{error}</p>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Codice</th><th>Politica</th><th>Giacenza kg</th><th>Riempimento</th><th>Lotti</th><th>Stato</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={String(r.container_id)} className={r.container_id === selected ? "selected" : ""} onClick={() => setSelected(String(r.container_id))}>
                <td>{String(r.code)}</td>
                <td>{String(r.consumption_policy)}</td>
                <td>{fmt(r.total)}</td>
                <td>
                  {r.fill_pct === null ? "—" : (
                    <div className="bar" title={`${String(r.fill_pct)}%`}>
                      <div style={{ width: `${Math.min(100, Math.max(0, Number(r.fill_pct)))}%` }} />
                    </div>
                  )}
                </td>
                <td>{String(r.lots_count)}</td>
                <td>{r.negative ? "⚠ negativa" : ""}{r.medicated_contaminated ? " contaminato" : ""}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={6}>Nessun contenitore: creane uno in Anagrafiche.</td></tr>}
          </tbody>
        </table>
      </div>
      {current && <ContainerDetail key={selected} container={current} perms={perms} onChanged={() => void load()} />}
    </section>
  );
}

// ---------------------------------------------------------------- anomalie
export function AnomaliesPage() {
  const [rows, setRows] = useState<Row[]>([]);
  const [error, setError] = useState("");
  useEffect(() => {
    api<Row[]>("/anomalies").then(setRows).catch((e: Error) => setError(e.message));
  }, []);
  return (
    <section>
      <h2>Anomalie</h2>
      {error && <p className="error">{error}</p>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Tipo</th><th>Contenitore</th><th>Lotto</th><th>kg</th></tr></thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i}>
                <td>Giacenza negativa</td>
                <td>{String(r.container_code)}</td>
                <td>{String(r.lot_code)}</td>
                <td className="error">{fmt(r.quantity)}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={4}>Nessuna anomalia.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}
