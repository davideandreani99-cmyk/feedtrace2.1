import { FormEvent, Fragment, useCallback, useEffect, useState } from "react";
import { api } from "./api";

type Row = Record<string, unknown>;
type Warning = { code: string; message: string };

const fmt = (value: unknown): string => {
  const n = Number(value);
  return Number.isFinite(n)
    ? n.toLocaleString("it-IT", { minimumFractionDigits: 0, maximumFractionDigits: 3 })
    : "";
};
const dec = (text: string): string => text.trim().replace(",", ".");
const errText = (e: unknown): string => (e instanceof Error ? e.message : "Errore");

interface LineInput {
  actual: string;
  unit: string;
  container: string;
}

export function ProductionPage({ perms }: { perms: string[] }) {
  const canWrite = perms.includes("movements:write");
  const canStorno = perms.includes("inventory:write");
  const [plants, setPlants] = useState<Row[]>([]);
  const [recipes, setRecipes] = useState<Row[]>([]);
  const [materials, setMaterials] = useState<Row[]>([]);
  const [containers, setContainers] = useState<Row[]>([]);
  const [productions, setProductions] = useState<Row[]>([]);
  const [plantId, setPlantId] = useState("");
  const [recipeId, setRecipeId] = useState("");
  const [quantity, setQuantity] = useState("");
  const [unit, setUnit] = useState("t");
  const [destination, setDestination] = useState("");
  const [lineInputs, setLineInputs] = useState<Record<string, LineInput>>({});
  const [override, setOverride] = useState("");
  const [operationId, setOperationId] = useState(crypto.randomUUID());
  const [warnings, setWarnings] = useState<Warning[]>([]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [open, setOpen] = useState("");

  const load = useCallback(async () => {
    try {
      setPlants(await api<Row[]>("/plants?active=true"));
      setRecipes(await api<Row[]>("/recipes"));
      setMaterials(await api<Row[]>("/raw-materials?active=true"));
      setContainers(await api<Row[]>("/containers?active=true"));
      setProductions(await api<Row[]>("/productions?limit=30"));
    } catch (e) {
      setError(errText(e));
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  const plant = plants.find((p) => p.id === plantId);
  const eligibleRecipes = recipes.filter((r) => r.active !== false && (!plant || r.plant_type === plant.type));
  const recipe = recipes.find((r) => r.id === recipeId);
  const recipeLines = ((recipe?.lines as Row[] | undefined) ?? []);
  const siteContainers = containers.filter((c) => plant && c.site_id === plant.site_id && c.type !== "IMPIANTO");
  const material = (id: unknown) => materials.find((m) => m.id === id);
  const kgProduced = Number(dec(quantity) || 0) * (unit === "t" ? 1000 : 1);

  const patch = (materialId: string, change: Partial<LineInput>) =>
    setLineInputs({
      ...lineInputs,
      [materialId]: { actual: "", unit: "kg", container: "", ...lineInputs[materialId], ...change },
    });

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setMessage("");
    const lines = recipeLines
      .map((l) => {
        const input = lineInputs[String(l.material_id)];
        if (!input || (!input.actual && !input.container)) return null;
        return {
          material_id: l.material_id,
          container_id: input.container || null,
          actual_quantity: input.actual ? dec(input.actual) : null,
          unit: input.unit,
        };
      })
      .filter((l) => l !== null);
    const body = {
      operation_id: operationId,
      plant_id: plantId,
      recipe_id: recipeId,
      quantity: dec(quantity),
      unit,
      destination_container_id: destination || null,
      lines,
      override_reason: override || null,
    };
    try {
      const out = await api<{ mix_lot_code: string; warnings: Warning[] }>("/productions", {
        method: "POST",
        body: JSON.stringify(body),
      });
      setWarnings(out.warnings);
      setMessage(`Produzione registrata. Lotto miscela: ${out.mix_lot_code}`);
      setQuantity("");
      setLineInputs({});
      setOverride("");
      setOperationId(crypto.randomUUID());
      await load();
    } catch (err) {
      setError(errText(err));
    }
  }

  async function storno(id: string) {
    const why = window.prompt("Motivazione dello storno (obbligatoria):");
    if (!why) return;
    try {
      await api(`/productions/${id}/storno`, {
        method: "POST",
        body: JSON.stringify({ operation_id: crypto.randomUUID(), reason: why }),
      });
      await load();
    } catch (err) {
      setError(errText(err));
    }
  }

  return (
    <section>
      <h2>Produzione miscele</h2>
      {error && <p className="error">{error}</p>}
      {message && <p className="ok">{message}</p>}
      {warnings.length > 0 && (
        <ul className="warnings">{warnings.map((w, i) => <li key={i}>⚠ {w.message}</li>)}</ul>
      )}
      {canWrite && (
        <form className="card" onSubmit={submit}>
          <div className="grid">
            <label>Impianto
              <select value={plantId} required onChange={(e) => { setPlantId(e.target.value); setRecipeId(""); }}>
                <option value="">Seleziona…</option>
                {plants.map((p) => <option key={String(p.id)} value={String(p.id)}>{String(p.code)} ({String(p.type)})</option>)}
              </select>
            </label>
            <label>Ricetta
              <select value={recipeId} required onChange={(e) => { setRecipeId(e.target.value); setLineInputs({}); }}>
                <option value="">Seleziona…</option>
                {eligibleRecipes.map((r) => <option key={String(r.id)} value={String(r.id)}>{String(r.code)} v{String(r.version)} — {String(r.name)}</option>)}
              </select>
            </label>
            <label>Quantità da produrre
              <input inputMode="decimal" required value={quantity} onChange={(e) => setQuantity(e.target.value)} />
            </label>
            <label>Unità
              <select value={unit} onChange={(e) => setUnit(e.target.value)}><option>t</option><option>kg</option></select>
            </label>
            <label>Destinazione
              <select value={destination} onChange={(e) => setDestination(e.target.value)}>
                <option value="">Contenitore dell'impianto (scarico diretto)</option>
                {siteContainers.map((c) => <option key={String(c.id)} value={String(c.id)}>{String(c.code)}</option>)}
              </select>
            </label>
          </div>
          {recipe && (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Materia prima</th><th>kg/t</th><th>Teorica kg</th><th>Effettiva (opz.)</th><th>Unità</th><th>Prelievo da</th></tr></thead>
                <tbody>
                  {recipeLines.map((l) => {
                    const id = String(l.material_id);
                    const m = material(l.material_id);
                    const input = lineInputs[id];
                    return (
                      <tr key={id}>
                        <td>{String(m?.code ?? id)}</td>
                        <td>{fmt(l.kg_per_t)}</td>
                        <td>{fmt((Number(l.kg_per_t) * kgProduced) / 1000)}</td>
                        <td><input inputMode="decimal" value={input?.actual ?? ""} onChange={(e) => patch(id, { actual: e.target.value })} /></td>
                        <td>
                          <select value={input?.unit ?? "kg"} onChange={(e) => patch(id, { unit: e.target.value })}>
                            <option>kg</option><option>l</option>
                          </select>
                        </td>
                        <td>
                          {m?.lot_tracked === false ? "non tracciata" : (
                            <select value={input?.container ?? ""} onChange={(e) => patch(id, { container: e.target.value })}>
                              <option value="">{l.default_container_id ? "(da ricetta)" : "Seleziona…"}</option>
                              {siteContainers.map((c) => <option key={String(c.id)} value={String(c.id)}>{String(c.code)}</option>)}
                            </select>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
          <label>Override motivato (solo Responsabile, per lotti in quarantena o bloccati)
            <input value={override} onChange={(e) => setOverride(e.target.value)} />
          </label>
          <div className="row"><button type="submit">Registra produzione</button></div>
        </form>
      )}
      <h3>Ultime produzioni</h3>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Data</th><th>Ricetta</th><th>Lotto miscela</th><th>kg</th><th>Stato</th><th /></tr></thead>
          <tbody>
            {productions.map((p) => (
              <Fragment key={String(p.id)}>
                <tr onClick={() => setOpen(open === p.id ? "" : String(p.id))}>
                  <td>{String(p.started_at).slice(0, 16).replace("T", " ")}</td>
                  <td>{String(p.recipe_code)} v{String(p.recipe_version)}</td>
                  <td>{String(p.mix_lot_code)}</td>
                  <td>{fmt(p.actual_qty)}</td>
                  <td>{String(p.status)}{(p.overrides as unknown[]).length > 0 ? " · override" : ""}{(p.warnings as unknown[]).length > 0 ? " ⚠" : ""}</td>
                  <td>
                    {canStorno && p.status === "REGISTRATA" && (
                      <button className="secondary" onClick={(e) => { e.stopPropagation(); void storno(String(p.id)); }}>Storna</button>
                    )}
                  </td>
                </tr>
                {open === p.id && (
                  <tr>
                    <td colSpan={6}>
                      {(p.lines as Row[]).map((l, i) => (
                        <div key={i}>
                          <strong>{String(l.material_code)}</strong>: teorica {fmt(l.theoretical_qty)} kg, effettiva {fmt(l.actual_qty)} kg
                          {l.deviation_pct !== null ? ` (${String(l.deviation_pct)}%)` : ""}
                          {(l.allocations as Row[]).length > 0 && " ← " + (l.allocations as Row[]).map((a) => `${String(a.lot_code)} ${fmt(a.quantity)}`).join(", ")}
                        </div>
                      ))}
                      {(p.warnings as Warning[]).map((w, i) => <div key={i} className="error">⚠ {w.message}</div>)}
                    </td>
                  </tr>
                )}
              </Fragment>
            ))}
            {productions.length === 0 && <tr><td colSpan={6}>Nessuna produzione.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}
