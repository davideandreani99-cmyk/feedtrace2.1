"""Fase 3: produzioni, righe di produzione, legami di tracciabilita, lotti miscela.

Idempotente rispetto alle colonne (ADD COLUMN IF NOT EXISTS): le migrazioni 0001/0002 creano le
tabelle dai modelli correnti, quindi su un database nuovo le colonne esistono gia'.
NB: nessun carattere percento nelle istruzioni SQL (driver psycopg, nessun parametro).

Revision ID: 0003
Revises: 0002
"""

from alembic import op

from app.models import Base

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None

APP_ROLE = "feedtrace_app"
F3_TABLES = {"production", "production_line", "trace_link"}


def upgrade() -> None:
    bind = op.get_bind()

    def run(sql: str) -> None:
        bind.exec_driver_sql(sql)

    f3 = [t for t in Base.metadata.sorted_tables if t.name in F3_TABLES]
    Base.metadata.create_all(bind=bind, tables=f3)

    run("ALTER TABLE lot ADD COLUMN IF NOT EXISTS plant_id uuid REFERENCES plant(id)")
    run("ALTER TABLE lot ADD COLUMN IF NOT EXISTS recipe_id uuid REFERENCES recipe(id)")
    run("ALTER TABLE lot ADD COLUMN IF NOT EXISTS lot_date date")
    run("ALTER TABLE lot ADD COLUMN IF NOT EXISTS daily_key varchar(200)")
    run("ALTER TABLE lot ADD COLUMN IF NOT EXISTS medicated boolean NOT NULL DEFAULT false")
    run("ALTER TABLE container ADD COLUMN IF NOT EXISTS plant_id uuid REFERENCES plant(id)")
    run(
        "CREATE UNIQUE INDEX IF NOT EXISTS ix_lot_daily_key ON lot (tenant_id, daily_key) "
        "WHERE daily_key IS NOT NULL"
    )

    for table in f3:
        run(f"ALTER TABLE {table.name} ENABLE ROW LEVEL SECURITY")
        run(f"ALTER TABLE {table.name} FORCE ROW LEVEL SECURITY")
        run(f"DROP POLICY IF EXISTS tenant_isolation ON {table.name}")
        run(
            f"CREATE POLICY tenant_isolation ON {table.name} "
            "USING (tenant_id = app_current_tenant()) "
            "WITH CHECK (tenant_id = app_current_tenant())"
        )
        run(f"GRANT SELECT, INSERT, UPDATE ON {table.name} TO {APP_ROLE}")

    # Legami append-only: le correzioni sono righe con quantita' di segno opposto.
    run(f"REVOKE UPDATE ON trace_link FROM {APP_ROLE}")
    run("DROP TRIGGER IF EXISTS trace_link_immutable ON trace_link")
    run(
        "CREATE TRIGGER trace_link_immutable BEFORE UPDATE OR DELETE ON trace_link "
        "FOR EACH ROW EXECUTE FUNCTION prevent_mutation()"
    )


def downgrade() -> None:
    raise NotImplementedError("Downgrade non supportato")
