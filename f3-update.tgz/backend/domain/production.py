"""Regole di produzione delle miscele (RF-04, SPEC §6.4). Funzioni pure."""

import uuid
from collections.abc import Sequence
from datetime import date
from decimal import ROUND_HALF_UP, Decimal

from domain.enums import LotRule, LotStatus

_KG = Decimal("0.001")
_PCT = Decimal("0.01")
BLOCKED_STATUSES = frozenset(
    {LotStatus.IN_QUARANTENA, LotStatus.NON_CONFORME, LotStatus.BLOCCATO}
)


def theoretical_kg(kg_per_t: Decimal, produced_kg: Decimal) -> Decimal:
    """Quantità teorica di una riga: ricetta (kg per tonnellata) × quantità prodotta."""
    return (kg_per_t * produced_kg / 1000).quantize(_KG, rounding=ROUND_HALF_UP)


def deviation_pct(theoretical: Decimal, actual: Decimal) -> Decimal | None:
    if theoretical == 0:
        return None
    return ((actual - theoretical) / theoretical * 100).quantize(_PCT, rounding=ROUND_HALF_UP)


def exceeds_tolerance(deviation: Decimal | None, tolerance_pct: Decimal) -> bool:
    return deviation is not None and abs(deviation) > tolerance_pct


def recipe_valid_on(valid_from: date, valid_to: date | None, day: date) -> bool:
    return valid_from <= day and (valid_to is None or day <= valid_to)


def mix_lot_code(
    rule: LotRule,
    plant_code: str,
    day: date,
    recipe_code: str,
    version: int,
    progressive: int | None,
) -> str:
    """GIORNALIERO_PER_RICETTA: MX-{impianto}-{AAAAMMGG}-{ricetta}; PER_CICLO aggiunge il
    progressivo. Versioni diverse della stessa ricetta non confluiscono nello stesso lotto (D9)."""
    code = f"MX-{plant_code}-{day:%Y%m%d}-{recipe_code}"
    if version > 1:
        code += f"-V{version}"
    if rule == LotRule.PER_CICLO:
        if progressive is None:
            raise ValueError("Il lotto per ciclo richiede un progressivo")
        code += f"-{progressive:03d}"
    return code


def daily_key(plant_id: uuid.UUID, recipe_id: uuid.UUID, day: date) -> str:
    """Chiave univoca del lotto giornaliero: impianto + versione di ricetta + giorno."""
    return f"{plant_id}|{recipe_id}|{day.isoformat()}"


def blocked_lots(used: Sequence[tuple[str, LotStatus]]) -> list[tuple[str, str]]:
    """Lotti non utilizzabili in produzione (quarantena, non conforme, bloccato)."""
    return [(code, status.value) for code, status in used if status in BLOCKED_STATUSES]


def medicated_errors(
    recipe_medicated: bool,
    plant_authorized: bool,
    plant_contaminated: bool,
    rev_valid: bool,
) -> list[str]:
    """Blocchi sui medicati (SPEC §6.4/§6.9). Messaggi per l'utente, in italiano."""
    errors: list[str] = []
    if recipe_medicated:
        if not plant_authorized:
            errors.append("L'impianto non è autorizzato alla produzione di mangimi medicati")
        if not rev_valid:
            errors.append("Ricetta medicata: serve una REV valida collegata alla produzione")
    elif plant_contaminated:
        errors.append(
            "L'impianto è contaminato da medicato: registra una pulizia/flushing prima di "
            "produrre una ricetta non medicata"
        )
    return errors
