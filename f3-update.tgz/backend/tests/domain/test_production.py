"""Regole di produzione (RF-04): quantità teoriche, scostamenti, lotto miscela, blocchi."""

import uuid
from datetime import date
from decimal import Decimal as D

import pytest

from domain.enums import LotRule, LotStatus
from domain.production import (
    blocked_lots,
    daily_key,
    deviation_pct,
    exceeds_tolerance,
    medicated_errors,
    mix_lot_code,
    recipe_valid_on,
    theoretical_kg,
)


# --- quantità teoriche e scostamenti ----------------------------------------------
def test_quantita_teorica_da_ricetta_per_tonnellata():
    assert theoretical_kg(D("650"), D("12000")) == D("7800.000")
    assert theoretical_kg(D("0.333"), D("1000")) == D("0.333")
    assert theoretical_kg(D("1"), D("1")) == D("0.001")


def test_scostamento_percentuale():
    assert deviation_pct(D("1000"), D("1050")) == D("5.00")
    assert deviation_pct(D("1000"), D("950")) == D("-5.00")
    assert deviation_pct(D("0"), D("10")) is None


def test_scostamento_oltre_tolleranza():
    assert exceeds_tolerance(D("5.01"), D("5")) is True
    assert exceeds_tolerance(D("-6"), D("5")) is True
    assert exceeds_tolerance(D("5"), D("5")) is False
    assert exceeds_tolerance(None, D("5")) is False


# --- validità ricetta --------------------------------------------------------------
def test_validita_ricetta():
    assert recipe_valid_on(date(2026, 1, 1), None, date(2026, 6, 1))
    assert recipe_valid_on(date(2026, 1, 1), date(2026, 3, 31), date(2026, 3, 31))
    assert not recipe_valid_on(date(2026, 1, 1), date(2026, 3, 31), date(2026, 4, 1))
    assert not recipe_valid_on(date(2026, 3, 1), None, date(2026, 2, 28))
    # versione sostituita lo stesso giorno: mai in vigore
    assert not recipe_valid_on(date(2026, 3, 1), date(2026, 2, 28), date(2026, 3, 1))


# --- lotto miscela per impianto (SPEC §6.4, D9, D14) --------------------------------
def test_codice_lotto_giornaliero_per_ricetta():
    code = mix_lot_code(LotRule.GIORNALIERO_PER_RICETTA, "BRO1", date(2026, 3, 10), "R1", 1, None)
    assert code == "MX-BRO1-20260310-R1"


def test_codice_lotto_giornaliero_versione_diversa_lotto_diverso():
    v1 = mix_lot_code(LotRule.GIORNALIERO_PER_RICETTA, "BRO1", date(2026, 3, 10), "R1", 1, None)
    v2 = mix_lot_code(LotRule.GIORNALIERO_PER_RICETTA, "BRO1", date(2026, 3, 10), "R1", 2, None)
    assert v1 != v2 and v2.endswith("-V2")


def test_codice_lotto_per_ciclo_ha_progressivo():
    code = mix_lot_code(LotRule.PER_CICLO, "MIX1", date(2026, 3, 10), "R1", 1, 7)
    assert code == "MX-MIX1-20260310-R1-007"
    with pytest.raises(ValueError):
        mix_lot_code(LotRule.PER_CICLO, "MIX1", date(2026, 3, 10), "R1", 1, None)


def test_chiave_giornaliera_distingue_impianto_ricetta_giorno():
    p1, p2, r1, r2 = (uuid.uuid4() for _ in range(4))
    day = date(2026, 3, 10)
    assert daily_key(p1, r1, day) == daily_key(p1, r1, day)
    assert len({daily_key(p1, r1, day), daily_key(p2, r1, day), daily_key(p1, r2, day),
                daily_key(p1, r1, date(2026, 3, 11))}) == 4


# --- blocchi sui lotti (SPEC §6.4 / §6.8) ------------------------------------------
def test_lotti_bloccati_in_produzione():
    used = [("L1", LotStatus.DISPONIBILE), ("L2", LotStatus.IN_QUARANTENA),
            ("L3", LotStatus.NON_CONFORME), ("L4", LotStatus.BLOCCATO), ("L5", LotStatus.ESAURITO)]
    assert blocked_lots(used) == [("L2", "IN_QUARANTENA"), ("L3", "NON_CONFORME"),
                                  ("L4", "BLOCCATO")]
    assert blocked_lots([("L1", LotStatus.DISPONIBILE)]) == []


# --- medicati (SPEC §6.4, §6.9) -----------------------------------------------------
def test_ricetta_non_medicata_su_impianto_pulito_nessun_errore():
    assert medicated_errors(False, False, False, rev_valid=False) == []


def test_ricetta_medicata_richiede_impianto_autorizzato_e_rev_valida():
    errors = medicated_errors(True, False, False, rev_valid=False)
    assert len(errors) == 2
    assert medicated_errors(True, True, False, rev_valid=True) == []
    assert len(medicated_errors(True, True, False, rev_valid=False)) == 1


def test_ricetta_non_medicata_su_impianto_contaminato_bloccata():
    errors = medicated_errors(False, True, True, rev_valid=False)
    assert len(errors) == 1 and "pulizia" in errors[0]
    assert medicated_errors(True, True, True, rev_valid=True) == []
