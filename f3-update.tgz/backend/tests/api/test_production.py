"""Fase 3 (RF-04): produzione delle miscele, regola del lotto per impianto, blocchi, legami."""

import uuid
from datetime import UTC, datetime, timedelta
from decimal import Decimal as D

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session

from app.db import SessionLocal, admin_engine
from app.models import Plant
from tests.api.conftest import API, create_material, create_site
from tests.api.test_stock import (
    create_container,
    create_supplier,
    get_stock,
    post_op,
    post_receipt,
    qty_by_code,
)


# --- helper ------------------------------------------------------------------------
def create_plant(client, acc, site, ptype="MISCELATORE_BATCH", rule="PER_CICLO", code=None, **extra):
    body = {"site_id": site["id"], "code": code or f"P{uuid.uuid4().hex[:4]}", "name": "Impianto",
            "type": ptype, "lot_rule": rule, **extra}
    r = client.post(f"{API}/plants", json=body, headers=acc.headers)
    assert r.status_code == 201, r.text
    return r.json()


def create_recipe(client, acc, code, lines, ptype="MISCELATORE_BATCH", **extra):
    """lines: [(materia, kg_per_t, contenitore|None, dict extra)]"""
    body = {"code": code, "name": f"Ricetta {code}", "plant_type": ptype, "phase": "INGRASSO",
            "lines": [], **extra}
    for item in lines:
        material, kg, container = item[0], item[1], item[2]
        line = {"material_id": material["id"], "kg_per_t": str(kg)}
        if container:
            line["default_container_id"] = container["id"]
        if len(item) > 3:
            line.update(item[3])
        body["lines"].append(line)
    r = client.post(f"{API}/recipes", json=body, headers=acc.headers)
    assert r.status_code == 201, r.text
    return r.json()


def produce(client, acc, plant, recipe, quantity, unit="t", **extra):
    body = {"plant_id": plant["id"], "recipe_id": recipe["id"], "quantity": str(quantity),
            "unit": unit, "operation_id": str(uuid.uuid4()), **extra}
    return client.post(f"{API}/productions", json=body, headers=acc.headers)


def links(client, acc, lot_id):
    r = client.get(f"{API}/lots/{lot_id}/links", headers=acc.headers)
    assert r.status_code == 200, r.text
    return r.json()


def today():
    from zoneinfo import ZoneInfo
    return datetime.now(ZoneInfo("Europe/Rome")).strftime("%Y%m%d")


@pytest.fixture
def mill(client, make_account):
    """Azienda con mangimificio: sito, mais e soia caricati in due silos, silo di prodotto finito."""
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    mais, soia = create_material(client, acc, code="MAIS"), create_material(client, acc, code="SOIA")
    silo_mais = create_container(client, acc, site, code="SILO-MAIS")
    silo_soia = create_container(client, acc, site, code="SILO-SOIA")
    product = create_container(client, acc, site, code="SILO-PF")
    assert post_receipt(client, acc, site, silo_mais, mais, "20", supplier, unit="t").status_code == 201
    assert post_receipt(client, acc, site, silo_soia, soia, "10", supplier, unit="t").status_code == 201
    plant = create_plant(client, acc, site, code="MIX1")
    recipe = create_recipe(client, acc, "R1", [(mais, 700, silo_mais), (soia, 300, silo_soia)])
    return {"acc": acc, "site": site, "supplier": supplier, "mais": mais, "soia": soia,
            "silo_mais": silo_mais, "silo_soia": silo_soia, "product": product, "plant": plant,
            "recipe": recipe}


# --- produzione di base (batch) -----------------------------------------------------
def test_produzione_batch_consuma_le_materie_prime_e_carica_il_prodotto_finito(client, mill):
    m = mill
    r = produce(client, m["acc"], m["plant"], m["recipe"], 2, destination_container_id=m["product"]["id"])
    assert r.status_code == 201, r.text
    out = r.json()
    assert D(out["actual_qty"]) == D("2000") and out["status"] == "REGISTRATA"
    assert out["mix_lot_code"] == f"MX-MIX1-{today()}-R1-001"
    lines = {line["material_code"]: line for line in out["lines"]}
    assert D(lines["MAIS"]["theoretical_qty"]) == D("1400") and D(lines["SOIA"]["actual_qty"]) == D("600")
    assert D(get_stock(client, m["acc"], m["silo_mais"])["total"]) == D("18600")
    assert D(get_stock(client, m["acc"], m["silo_soia"])["total"]) == D("9400")
    product = get_stock(client, m["acc"], m["product"])
    assert D(product["total"]) == D("2000") and product["lots"][0]["kind"] == "MISCELA"
    mix_lots = client.get(f"{API}/lots", params={"kind": "MISCELA"}, headers=m["acc"].headers).json()
    assert [lot["internal_code"] for lot in mix_lots] == [out["mix_lot_code"]]
    assert mix_lots[0]["plant_id"] == m["plant"]["id"] and D(mix_lots[0]["initial_qty"]) == D("2000")


def test_per_ciclo_ogni_produzione_un_nuovo_lotto(client, mill):
    m = mill
    codes = [produce(client, m["acc"], m["plant"], m["recipe"], 1,
                     destination_container_id=m["product"]["id"]).json()["mix_lot_code"]
             for _ in range(3)]
    assert [c.rsplit("-", 1)[1] for c in codes] == ["001", "002", "003"]


# --- §7: lotto giornaliero per ricetta ----------------------------------------------
def test_lotto_giornaliero_3_cicli_R1_e_1_ciclo_R2_due_lotti_miscela(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    mais = create_material(client, acc, code="MAIS")
    silo = create_container(client, acc, site, code="SILO-M")
    tank = create_container(client, acc, site, code="VASCA")
    post_receipt(client, acc, site, silo, mais, "50", supplier, unit="t")
    plant = create_plant(client, acc, site, ptype="BRODA", rule="GIORNALIERO_PER_RICETTA", code="BRO")
    r1 = create_recipe(client, acc, "R1", [(mais, 1000, silo)], ptype="BRODA")
    r2 = create_recipe(client, acc, "R2", [(mais, 1000, silo)], ptype="BRODA")
    outs = [produce(client, acc, plant, r1, 2, destination_container_id=tank["id"]).json()
            for _ in range(3)]
    outs.append(produce(client, acc, plant, r2, 1, destination_container_id=tank["id"]).json())
    assert outs[0]["mix_lot_id"] == outs[1]["mix_lot_id"] == outs[2]["mix_lot_id"]
    assert outs[3]["mix_lot_id"] != outs[0]["mix_lot_id"]
    assert outs[0]["mix_lot_code"] == f"MX-BRO-{today()}-R1"
    assert outs[3]["mix_lot_code"] == f"MX-BRO-{today()}-R2"
    mix_lots = client.get(f"{API}/lots", params={"kind": "MISCELA"}, headers=acc.headers).json()
    assert len(mix_lots) == 2
    by_code = {lot["internal_code"]: D(lot["initial_qty"]) for lot in mix_lots}
    assert by_code[f"MX-BRO-{today()}-R1"] == D("6000") and by_code[f"MX-BRO-{today()}-R2"] == D("1000")
    assert qty_by_code(get_stock(client, acc, tank)) == {
        f"MX-BRO-{today()}-R1": D("6000"), f"MX-BRO-{today()}-R2": D("1000")}


def test_nuova_versione_di_ricetta_stesso_giorno_nuovo_lotto(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    mais = create_material(client, acc, code="MAIS")
    silo = create_container(client, acc, site)
    post_receipt(client, acc, site, silo, mais, "20", supplier, unit="t")
    plant = create_plant(client, acc, site, ptype="BRODA", rule="GIORNALIERO_PER_RICETTA", code="BRO")
    v1 = create_recipe(client, acc, "R1", [(mais, 1000, silo)], ptype="BRODA")
    first = produce(client, acc, plant, v1, 1).json()
    body = {"code": "R1", "name": "Ricetta R1", "plant_type": "BRODA",
            "lines": [{"material_id": mais["id"], "kg_per_t": "1000",
                       "default_container_id": silo["id"]}]}
    v2 = client.put(f"{API}/recipes/{v1['id']}", json=body, headers=acc.headers).json()
    second = produce(client, acc, plant, v2, 1).json()
    assert second["mix_lot_id"] != first["mix_lot_id"]
    assert second["mix_lot_code"] == f"MX-BRO-{today()}-R1-V2" and second["recipe_version"] == 2
    # la versione 1 non è più in vigore: non si può usare per nuove produzioni
    assert produce(client, acc, plant, v1, 1).status_code == 422
    # la produzione passata resta legata alla versione usata
    old = client.get(f"{API}/productions/{first['id']}", headers=acc.headers).json()
    assert old["recipe_version"] == 1


# --- §7: quarantena e override ------------------------------------------------------
def quarantine_setup(client, mill):
    m = mill
    soia_q = create_material(client, m["acc"], code="SOIAQ", requires_analysis=True)
    silo = create_container(client, m["acc"], m["site"], code="SILO-Q")
    r = post_receipt(client, m["acc"], m["site"], silo, soia_q, "5", m["supplier"], unit="t")
    assert r.json()["lots"][0]["status"] == "IN_QUARANTENA"
    recipe = create_recipe(client, m["acc"], "RQ", [(soia_q, 1000, silo)])
    return silo, recipe


def test_lotto_in_quarantena_usato_in_produzione_errore(client, mill):
    m = mill
    silo, recipe = quarantine_setup(client, mill)
    r = produce(client, m["acc"], m["plant"], recipe, 1, destination_container_id=m["product"]["id"])
    assert r.status_code == 422 and "IN_QUARANTENA" in r.json()["detail"]
    assert D(get_stock(client, m["acc"], silo)["total"]) == D("5000")  # nulla è stato consumato
    assert get_stock(client, m["acc"], m["product"])["lots"] == []


def test_override_del_responsabile_produzione_registrata_con_flag_e_audit(client, mill, make_account):
    m = mill
    silo, recipe = quarantine_setup(client, mill)
    operatore = make_account("OPERATORE", m["acc"].tenant_id)
    r = produce(client, operatore, m["plant"], recipe, 1, override_reason="Analisi in arrivo",
                destination_container_id=m["product"]["id"])
    assert r.status_code == 403
    responsabile = make_account("RESPONSABILE", m["acc"].tenant_id)
    no_reason = produce(client, responsabile, m["plant"], recipe, 1,
                        destination_container_id=m["product"]["id"])
    assert no_reason.status_code == 422
    r = produce(client, responsabile, m["plant"], recipe, 1, override_reason="Analisi in arrivo",
                destination_container_id=m["product"]["id"])
    assert r.status_code == 201, r.text
    out = r.json()
    assert out["overrides"][0]["reason"] == "Analisi in arrivo"
    assert out["overrides"][0]["type"] == "BLOCKED_LOTS"
    assert "OVERRIDE" in [w["code"] for w in out["warnings"]]
    assert D(get_stock(client, m["acc"], silo)["total"]) == D("4000")
    audit = client.get(f"{API}/audit-log", params={"entity": "productions"}, headers=m["acc"].headers).json()
    assert "OVERRIDE" in [a["action"] for a in audit]


# --- medicati (aggancio REV in Fase 6) ----------------------------------------------
def test_ricetta_medicata_bloccata_senza_rev_e_impianto_non_autorizzato(client, mill):
    m = mill
    medicated = create_recipe(client, m["acc"], "RM", [(m["mais"], 1000, m["silo_mais"])],
                              medicated=True)
    r = produce(client, m["acc"], m["plant"], medicated, 1, destination_container_id=m["product"]["id"])
    assert r.status_code == 422
    assert "non è autorizzato" in r.json()["detail"] and "REV" in r.json()["detail"]
    authorized = create_plant(client, m["acc"], m["site"], medicated_authorized=True)
    r = produce(client, m["acc"], authorized, medicated, 1, destination_container_id=m["product"]["id"])
    assert r.status_code == 422 and "REV" in r.json()["detail"]
    assert "non è autorizzato" not in r.json()["detail"]


def test_impianto_contaminato_blocca_ricetta_non_medicata(client, mill):
    m = mill
    with Session(admin_engine) as db:
        plant = db.get(Plant, uuid.UUID(m["plant"]["id"]))
        plant.medicated_contaminated = True
        db.commit()
    r = produce(client, m["acc"], m["plant"], m["recipe"], 1, destination_container_id=m["product"]["id"])
    assert r.status_code == 422 and "pulizia" in r.json()["detail"]


# --- scostamenti, acqua, litri -------------------------------------------------------
def test_scostamento_oltre_tolleranza_avviso_registrato(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    mais = create_material(client, acc, code="MAIS")
    silo = create_container(client, acc, site)
    post_receipt(client, acc, site, silo, mais, "20", supplier, unit="t")
    plant = create_plant(client, acc, site, tolerance_pct="2")
    recipe = create_recipe(client, acc, "R1", [(mais, 1000, silo)])
    ok = produce(client, acc, plant, recipe, 1, lines=[{"material_id": mais["id"], "actual_quantity": "1015"}])
    assert [w["code"] for w in ok.json()["warnings"]] == []
    bad = produce(client, acc, plant, recipe, 1, lines=[{"material_id": mais["id"], "actual_quantity": "1050"}])
    assert bad.status_code == 201
    warning = [w for w in bad.json()["warnings"] if w["code"] == "DEVIATION"]
    assert len(warning) == 1 and "MAIS" in warning[0]["message"]
    line = bad.json()["lines"][0]
    assert D(line["deviation_pct"]) == D("5.00")
    stored = client.get(f"{API}/productions/{bad.json()['id']}", headers=acc.headers).json()
    assert [w["code"] for w in stored["warnings"]] == ["DEVIATION"]


def test_acqua_non_tracciata_a_lotto_senza_contenitore(client, mill):
    m = mill
    acqua = create_material(client, m["acc"], code="H2O", type="ACQUA", lot_tracked=False)
    recipe = create_recipe(client, m["acc"], "RW", [(m["mais"], 900, m["silo_mais"]), (acqua, 100, None)])
    r = produce(client, m["acc"], m["plant"], recipe, 1, destination_container_id=m["product"]["id"])
    assert r.status_code == 201, r.text
    water = next(line for line in r.json()["lines"] if line["material_code"] == "H2O")
    assert water["allocations"] == [] and water["container_id"] is None
    assert D(water["actual_qty"]) == D("100")


def test_ingrediente_liquido_in_litri_convertito_con_la_densita(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    siero = create_material(client, acc, code="SIERO", type="LIQUIDO", unit="l", density_kg_l="1.025")
    cisterna = create_container(client, acc, site, code="CIST")
    post_receipt(client, acc, site, cisterna, siero, "5000", supplier, unit="l")  # 5125 kg
    plant = create_plant(client, acc, site, ptype="BRODA", rule="GIORNALIERO_PER_RICETTA")
    recipe = create_recipe(client, acc, "RB", [(siero, 100, cisterna)], ptype="BRODA")
    r = produce(client, acc, plant, recipe, 1, lines=[
        {"material_id": siero["id"], "actual_quantity": "100", "unit": "l"}])
    assert r.status_code == 201, r.text
    assert D(r.json()["lines"][0]["actual_qty"]) == D("102.500")
    assert D(get_stock(client, acc, cisterna)["total"]) == D("5125") - D("102.5")


# --- legami di tracciabilità (CERTI / POSSIBILI) --------------------------------------
def single_ingredient_mill(client, acc, policy):
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    mais = create_material(client, acc, code="MAIS")
    silo = create_container(client, acc, site, policy=policy)
    post_receipt(client, acc, site, silo, mais, "10", supplier, unit="t")   # lotto A
    post_receipt(client, acc, site, silo, mais, "5", supplier, unit="t")    # lotto B
    plant = create_plant(client, acc, site)
    recipe = create_recipe(client, acc, "R1", [(mais, 1000, silo)])
    product = create_container(client, acc, site, code="PF")
    return plant, recipe, product, silo


def test_legami_fifo_10t_da_A_e_2t_da_B(client, make_account):
    acc = make_account("ADMIN")
    plant, recipe, product, silo = single_ingredient_mill(client, acc, "FIFO")
    out = produce(client, acc, plant, recipe, 12, destination_container_id=product["id"]).json()
    sources = links(client, acc, out["mix_lot_id"])["sources"]
    assert sorted((s["kind"], D(s["quantity"])) for s in sources) == [
        ("CERTO", D("2000")), ("CERTO", D("10000"))]
    # in avanti dal lotto A: il lotto miscela
    first_lot = max(sources, key=lambda s: D(s["quantity"]))["lot_id"]
    targets = links(client, acc, first_lot)["targets"]
    assert [(t["lot_id"], t["kind"], D(t["quantity"])) for t in targets] == [
        (out["mix_lot_id"], "CERTO", D("10000"))]
    assert D(get_stock(client, acc, silo)["total"]) == D("3000")


def test_legami_proporzionale(client, make_account):
    acc = make_account("ADMIN")
    plant, recipe, product, _ = single_ingredient_mill(client, acc, "PROPORZIONALE")
    out = produce(client, acc, plant, recipe, 6, destination_container_id=product["id"]).json()
    sources = links(client, acc, out["mix_lot_id"])["sources"]
    assert sorted(D(s["quantity"]) for s in sources) == [D("2000"), D("4000")]
    assert {s["kind"] for s in sources} == {"CERTO"}


def test_legami_tutti_presenti_certi_e_possibili(client, make_account):
    acc = make_account("ADMIN")
    plant, recipe, product, _ = single_ingredient_mill(client, acc, "TUTTI_PRESENTI")
    out = produce(client, acc, plant, recipe, 6, destination_container_id=product["id"]).json()
    sources = links(client, acc, out["mix_lot_id"])["sources"]
    certain = [s for s in sources if s["kind"] == "CERTO"]
    possible = [s for s in sources if s["kind"] == "POSSIBILE"]
    assert sorted(D(s["quantity"]) for s in certain) == [D("2000"), D("4000")]
    assert len(possible) == 2 and sum(D(s["quantity"]) for s in possible) == D("6000")


def test_prelievo_da_contenitore_vuoto_giacenza_negativa_con_avviso(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    mais = create_material(client, acc, code="MAIS")
    silo = create_container(client, acc, site)
    plant = create_plant(client, acc, site)
    recipe = create_recipe(client, acc, "R1", [(mais, 1000, silo)])
    r = produce(client, acc, plant, recipe, 1)
    assert r.status_code == 201, r.text
    assert "NEGATIVE_STOCK" in [w["code"] for w in r.json()["warnings"]]
    stock = get_stock(client, acc, silo)
    assert stock["negative"] is True and D(stock["total"]) == D("-1000")
    sources = links(client, acc, r.json()["mix_lot_id"])["sources"]
    assert len(sources) == 1 and D(sources[0]["quantity"]) == D("1000")


# --- impianto come contenitore virtuale (D10) ----------------------------------------
def test_senza_destinazione_la_miscela_va_nel_contenitore_dell_impianto(client, mill):
    m = mill
    r = produce(client, m["acc"], m["plant"], m["recipe"], 1)
    assert r.status_code == 201, r.text
    virtual_id = r.json()["destination_container_id"]
    stock = client.get(f"{API}/containers/{virtual_id}/stock", headers=m["acc"].headers).json()
    assert stock["code"] == "IMP-MIX1" and D(stock["total"]) == D("1000")
    again = produce(client, m["acc"], m["plant"], m["recipe"], 1).json()
    assert again["destination_container_id"] == virtual_id  # sempre lo stesso contenitore
    containers = client.get(f"{API}/containers", headers=m["acc"].headers).json()
    assert [c["type"] for c in containers if c["id"] == virtual_id] == ["IMPIANTO"]


# --- idempotenza e storno ------------------------------------------------------------
def test_produzione_idempotente(client, mill):
    m = mill
    op = str(uuid.uuid4())
    body = {"plant_id": m["plant"]["id"], "recipe_id": m["recipe"]["id"], "quantity": "1", "unit": "t",
            "operation_id": op, "destination_container_id": m["product"]["id"]}
    first = client.post(f"{API}/productions", json=body, headers=m["acc"].headers)
    second = client.post(f"{API}/productions", json=body, headers=m["acc"].headers)
    assert first.status_code == 201 and second.status_code == 200
    assert second.json() == first.json()
    assert D(get_stock(client, m["acc"], m["silo_mais"])["total"]) == D("19300")
    assert len(client.get(f"{API}/productions", headers=m["acc"].headers).json()) == 1


def test_storno_produzione_ripristina_giacenze_e_compensa_i_legami(client, mill, make_account):
    m = mill
    out = produce(client, m["acc"], m["plant"], m["recipe"], 2,
                  destination_container_id=m["product"]["id"]).json()
    operatore = make_account("OPERATORE", m["acc"].tenant_id)
    assert post_op(client, operatore, f"/productions/{out['id']}/storno", {"reason": "errore"}).status_code == 403
    r = post_op(client, m["acc"], f"/productions/{out['id']}/storno", {"reason": "Produzione registrata per errore"})
    assert r.status_code == 201, r.text
    assert r.json()["status"] == "STORNATA"
    assert D(get_stock(client, m["acc"], m["silo_mais"])["total"]) == D("20000")
    assert D(get_stock(client, m["acc"], m["silo_soia"])["total"]) == D("10000")
    assert get_stock(client, m["acc"], m["product"])["lots"] == []
    assert links(client, m["acc"], out["mix_lot_id"])["sources"] == []  # legami compensati a zero
    lot = client.get(f"{API}/lots/{out['mix_lot_id']}", headers=m["acc"].headers).json()
    assert D(lot["initial_qty"]) == D("0")
    assert post_op(client, m["acc"], f"/productions/{out['id']}/storno", {"reason": "di nuovo"}).status_code == 409


# --- validazioni ----------------------------------------------------------------------
def test_ricetta_non_ancora_valida(client, mill):
    m = mill
    future = (datetime.now(UTC) + timedelta(days=10)).date().isoformat()
    recipe = create_recipe(client, m["acc"], "RF", [(m["mais"], 1000, m["silo_mais"])], valid_from=future)
    r = produce(client, m["acc"], m["plant"], recipe, 1, destination_container_id=m["product"]["id"])
    assert r.status_code == 422 and "non è valida" in r.json()["detail"]


def test_tipo_impianto_non_coerente_con_la_ricetta(client, mill):
    m = mill
    broda_recipe = create_recipe(client, m["acc"], "RB", [(m["mais"], 1000, m["silo_mais"])], ptype="BRODA")
    r = produce(client, m["acc"], m["plant"], broda_recipe, 1)
    assert r.status_code == 422 and "BRODA" in r.json()["detail"]


def test_contenitore_di_prelievo_mancante(client, mill):
    m = mill
    recipe = create_recipe(client, m["acc"], "RN", [(m["mais"], 1000, None)])
    r = produce(client, m["acc"], m["plant"], recipe, 1)
    assert r.status_code == 422 and "Contenitore di prelievo mancante" in r.json()["detail"]
    ok = produce(client, m["acc"], m["plant"], recipe, 1, lines=[
        {"material_id": m["mais"]["id"], "container_id": m["silo_mais"]["id"]}])
    assert ok.status_code == 201, ok.text


def test_riga_non_appartenente_alla_ricetta(client, mill):
    m = mill
    other = create_material(client, m["acc"], code="ALTRO")
    r = produce(client, m["acc"], m["plant"], m["recipe"], 1, lines=[
        {"material_id": other["id"], "actual_quantity": "5"}])
    assert r.status_code == 422


# --- permessi e isolamento ------------------------------------------------------------
def test_permessi_e_isolamento_tra_aziende(client, mill, make_account):
    m = mill
    auditor = make_account("AUDITOR", m["acc"].tenant_id)
    assert produce(client, auditor, m["plant"], m["recipe"], 1).status_code == 403
    operatore = make_account("OPERATORE", m["acc"].tenant_id)
    out = produce(client, operatore, m["plant"], m["recipe"], 1,
                  destination_container_id=m["product"]["id"])
    assert out.status_code == 201
    intruder = make_account("ADMIN")
    assert client.get(f"{API}/productions/{out.json()['id']}", headers=intruder.headers).status_code == 404
    assert client.get(f"{API}/productions", headers=intruder.headers).json() == []
    assert produce(client, intruder, m["plant"], m["recipe"], 1).status_code == 422
    assert client.get(f"{API}/lots/{out.json()['mix_lot_id']}/links", headers=intruder.headers).status_code == 404
    assert client.get(f"{API}/productions", headers=auditor.headers).status_code == 200


def test_legami_immutabili(client, mill):
    m = mill
    produce(client, m["acc"], m["plant"], m["recipe"], 1, destination_container_id=m["product"]["id"])
    for statement in ("update trace_link set quantity = 1", "delete from trace_link"):
        with SessionLocal() as db:
            db.execute(text("select set_config('app.tenant_id', :t, true)"),
                       {"t": str(m["acc"].tenant_id)})
            with pytest.raises(DBAPIError):
                db.execute(text(statement))
        with admin_engine.connect() as conn, pytest.raises(DBAPIError):
            conn.exec_driver_sql(statement)
