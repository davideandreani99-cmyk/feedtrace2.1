"""Ingresso materie prime da DDT (RF-02)."""

import uuid
from datetime import date
from decimal import Decimal
from zoneinfo import ZoneInfo

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert

from app import audit
from app.deps import Ctx
from app.models import (
    ContainerAllowedMaterial,
    GoodsReceipt,
    Lot,
    LotCounter,
    RawMaterial,
    Site,
    Supplier,
    Tenant,
)
from app.schemas_stock import LotOut, ReceiptIn, ReceiptOut, WarningOut
from app.services import stock
from domain.enums import LotKind, LotStatus, MovementType
from domain.lotcodes import DEFAULT_LOT_CODE_FORMAT, format_lot_code
from domain.units import convert_to_kg

ROME = ZoneInfo("Europe/Rome")


def next_progressive(ctx: Ctx, site_id: uuid.UUID, day: date, kind: str = "MP") -> int:
    """Progressivo giornaliero per sito, atomico anche con richieste concorrenti (D14)."""
    stmt = (
        pg_insert(LotCounter)
        .values(tenant_id=ctx.tenant_id, site_id=site_id, kind=kind, day=day, last_value=1)
        .on_conflict_do_update(
            index_elements=[
                LotCounter.tenant_id,
                LotCounter.site_id,
                LotCounter.kind,
                LotCounter.day,
            ],
            set_={"last_value": LotCounter.last_value + 1},
        )
        .returning(LotCounter.last_value)
    )
    return ctx.db.execute(stmt).scalar_one()


def _unprocessable(message: str) -> HTTPException:
    return HTTPException(status_code=422, detail=message)


def create_receipt(ctx: Ctx, payload: ReceiptIn, operation_id: uuid.UUID) -> ReceiptOut:
    db = ctx.db
    site = db.scalar(select(Site).where(Site.id == payload.site_id, Site.tenant_id == ctx.tenant_id))
    if site is None:
        raise _unprocessable("Sito non trovato")

    supplier = None
    if payload.supplier_id is not None:
        supplier = db.scalar(
            select(Supplier).where(
                Supplier.id == payload.supplier_id, Supplier.tenant_id == ctx.tenant_id
            )
        )
        if supplier is None:
            raise _unprocessable("Fornitore non trovato")

    tenant = db.get(Tenant, ctx.tenant_id)
    tenant_settings = (tenant.settings if tenant else None) or {}
    lot_format = tenant_settings.get("lot_code_format", DEFAULT_LOT_CODE_FORMAT)
    try:
        format_lot_code(lot_format, date.today(), 1)
    except ValueError as exc:
        raise _unprocessable(f"Formato codice lotto non valido: {exc}") from exc

    warnings: list[WarningOut] = []
    if supplier is not None and not supplier.reg_183_number:
        message = f"Il fornitore {supplier.name} non ha il numero di registrazione Reg. 183/2005"
        if tenant_settings.get("block_supplier_without_183", False):
            raise _unprocessable(message)
        warnings.append(WarningOut(code="SUPPLIER_NO_183", message=message))

    container_ids = [a.container_id for line in payload.lines for a in line.allocations]
    containers = stock.lock_containers(ctx, container_ids)
    for container in containers.values():
        if container.site_id != site.id:
            raise _unprocessable(f"Il contenitore {container.code} appartiene a un altro sito")
    occurred_at = stock.resolve_occurred_at(ctx, payload.occurred_at, list(containers))

    allowed: dict[uuid.UUID, set[uuid.UUID]] = {cid: set() for cid in containers}
    for container_id, material_id in db.execute(
        select(
            ContainerAllowedMaterial.container_id, ContainerAllowedMaterial.material_id
        ).where(
            ContainerAllowedMaterial.container_id.in_(list(containers)),
            ContainerAllowedMaterial.tenant_id == ctx.tenant_id,
        )
    ):
        allowed[container_id].add(material_id)

    receipt = GoodsReceipt(
        tenant_id=ctx.tenant_id,
        site_id=site.id,
        supplier_id=payload.supplier_id,
        ddt_number=payload.ddt_number,
        ddt_date=payload.ddt_date,
        plate=payload.plate,
        received_at=occurred_at,
        notes=payload.notes,
        operation_id=operation_id,
        user_id=ctx.user.id,
    )
    db.add(receipt)
    db.flush()

    local_day = occurred_at.astimezone(ROME).date()
    added: dict[uuid.UUID, Decimal] = {}
    lots: list[Lot] = []

    for line in payload.lines:
        material = db.scalar(
            select(RawMaterial).where(
                RawMaterial.id == line.material_id, RawMaterial.tenant_id == ctx.tenant_id
            )
        )
        if material is None or not material.active:
            raise _unprocessable("Materia prima non trovata o disattivata")
        if not material.lot_tracked:
            raise _unprocessable(f"{material.code} non è tracciata a lotto (es. acqua)")
        if supplier is None and not line.self_produced:
            raise _unprocessable(
                f"Fornitore obbligatorio per {material.code} (o indica materia prima autoprodotta)"
            )
        if supplier is not None and line.self_produced:
            raise _unprocessable("Una materia prima autoprodotta non ha fornitore esterno")

        per_container: dict[uuid.UUID, Decimal] = {}
        for allocation in line.allocations:
            try:
                kg = convert_to_kg(allocation.quantity, line.unit, material.density_kg_l)
            except ValueError as exc:
                raise _unprocessable(f"{material.code}: {exc}") from exc
            container = containers[allocation.container_id]
            restriction = allowed[container.id]
            if restriction and material.id not in restriction:
                raise _unprocessable(
                    f"La materia prima {material.code} non è ammessa nel contenitore "
                    f"{container.code}"
                )
            per_container[container.id] = per_container.get(container.id, Decimal("0")) + kg

        total_kg = sum(per_container.values(), Decimal("0"))
        code = format_lot_code(
            lot_format, local_day, next_progressive(ctx, site.id, local_day)
        )
        status = LotStatus.IN_QUARANTENA if material.requires_analysis else LotStatus.DISPONIBILE
        lot = Lot(
            tenant_id=ctx.tenant_id,
            kind=LotKind.MATERIA_PRIMA.value,
            site_id=site.id,
            internal_code=code,
            material_id=material.id,
            supplier_id=payload.supplier_id,
            supplier_lot=line.supplier_lot,
            entry_date=local_day,
            ddt_number=payload.ddt_number,
            ddt_date=payload.ddt_date,
            plate=payload.plate,
            initial_qty=total_kg,
            price_eur_t=line.price_eur_t,
            origin_country=line.origin_country,
            origin_region=line.origin_region,
            origin_province=line.origin_province or (site.province if line.self_produced else None),
            self_produced=line.self_produced,
            typical_zone=line.typical_zone,
            expiry_date=line.expiry_date,
            status=status.value,
            receipt_id=receipt.id,
        )
        db.add(lot)
        db.flush()
        lots.append(lot)
        if status == LotStatus.IN_QUARANTENA:
            warnings.append(
                WarningOut(
                    code="LOT_IN_QUARANTINE",
                    message=f"Il lotto {code} ({material.code}) è in quarantena: "
                    "richiede analisi prima dell'uso",
                )
            )

        for container_id, kg in per_container.items():
            stock.add_movement(
                ctx,
                container=containers[container_id],
                lot_id=lot.id,
                quantity=kg,
                mtype=MovementType.CARICO_INGRESSO,
                occurred_at=occurred_at,
                operation_id=operation_id,
                doc_type="goods_receipt",
                doc_id=receipt.id,
            )
            added[container_id] = added.get(container_id, Decimal("0")) + kg

    db.flush()
    for container_id in added:
        container = containers[container_id]
        if container.capacity is not None and container.unit == "kg":
            rows = stock.load_stock(db, ctx.tenant_id, container_id)
            if stock.total_of(rows) > container.capacity:
                warnings.append(
                    WarningOut(
                        code="CAPACITY_EXCEEDED",
                        message=f"Capacità superata nel contenitore {container.code} "
                        f"({stock.total_of(rows)} kg su {container.capacity})",
                    )
                )

    out = ReceiptOut(
        id=receipt.id,
        operation_id=operation_id,
        site_id=receipt.site_id,
        supplier_id=receipt.supplier_id,
        ddt_number=receipt.ddt_number,
        ddt_date=receipt.ddt_date,
        plate=receipt.plate,
        received_at=receipt.received_at,
        notes=receipt.notes,
        lots=[LotOut.model_validate(lot) for lot in lots],
        warnings=warnings,
    )
    audit.record(
        ctx,
        "receipts",
        receipt.id,
        "CREATE",
        None,
        {"ddt_number": receipt.ddt_number, "lots": [lot.internal_code for lot in lots]},
    )
    return out
