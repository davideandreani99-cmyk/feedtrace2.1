import uuid
from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import Response
from sqlalchemy import func, select

from app import audit
from app.deps import Ctx, require
from app.idempotency import run_idempotent
from app.models import (
    Attachment,
    Container,
    GoodsReceipt,
    Lot,
    Movement,
    RawMaterial,
)
from app.schemas_stock import (
    AnomalyOut,
    AttachmentOut,
    CleaningIn,
    ContainerSummaryOut,
    InventoryIn,
    LotDetailOut,
    LotLocationOut,
    LotOut,
    MovementListOut,
    OperationOut,
    OutflowIn,
    ReceiptIn,
    ReceiptOut,
    StockLotOut,
    StockOut,
    StornoIn,
    TransferIn,
)
from app.services import operations, stock
from app.services.receipts import create_receipt
from domain.enums import LotKind
from domain.permissions import Permission

router = APIRouter(tags=["stock"])

READ = Permission.STOCK_READ
MOVE = Permission.MOVEMENTS_WRITE
INV = Permission.INVENTORY_WRITE


# --- ingressi ----------------------------------------------------------------------
@router.post("/receipts", response_model=ReceiptOut, status_code=201)
def post_receipt(payload: ReceiptIn, ctx: Ctx = Depends(require(MOVE))):
    """Ingresso da DDT. Idempotente: stesso `operation_id` = nessun duplicato."""
    return run_idempotent(
        ctx, payload.operation_id, "RECEIPT", lambda op: create_receipt(ctx, payload, op)
    )


def _receipt_out(ctx: Ctx, receipt: GoodsReceipt) -> ReceiptOut:
    lots = ctx.db.scalars(
        select(Lot).where(Lot.receipt_id == receipt.id, Lot.tenant_id == ctx.tenant_id)
        .order_by(Lot.internal_code)
    )
    return ReceiptOut(
        id=receipt.id, operation_id=receipt.operation_id, site_id=receipt.site_id,
        supplier_id=receipt.supplier_id, ddt_number=receipt.ddt_number,
        ddt_date=receipt.ddt_date, plate=receipt.plate, received_at=receipt.received_at,
        notes=receipt.notes, lots=[LotOut.model_validate(lot) for lot in lots],
    )


@router.get("/receipts", response_model=list[ReceiptOut])
def list_receipts(
    site_id: uuid.UUID | None = None,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    ctx: Ctx = Depends(require(READ)),
):
    stmt = select(GoodsReceipt).where(GoodsReceipt.tenant_id == ctx.tenant_id)
    if site_id:
        stmt = stmt.where(GoodsReceipt.site_id == site_id)
    rows = ctx.db.scalars(stmt.order_by(GoodsReceipt.received_at.desc()).limit(limit).offset(offset))
    return [_receipt_out(ctx, r) for r in rows]


@router.get("/receipts/{receipt_id}", response_model=ReceiptOut)
def get_receipt(receipt_id: uuid.UUID, ctx: Ctx = Depends(require(READ))):
    receipt = ctx.db.scalar(
        select(GoodsReceipt).where(
            GoodsReceipt.id == receipt_id, GoodsReceipt.tenant_id == ctx.tenant_id
        )
    )
    if receipt is None:
        raise HTTPException(status_code=404, detail="Ingresso non trovato")
    return _receipt_out(ctx, receipt)


# --- lotti -------------------------------------------------------------------------
@router.get("/lots", response_model=list[LotOut])
def list_lots(
    material_id: uuid.UUID | None = None,
    status: str | None = None,
    kind: str | None = Query(None, description="MATERIA_PRIMA oppure MISCELA"),
    q: str | None = Query(None, description="Ricerca nel codice interno o del fornitore"),
    include_unallocated: bool = False,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    ctx: Ctx = Depends(require(READ)),
):
    stmt = select(Lot).where(Lot.tenant_id == ctx.tenant_id)
    if not include_unallocated:
        stmt = stmt.where(Lot.kind != LotKind.NON_ALLOCATO.value)
    if material_id:
        stmt = stmt.where(Lot.material_id == material_id)
    if status:
        stmt = stmt.where(Lot.status == status)
    if kind:
        stmt = stmt.where(Lot.kind == kind)
    if q:
        like = f"%{q}%"
        stmt = stmt.where(Lot.internal_code.ilike(like) | Lot.supplier_lot.ilike(like))
    return list(ctx.db.scalars(stmt.order_by(Lot.created_at.desc(), Lot.internal_code)
                               .limit(limit).offset(offset)))


@router.get("/lots/{lot_id}", response_model=LotDetailOut)
def get_lot(lot_id: uuid.UUID, ctx: Ctx = Depends(require(READ))):
    lot = ctx.db.scalar(select(Lot).where(Lot.id == lot_id, Lot.tenant_id == ctx.tenant_id))
    if lot is None:
        raise HTTPException(status_code=404, detail="Lotto non trovato")
    rows = ctx.db.execute(
        select(Movement.container_id, Container.code, func.sum(Movement.quantity))
        .join(Container, Container.id == Movement.container_id)
        .where(Movement.tenant_id == ctx.tenant_id, Movement.lot_id == lot_id)
        .group_by(Movement.container_id, Container.code)
        .having(func.sum(Movement.quantity) != 0)
        .order_by(Container.code)
    ).all()
    locations = [LotLocationOut(container_id=r[0], container_code=r[1], quantity=r[2]) for r in rows]
    return LotDetailOut(
        **LotOut.model_validate(lot).model_dump(),
        containers=locations,
        total=sum((loc.quantity for loc in locations), Decimal("0")),
    )


# --- giacenze ----------------------------------------------------------------------
def _fill_pct(container: Container, total: Decimal) -> Decimal | None:
    if container.capacity and container.capacity > 0 and container.unit == "kg":
        return (total * 100 / container.capacity).quantize(Decimal("0.1"))
    return None


def _load_container(ctx: Ctx, container_id: uuid.UUID) -> Container:
    container = ctx.db.scalar(
        select(Container).where(
            Container.id == container_id, Container.tenant_id == ctx.tenant_id
        )
    )
    if container is None:
        raise HTTPException(status_code=404, detail="Contenitore non trovato")
    return container


@router.get("/containers/{container_id}/stock", response_model=StockOut)
def container_stock(
    container_id: uuid.UUID,
    at: datetime | None = Query(None, description="Giacenza a una data/ora passata (ISO 8601)"),
    ctx: Ctx = Depends(require(READ)),
):
    """Composizione per lotto del contenitore, in tempo reale o ricostruita a una data."""
    container = _load_container(ctx, container_id)
    rows = [r for r in stock.load_stock(ctx.db, ctx.tenant_id, container.id, at) if r.quantity != 0]
    rows.sort(key=lambda r: r.first_key)
    labels = {
        lot.id: (lot, material)
        for lot, material in ctx.db.execute(
            select(Lot, RawMaterial)
            .outerjoin(RawMaterial, Lot.material_id == RawMaterial.id)
            .where(Lot.id.in_([r.lot_id for r in rows] or [uuid.uuid4()]),
                   Lot.tenant_id == ctx.tenant_id)
        )
    }
    lots = [
        StockLotOut(
            lot_id=r.lot_id,
            internal_code=labels[r.lot_id][0].internal_code,
            kind=labels[r.lot_id][0].kind,
            material_id=labels[r.lot_id][0].material_id,
            material_code=labels[r.lot_id][1].code if labels[r.lot_id][1] else None,
            material_name=labels[r.lot_id][1].name if labels[r.lot_id][1] else None,
            status=labels[r.lot_id][0].status,
            quantity=r.quantity,
        )
        for r in rows
    ]
    total = stock.total_of(rows)
    return StockOut(
        container_id=container.id, code=container.code, at=at, unit=container.unit,
        capacity=container.capacity, consumption_policy=container.consumption_policy,
        total=total, fill_pct=_fill_pct(container, total),
        negative=any(r.quantity < 0 for r in rows),
        medicated_contaminated=container.medicated_contaminated, lots=lots,
    )


@router.get("/stock/containers", response_model=list[ContainerSummaryOut])
def containers_summary(
    site_id: uuid.UUID | None = None,
    active: bool | None = True,
    ctx: Ctx = Depends(require(READ)),
):
    """Elenco contenitori con giacenza, riempimento e lotti presenti."""
    stmt = select(Container).where(Container.tenant_id == ctx.tenant_id)
    if site_id:
        stmt = stmt.where(Container.site_id == site_id)
    if active is not None:
        stmt = stmt.where(Container.active == active)
    containers = list(ctx.db.scalars(stmt.order_by(Container.code)))
    sums: dict[uuid.UUID, list[Decimal]] = {c.id: [] for c in containers}
    for container_id, quantity in ctx.db.execute(
        select(Movement.container_id, func.sum(Movement.quantity))
        .where(Movement.tenant_id == ctx.tenant_id)
        .group_by(Movement.container_id, Movement.lot_id)
        .having(func.sum(Movement.quantity) != 0)
    ):
        if container_id in sums:
            sums[container_id].append(quantity)
    result = []
    for c in containers:
        quantities = sums[c.id]
        total = sum(quantities, Decimal("0"))
        result.append(
            ContainerSummaryOut(
                container_id=c.id, site_id=c.site_id, code=c.code, type=c.type, unit=c.unit,
                capacity=c.capacity, consumption_policy=c.consumption_policy, active=c.active,
                total=total, fill_pct=_fill_pct(c, total), lots_count=len(quantities),
                negative=any(q < 0 for q in quantities),
                medicated_contaminated=c.medicated_contaminated,
            )
        )
    return result


@router.get("/anomalies", response_model=list[AnomalyOut])
def anomalies(ctx: Ctx = Depends(require(READ))):
    """Cruscotto anomalie: giacenze negative per lotto (RF-03)."""
    rows = ctx.db.execute(
        select(Movement.container_id, Container.code, Movement.lot_id, Lot.internal_code,
               func.sum(Movement.quantity))
        .join(Container, Container.id == Movement.container_id)
        .join(Lot, Lot.id == Movement.lot_id)
        .where(Movement.tenant_id == ctx.tenant_id)
        .group_by(Movement.container_id, Container.code, Movement.lot_id, Lot.internal_code)
        .having(func.sum(Movement.quantity) < 0)
        .order_by(Container.code)
    ).all()
    return [
        AnomalyOut(kind="NEGATIVE_STOCK", container_id=r[0], container_code=r[1], lot_id=r[2],
                   lot_code=r[3], quantity=r[4])
        for r in rows
    ]


# --- movimenti ---------------------------------------------------------------------
@router.get("/movements", response_model=list[MovementListOut])
def list_movements(
    container_id: uuid.UUID | None = None,
    lot_id: uuid.UUID | None = None,
    operation_id: uuid.UUID | None = None,
    type: str | None = None,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    ctx: Ctx = Depends(require(READ)),
):
    stmt = select(Movement).where(Movement.tenant_id == ctx.tenant_id)
    if container_id:
        stmt = stmt.where(Movement.container_id == container_id)
    if lot_id:
        stmt = stmt.where(Movement.lot_id == lot_id)
    if operation_id:
        stmt = stmt.where(Movement.operation_id == operation_id)
    if type:
        stmt = stmt.where(Movement.type == type)
    if date_from:
        stmt = stmt.where(Movement.occurred_at >= date_from)
    if date_to:
        stmt = stmt.where(Movement.occurred_at <= date_to)
    rows = ctx.db.scalars(stmt.order_by(Movement.seq.desc()).limit(limit).offset(offset))
    return [MovementListOut.model_validate(m) for m in rows]


# --- operazioni sui contenitori ----------------------------------------------------
@router.post("/transfers", response_model=OperationOut, status_code=201)
def post_transfer(payload: TransferIn, ctx: Ctx = Depends(require(MOVE))):
    return run_idempotent(
        ctx, payload.operation_id, "TRANSFER", lambda op: operations.transfer(ctx, payload, op)
    )


@router.post("/outflows", response_model=OperationOut, status_code=201)
def post_outflow(payload: OutflowIn, ctx: Ctx = Depends(require(MOVE))):
    return run_idempotent(
        ctx, payload.operation_id, "OUTFLOW", lambda op: operations.outflow(ctx, payload, op)
    )


@router.post("/containers/{container_id}/inventory", response_model=OperationOut, status_code=201)
def post_inventory(
    container_id: uuid.UUID, payload: InventoryIn, ctx: Ctx = Depends(require(INV))
):
    return run_idempotent(
        ctx, payload.operation_id, "INVENTORY",
        lambda op: operations.inventory(ctx, container_id, payload, op),
    )


@router.post("/containers/{container_id}/cleanings", response_model=OperationOut, status_code=201)
def post_cleaning(container_id: uuid.UUID, payload: CleaningIn, ctx: Ctx = Depends(require(INV))):
    return run_idempotent(
        ctx, payload.operation_id, "CLEANING",
        lambda op: operations.cleaning(ctx, container_id, payload, op),
    )


@router.post("/movements/{movement_id}/storno", response_model=OperationOut, status_code=201)
def post_storno(movement_id: uuid.UUID, payload: StornoIn, ctx: Ctx = Depends(require(INV))):
    return run_idempotent(
        ctx, payload.operation_id, "STORNO",
        lambda op: operations.storno_movement(ctx, movement_id, payload, op),
    )


@router.post("/operations/{target_operation_id}/storno", response_model=OperationOut, status_code=201)
def post_storno_operation(
    target_operation_id: uuid.UUID, payload: StornoIn, ctx: Ctx = Depends(require(INV))
):
    return run_idempotent(
        ctx, payload.operation_id, "STORNO_OPERATION",
        lambda op: operations.storno_operation(ctx, target_operation_id, payload, op),
    )


# --- allegati (DDT, cartellino, certificato di analisi) ----------------------------
MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024
ALLOWED_TYPES = {"application/pdf", "image/jpeg", "image/png"}


@router.post("/attachments", response_model=AttachmentOut, status_code=201)
async def upload_attachment(
    target_type: str = Form(...),
    target_id: uuid.UUID = Form(...),
    file: UploadFile = File(...),
    ctx: Ctx = Depends(require(MOVE)),
):
    if target_type not in ("receipt", "lot"):
        raise HTTPException(status_code=422, detail="target_type ammesso: receipt o lot")
    model = GoodsReceipt if target_type == "receipt" else Lot
    exists = ctx.db.scalar(
        select(func.count()).select_from(model).where(
            model.id == target_id, model.tenant_id == ctx.tenant_id
        )
    )
    if not exists:
        raise HTTPException(status_code=404, detail="Elemento a cui allegare non trovato")
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(status_code=415, detail="Ammessi solo PDF, JPEG e PNG")
    data = await file.read()
    if len(data) > MAX_ATTACHMENT_BYTES:
        raise HTTPException(status_code=413, detail="Allegato troppo grande (massimo 10 MB)")
    attachment = Attachment(
        tenant_id=ctx.tenant_id, target_type=target_type, target_id=target_id,
        filename=(file.filename or "allegato")[:200], content_type=file.content_type,
        size=len(data), data=data, user_id=ctx.user.id,
    )
    ctx.db.add(attachment)
    ctx.db.flush()
    out = AttachmentOut.model_validate(attachment)
    audit.record(ctx, "attachments", attachment.id, "CREATE", None, out.model_dump(mode="json"))
    ctx.db.commit()
    return out


@router.get("/attachments", response_model=list[AttachmentOut])
def list_attachments(
    target_type: str, target_id: uuid.UUID, ctx: Ctx = Depends(require(READ))
):
    rows = ctx.db.scalars(
        select(Attachment)
        .where(Attachment.tenant_id == ctx.tenant_id, Attachment.target_type == target_type,
               Attachment.target_id == target_id)
        .order_by(Attachment.created_at)
    )
    return [AttachmentOut.model_validate(a) for a in rows]


@router.get("/attachments/{attachment_id}/download")
def download_attachment(attachment_id: uuid.UUID, ctx: Ctx = Depends(require(READ))):
    attachment = ctx.db.scalar(
        select(Attachment).where(
            Attachment.id == attachment_id, Attachment.tenant_id == ctx.tenant_id
        )
    )
    if attachment is None:
        raise HTTPException(status_code=404, detail="Allegato non trovato")
    return Response(
        content=attachment.data,
        media_type=attachment.content_type,
        headers={"Content-Disposition": f'attachment; filename="{attachment.filename}"'},
    )
