"""Schemi della Fase 3: produzione delle miscele (RF-04)."""

import uuid
from datetime import datetime
from decimal import Decimal
from typing import Annotated, Literal

from pydantic import BaseModel, Field

from app.schemas_stock import Qty, WarningOut
from domain.units import InputUnit

OverrideReason = Annotated[str, Field(min_length=3, max_length=500)]


class ProductionLineIn(BaseModel):
    """Quantità effettiva e/o contenitore di prelievo diversi da quelli della ricetta."""

    material_id: uuid.UUID
    container_id: uuid.UUID | None = None
    actual_quantity: Qty | None = None
    unit: InputUnit = InputUnit.KG  # litri convertiti in kg con la densità (broda)


class ProductionIn(BaseModel):
    operation_id: uuid.UUID | None = None
    plant_id: uuid.UUID
    recipe_id: uuid.UUID
    quantity: Qty  # quantità di miscela da produrre (teorica)
    unit: Literal["kg", "t"] = "kg"
    actual_quantity: Qty | None = None  # miscela effettivamente ottenuta (default = teorica)
    started_at: datetime | None = None
    ended_at: datetime | None = None
    # contenitore prodotto finito; assente = contenitore virtuale dell'impianto (scarico diretto)
    destination_container_id: uuid.UUID | None = None
    lines: list[ProductionLineIn] = []
    override_reason: OverrideReason | None = None  # per usare lotti in quarantena/bloccati
    notes: str | None = Field(None, max_length=500)


class AllocationOut(BaseModel):
    lot_id: uuid.UUID
    lot_code: str
    quantity: Decimal


class ProductionLineOut(BaseModel):
    material_id: uuid.UUID
    material_code: str
    container_id: uuid.UUID | None
    theoretical_qty: Decimal
    actual_qty: Decimal
    deviation_pct: Decimal | None
    tolerance_pct: Decimal | None
    allocations: list[AllocationOut]


class ProductionOut(BaseModel):
    id: uuid.UUID
    plant_id: uuid.UUID
    recipe_id: uuid.UUID
    recipe_code: str
    recipe_version: int
    status: str
    source: str
    started_at: datetime
    ended_at: datetime | None
    theoretical_qty: Decimal
    actual_qty: Decimal
    mix_lot_id: uuid.UUID
    mix_lot_code: str
    destination_container_id: uuid.UUID
    lines: list[ProductionLineOut]
    warnings: list[WarningOut] = []
    overrides: list[dict] = []
    notes: str | None = None
    reversal_reason: str | None = None


class LinkLotOut(BaseModel):
    lot_id: uuid.UUID
    lot_code: str
    kind: str  # CERTO | POSSIBILE
    quantity: Decimal


class LotLinksOut(BaseModel):
    sources: list[LinkLotOut]  # da quali lotti proviene (indietro)
    targets: list[LinkLotOut]  # verso quali lotti è andato (avanti)
