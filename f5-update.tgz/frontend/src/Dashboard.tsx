import { FormEvent, useEffect, useState } from "react";
import { api, download } from "./api";

type Row = Record<string, unknown>;
const fmt = (value: unknown): string => {
  const n = Number(value);
  return Number.isFinite(n) ? n.toLocaleString("it-IT", { minimumFractionDigits: 0, maximumFractionDigits: 3 }) : "";
};
const errText = (e: unknown): string => (e instanceof Error ? e.message : "Errore");

export function DashboardPage() {
  const [data, setData] = useState<Row | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    api<Row>("/dashboard").then(setData).catch((e: unknown) => setError(errText(e)));
  }, []);
  if (error) return <p className="error">{error}</p>;
  if (!data) return <p>Caricamento…</p>;
  const containers = data.containers as Row[];
  const blocked = data.blocked_lots as Row[];
  const contaminated = data.contaminated as Row[];
  const negative = data.negative_stock as Row[];
  const deviations = data.deviations as Row[];
  const issues = data.import_issues as Row[];
  const recent = data.recent as Row;
  return (
    <section>
      <h2>Cruscotto</h2>
      <div className="cards">
        <div className="card stat"><span>Giacenza totale</span><strong>{fmt(data.total_stock_kg)} kg</strong></div>
        <div className="card stat"><span>Ingressi (7 gg)</span><strong>{String(recent.receipts_7d)}</strong></div>
        <div className="card stat"><span>Produzioni (7 gg)</span><strong>{String(recent.productions_7d)}</strong></div>
        <div className="card stat"><span>Scarichi (7 gg)</span><strong>{String(recent.discharges_7d)}</strong></div>
        <div className={`card stat ${blocked.length ? "alert" : ""}`}><span>Lotti bloccati</span><strong>{blocked.length}</strong></div>
        <div className={`card stat ${negative.length ? "alert" : ""}`}><span>Giacenze negative</span><strong>{negative.length}</strong></div>
      </div>

      <h3>Contenitori</h3>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Contenitore</th><th>Politica</th><th>kg</th><th>Riempimento</th><th>Lotti</th><th>Stato</th></tr></thead>
          <tbody>
            {containers.map((c) => (
              <tr key={String(c.container_id)}>
                <td>{String(c.code)}</td><td>{String(c.consumption_policy)}</td><td>{fmt(c.total)}</td>
                <td>{c.fill_pct === null ? "—" : <div className="bar"><div style={{ width: `${Math.min(100, Math.max(0, Number(c.fill_pct)))}%` }} /></div>}</td>
                <td>{String(c.lots_count)}</td><td>{c.negative ? "⚠ negativa" : ""}</td>
              </tr>
            ))}
            {containers.length === 0 && <tr><td colSpan={6}>Nessun contenitore.</td></tr>}
          </tbody>
        </table>
      </div>

      <h3>Lotti in quarantena, non conformi o bloccati (con giacenza)</h3>
      <ul>{blocked.map((b) => <li key={String(b.lot_id)}><strong>{String(b.lot_code)}</strong> {String(b.material_code ?? "")} — {String(b.status)} — {fmt(b.stock_kg)} kg in {(b.containers as string[]).join(", ")}</li>)}
        {blocked.length === 0 && <li>Nessuno.</li>}</ul>

      <h3>Contaminazione da medicato</h3>
      <ul>{contaminated.map((c, i) => <li key={i}>{String(c.type)} {String(c.code)}</li>)}{contaminated.length === 0 && <li>Nessuna.</li>}</ul>

      <h3>REV in scadenza</h3>
      <p><small>Disponibile con la gestione dei medicati (fase dedicata).</small></p>

      <h3>Anomalie: giacenze negative</h3>
      <ul>{negative.map((n, i) => <li key={i}>{String(n.container_code)} — lotto {String(n.lot_code)}: <span className="error">{fmt(n.quantity)} kg</span></li>)}{negative.length === 0 && <li>Nessuna.</li>}</ul>

      <h3>Scostamenti di produzione (ultimi 30 giorni)</h3>
      <ul>{deviations.map((d, i) => <li key={i}>{String(d.started_at).slice(0, 10)} {String(d.recipe_code)}: {String(d.message)}</li>)}{deviations.length === 0 && <li>Nessuno.</li>}</ul>

      <h3>Import con righe in errore</h3>
      <ul>{issues.map((f) => <li key={String(f.file_id)}>{String(f.filename)} ({String(f.status)}): {String(f.error_count)} in errore, {String(f.failed_count)} fallite</li>)}{issues.length === 0 && <li>Nessuno.</li>}</ul>
    </section>
  );
}

export function ReportsPage() {
  const [sites, setSites] = useState<Row[]>([]);
  const [site, setSite] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState(new Date().toISOString().slice(0, 10));
  const [error, setError] = useState("");
  useEffect(() => {
    api<Row[]>("/sites?active=true").then(setSites).catch((e: unknown) => setError(errText(e)));
  }, []);
  function get(format: "pdf" | "xlsx", e?: FormEvent) {
    e?.preventDefault();
    setError("");
    void download(`/reports/ledger?site_id=${site}&date_from=${from}&date_to=${to}&format=${format}`, `registro-carico-scarico.${format}`)
      .catch((err: unknown) => setError(errText(err)));
  }
  return (
    <section>
      <h2>Report</h2>
      {error && <p className="error">{error}</p>}
      <form className="card grid" onSubmit={(e) => get("pdf", e)}>
        <h3 style={{ gridColumn: "1 / -1" }}>Registro di carico e scarico (ASL / enti di controllo)</h3>
        <label>Sito
          <select value={site} required onChange={(e) => setSite(e.target.value)}>
            <option value="">Seleziona…</option>
            {sites.map((s) => <option key={String(s.id)} value={String(s.id)}>{String(s.name)}</option>)}
          </select>
        </label>
        <label>Dal<input type="date" required value={from} onChange={(e) => setFrom(e.target.value)} /></label>
        <label>Al<input type="date" required value={to} onChange={(e) => setTo(e.target.value)} /></label>
        <button type="submit">Scarica PDF</button>
        <button type="button" className="secondary" disabled={!site || !from} onClick={() => get("xlsx")}>Scarica Excel</button>
      </form>
      <p>La scheda di tracciabilità e la simulazione di richiamo si scaricano dalla pagina Tracciabilità.</p>
    </section>
  );
}
