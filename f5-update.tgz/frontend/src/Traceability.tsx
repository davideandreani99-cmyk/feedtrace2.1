import { FormEvent, useEffect, useState } from "react";
import { api, download } from "./api";

type Row = Record<string, unknown>;
interface Node {
  id: string;
  node_type: string;
  label: string;
  kind: string;
  status: string | null;
  depth: number;
  material_name: string | null;
  recipe_code: string | null;
  supplier_name: string | null;
  supplier_lot: string | null;
  ddt_number: string | null;
  external_code: string | null;
  site_name: string | null;
  containers: { container_code: string; quantity: string }[];
}
interface Edge { source: string; target: string; quantity: string; kind: string; depth: number }
interface Trace {
  direction: string;
  start_label: string;
  amount: string;
  nodes: Node[];
  edges: Edge[];
  results: { node_id: string; certain_kg: string; possible_kg: string }[];
  warnings: string[];
  truncated: boolean;
}

const fmt = (value: unknown): string => {
  const n = Number(value);
  return Number.isFinite(n) ? n.toLocaleString("it-IT", { minimumFractionDigits: 0, maximumFractionDigits: 3 }) : "";
};
const errText = (e: unknown): string => (e instanceof Error ? e.message : "Errore");
const KIND: Record<string, string> = {
  MATERIA_PRIMA: "Materia prima", MISCELA: "Miscela", NON_ALLOCATO: "Non allocato", DESTINAZIONE: "Destinazione",
};

// ---------------------------------------------------------------- vista grafica a livelli
function Graph({ trace }: { trace: Trace }) {
  const byDepth: Record<number, Node[]> = {};
  trace.nodes.forEach((n) => (byDepth[n.depth] ??= []).push(n));
  const depths = Object.keys(byDepth).map(Number).sort((a, b) => a - b);
  const W = 170, H = 38, GX = 90, GY = 16;
  const pos: Record<string, { x: number; y: number }> = {};
  let height = 0;
  depths.forEach((d, col) => {
    byDepth[d].forEach((n, row) => {
      pos[n.id] = { x: 12 + col * (W + GX), y: 12 + row * (H + GY) };
      height = Math.max(height, 12 + (row + 1) * (H + GY));
    });
  });
  const width = 12 + depths.length * (W + GX);
  const max = Math.max(1, ...trace.edges.map((e) => Number(e.quantity)));
  return (
    <div className="graph">
      <svg width={width} height={height + 10} role="img" aria-label="Grafo di tracciabilità">
        {trace.edges.map((e, i) => {
          const a = pos[e.source], b = pos[e.target];
          if (!a || !b) return null;
          const forward = a.x < b.x;
          const x1 = forward ? a.x + W : a.x, x2 = forward ? b.x : b.x + W;
          const y1 = a.y + H / 2, y2 = b.y + H / 2;
          return (
            <g key={i}>
              <line x1={x1} y1={y1} x2={x2} y2={y2} className={e.kind === "POSSIBILE" ? "edge possible" : "edge"}
                strokeWidth={1 + (Number(e.quantity) / max) * 5} />
              <text x={(x1 + x2) / 2} y={(y1 + y2) / 2 - 3} className="edge-label">{fmt(e.quantity)}</text>
            </g>
          );
        })}
        {trace.nodes.map((n) => {
          const p = pos[n.id];
          if (!p) return null;
          return (
            <g key={n.id} transform={`translate(${p.x},${p.y})`}>
              <rect width={W} height={H} rx={6} className={`node ${n.kind}`} />
              <text x={8} y={15} className="node-title">{n.label.slice(0, 24)}</text>
              <text x={8} y={29} className="node-sub">{KIND[n.kind] ?? n.kind}{n.status && n.status !== "DISPONIBILE" && n.node_type === "LOT" ? ` · ${n.status}` : ""}</text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function ResultTable({ trace }: { trace: Trace }) {
  const nodes = Object.fromEntries(trace.nodes.map((n) => [n.id, n]));
  const forward = trace.direction === "forward";
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            {forward
              ? <><th>Lotto di destinazione</th><th>Pig'UP</th><th>Sito</th></>
              : <><th>Lotto MP</th><th>Materia prima</th><th>Fornitore</th><th>Lotto forn.</th><th>DDT</th><th>Stato</th></>}
            <th>kg certi</th><th>kg possibili</th>
          </tr>
        </thead>
        <tbody>
          {trace.results.map((r) => {
            const n = nodes[r.node_id];
            return (
              <tr key={r.node_id}>
                {forward
                  ? <><td>{n.label}</td><td>{n.external_code ?? ""}</td><td>{n.site_name ?? ""}</td></>
                  : <><td>{n.label}</td><td>{n.material_name ?? ""}</td><td>{n.supplier_name ?? ""}</td><td>{n.supplier_lot ?? ""}</td><td>{n.ddt_number ?? ""}</td><td>{n.status ?? ""}</td></>}
                <td>{fmt(r.certain_kg)}</td><td>{fmt(r.possible_kg)}</td>
              </tr>
            );
          })}
          {trace.results.length === 0 && <tr><td colSpan={8}>Nessun risultato.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

// ---------------------------------------------------------------- pagina
export function TraceabilityPage() {
  const [mode, setMode] = useState<"backward" | "forward" | "recall">("backward");
  const [source, setSource] = useState("destination");
  const [lots, setLots] = useState<Row[]>([]);
  const [dests, setDests] = useState<Row[]>([]);
  const [containers, setContainers] = useState<Row[]>([]);
  const [suppliers, setSuppliers] = useState<Row[]>([]);
  const [value, setValue] = useState("");
  const [at, setAt] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [trace, setTrace] = useState<Trace | null>(null);
  const [recall, setRecall] = useState<Row | null>(null);
  const [query, setQuery] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    void (async () => {
      try {
        setLots(await api<Row[]>("/lots?limit=500"));
        setDests(await api<Row[]>("/destination-lots"));
        setContainers(await api<Row[]>("/stock/containers"));
        setSuppliers(await api<Row[]>("/suppliers"));
      } catch (e) {
        setError(errText(e));
      }
    })();
  }, []);

  const effectiveSource = mode === "forward" ? (source === "supplier" ? "supplier" : "lot") : mode === "recall" ? "lot" : source;

  function params(): URLSearchParams {
    const p = new URLSearchParams();
    if (effectiveSource === "lot") p.set("lot_id", value);
    if (effectiveSource === "destination") p.set("destination_lot_id", value);
    if (effectiveSource === "container") {
      p.set("container_id", value);
      if (at) p.set("at", new Date(at).toISOString());
    }
    if (effectiveSource === "supplier") {
      p.set("supplier_id", value);
      if (from) p.set("date_from", from);
      if (to) p.set("date_to", to);
    }
    return p;
  }

  async function run(e: FormEvent) {
    e.preventDefault();
    setError("");
    setTrace(null);
    setRecall(null);
    try {
      if (mode === "recall") setRecall(await api<Row>(`/traceability/recall/${value}`));
      else setTrace(await api<Trace>(`/traceability/${mode}?${params().toString()}`));
    } catch (err) {
      setError(errText(err));
    }
  }

  function pdfOrXlsx(format: "pdf" | "xlsx") {
    const path = mode === "recall"
      ? `/reports/recall/${value}?format=${format}`
      : `/reports/traceability?direction=${mode}&format=${format}&${params().toString()}`;
    void download(path, `tracciabilita.${format}`).catch((err: unknown) => setError(errText(err)));
  }

  const options = (rows: Row[], label: (r: Row) => string) =>
    rows.map((r) => <option key={String(r.id ?? r.container_id)} value={String(r.id ?? r.container_id)}>{label(r)}</option>);
  const filteredLots = lots.filter((l) => !query || String(l.internal_code).toLowerCase().includes(query.toLowerCase()));

  return (
    <section>
      <h2>Tracciabilità</h2>
      {error && <p className="error">{error}</p>}
      <div className="row no-print">
        {([["backward", "Indietro (da dove proviene)"], ["forward", "Avanti (dove è arrivato)"], ["recall", "Simulazione richiamo"]] as const).map(([k, label]) => (
          <button key={k} className={mode === k ? "" : "secondary"} onClick={() => { setMode(k); setTrace(null); setRecall(null); setValue(""); setSource(k === "backward" ? "destination" : "lot"); }}>{label}</button>
        ))}
      </div>
      <form className="card grid no-print" onSubmit={run}>
        {mode === "backward" && (
          <label>Partire da
            <select value={source} onChange={(e) => { setSource(e.target.value); setValue(""); }}>
              <option value="destination">Lotto di destinazione</option>
              <option value="lot">Lotto (MP o miscela)</option>
              <option value="container">Contenitore (a una data)</option>
            </select>
          </label>
        )}
        {mode === "forward" && (
          <label>Partire da
            <select value={source} onChange={(e) => { setSource(e.target.value); setValue(""); }}>
              <option value="lot">Lotto (MP o miscela)</option>
              <option value="supplier">Fornitore e periodo</option>
            </select>
          </label>
        )}
        {effectiveSource === "lot" && <label>Cerca lotto<input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="codice…" /></label>}
        <label>{effectiveSource === "destination" ? "Lotto di destinazione" : effectiveSource === "container" ? "Contenitore" : effectiveSource === "supplier" ? "Fornitore" : "Lotto"}
          <select value={value} required onChange={(e) => setValue(e.target.value)}>
            <option value="">Seleziona…</option>
            {effectiveSource === "lot" && options(filteredLots, (l) => `${String(l.internal_code)} (${String(l.kind === "MISCELA" ? "miscela" : "MP")})`)}
            {effectiveSource === "destination" && options(dests, (d) => `${String(d.internal_code)}${d.external_code ? ` — ${String(d.external_code)}` : ""}`)}
            {effectiveSource === "container" && options(containers, (c) => String(c.code))}
            {effectiveSource === "supplier" && options(suppliers, (s) => String(s.name))}
          </select>
        </label>
        {effectiveSource === "container" && <label>Alla data (vuoto = adesso)<input type="datetime-local" value={at} onChange={(e) => setAt(e.target.value)} /></label>}
        {effectiveSource === "supplier" && <><label>Ingressi dal<input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></label><label>al<input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></label></>}
        <button type="submit">Cerca</button>
      </form>

      {(trace || recall) && (
        <div className="row no-print">
          <button className="secondary" onClick={() => pdfOrXlsx("pdf")}>Scarica PDF</button>
          <button className="secondary" onClick={() => pdfOrXlsx("xlsx")}>Scarica Excel</button>
          {recall && <button className="secondary" onClick={() => window.print()}>Stampa</button>}
        </div>
      )}

      {trace && (
        <div className="card">
          <h3>{trace.direction === "backward" ? "Provenienza di" : "Destinazione di"} {trace.start_label} — {fmt(trace.amount)} kg</h3>
          {trace.warnings.map((w, i) => <p key={i} className="error">⚠ {w}</p>)}
          {trace.truncated && <p className="error">⚠ Profondità massima raggiunta: il percorso potrebbe proseguire.</p>}
          <p><small>Linea tratteggiata = legame POSSIBILE (silo con politica TUTTI_PRESENTI). Spessore proporzionale ai kg attribuiti.</small></p>
          <Graph trace={trace} />
          <ResultTable trace={trace} />
        </div>
      )}

      {recall && (
        <div className="card printable">
          <h3>Simulazione di richiamo — {String((recall.lot as Node).label)}</h3>
          <p>
            {String((recall.lot as Node).material_name ?? (recall.lot as Node).recipe_code ?? "")} · fornitore {String((recall.lot as Node).supplier_name ?? "—")} ·
            DDT {String((recall.lot as Node).ddt_number ?? "—")} · stato {String((recall.lot as Node).status)}
          </p>
          <p>Lotti di destinazione: <strong>{(recall.destinations as Row[]).length}</strong> · kg certi <strong>{fmt(recall.total_certain_kg)}</strong> · kg possibili <strong>{fmt(recall.total_possible_kg)}</strong></p>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Lotto</th><th>Pig'UP</th><th>Sito</th><th>Capi</th><th>kg certi</th><th>kg possibili</th><th>Periodo</th><th>Referente</th><th>Telefono</th><th>Email</th></tr></thead>
              <tbody>
                {(recall.destinations as Row[]).map((d) => (
                  <tr key={String(d.destination_lot_id)}>
                    <td>{String(d.code)}</td><td>{String(d.external_code ?? "")}</td><td>{String(d.site_name ?? "")}</td><td>{String(d.head_count ?? "")}</td>
                    <td>{fmt(d.certain_kg)}</td><td>{fmt(d.possible_kg)}</td><td>{String(d.first_period ?? "")} {d.last_period && d.last_period !== d.first_period ? `→ ${String(d.last_period)}` : ""}</td>
                    <td>{String(d.contact_name ?? "")}</td><td>{String(d.contact_phone ?? "")}</td><td>{String(d.contact_email ?? "")}</td>
                  </tr>
                ))}
                {(recall.destinations as Row[]).length === 0 && <tr><td colSpan={10}>Il lotto non ha raggiunto nessun lotto di destinazione.</td></tr>}
              </tbody>
            </table>
          </div>
          <h4>Lotti miscela coinvolti</h4>
          <ul>{(recall.mix_lots as Row[]).map((m) => <li key={String(m.lot_id)}>{String(m.code)} ({String(m.recipe_code ?? "")}): {fmt(m.kg)} kg del lotto richiamato</li>)}</ul>
          <h4>Giacenze residue da bloccare</h4>
          <ul>{(recall.remaining_stock as Row[]).map((s, i) => <li key={i}>{String(s.lot_code)} in {String(s.container_code)}: {fmt(s.quantity)} kg</li>)}
            {(recall.remaining_stock as Row[]).length === 0 && <li>Nessuna giacenza residua.</li>}</ul>
          <p><small>Simulazione: non registra operazioni. I kg sono stime proporzionali (miscela omogenea).</small></p>
        </div>
      )}
    </section>
  );
}
