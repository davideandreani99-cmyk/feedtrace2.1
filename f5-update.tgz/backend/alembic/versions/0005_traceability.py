"""Fase 5: contatti dei siti (richiamo) e indice dei lotti per fornitore.

Idempotente (le migrazioni precedenti creano le tabelle dai modelli correnti).

Revision ID: 0005
Revises: 0004
"""

from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()

    def run(sql: str) -> None:
        bind.exec_driver_sql(sql)

    run("ALTER TABLE site ADD COLUMN IF NOT EXISTS contact_name varchar(200)")
    run("ALTER TABLE site ADD COLUMN IF NOT EXISTS contact_phone varchar(50)")
    run("ALTER TABLE site ADD COLUMN IF NOT EXISTS contact_email varchar(200)")
    run("CREATE INDEX IF NOT EXISTS ix_lot_supplier ON lot (tenant_id, supplier_id, entry_date)")


def downgrade() -> None:
    raise NotImplementedError("Downgrade non supportato")
