"""Attribuzione delle quantità lungo la catena di tracciabilità (RF-07, SPEC §6.7).

Il grafo ha come nodi i lotti (materia prima, miscela) e i lotti di destinazione; gli archi sono i
consumi registrati (legami CERTI) o le presenze possibili (POSSIBILI) con la quantità in kg.
Per attribuire le quantità si assume la miscela omogenea: dei `produced` kg di un nodo, una
quota `arco / produced` proviene da ciascun ingresso (e va a ciascuna uscita). Funzioni pure.
"""

from collections import defaultdict
from dataclasses import dataclass, field
from decimal import Decimal

ZERO = Decimal("0")
MAX_DEPTH = 8


@dataclass(frozen=True)
class Edge:
    source: str
    target: str
    quantity: Decimal  # kg
    kind: str  # CERTO | POSSIBILE


@dataclass
class Graph:
    inputs: dict[str, list[Edge]]  # nodo -> archi entranti (provenienza)
    outputs: dict[str, list[Edge]]  # nodo -> archi uscenti (destinazione)
    produced: dict[str, Decimal]  # kg totali di ogni nodo (denominatore delle quote)

    @classmethod
    def build(cls, edges: list[Edge], produced: dict[str, Decimal]) -> "Graph":
        inputs: dict[str, list[Edge]] = defaultdict(list)
        outputs: dict[str, list[Edge]] = defaultdict(list)
        for edge in edges:
            inputs[edge.target].append(edge)
            outputs[edge.source].append(edge)
        return cls(dict(inputs), dict(outputs), dict(produced))


@dataclass(frozen=True)
class TraceEdge:
    source: str
    target: str
    quantity: Decimal
    kind: str
    depth: int


@dataclass
class TraceResult:
    edges: list[TraceEdge]
    certain: dict[str, Decimal]  # nodi terminali raggiunti con certezza (kg attribuiti)
    possible: dict[str, Decimal]  # nodi terminali raggiunti solo "possibilmente"
    warnings: list[str] = field(default_factory=list)
    truncated: bool = False  # profondità massima raggiunta


def _combine(kind_a: str, kind_b: str) -> str:
    return "POSSIBILE" if "POSSIBILE" in (kind_a, kind_b) else "CERTO"


def trace(
    graph: Graph,
    start: str,
    direction: str,
    amount: Decimal | None = None,
    max_depth: int = MAX_DEPTH,
) -> TraceResult:
    """Tracciabilità `backward` (verso le materie prime) o `forward` (verso le destinazioni).

    `amount`: kg del nodo di partenza da tracciare (default: tutta la sua quantità)."""
    if direction not in ("backward", "forward"):
        raise ValueError("direction deve essere 'backward' o 'forward'")
    backward = direction == "backward"
    edges_of = graph.inputs if backward else graph.outputs

    def neighbour(edge: Edge) -> str:
        return edge.source if backward else edge.target

    warnings: list[str] = []
    if amount is None:
        amount = graph.produced.get(start, ZERO)

    # profondità minima di ogni nodo e ordine topologico (partenza per prima), con rilevamento cicli
    depth: dict[str, int] = {start: 0}
    frontier = [start]
    while frontier:
        following: list[str] = []
        for node in frontier:
            if depth[node] >= max_depth:
                continue
            for edge in edges_of.get(node, []):
                other = neighbour(edge)
                if other not in depth:
                    depth[other] = depth[node] + 1
                    following.append(other)
        frontier = following

    skipped: set[tuple[str, str, str]] = set()  # archi che chiuderebbero un ciclo
    visited: set[str] = set()
    on_stack: set[str] = set()
    postorder: list[str] = []

    def visit(node: str) -> None:
        visited.add(node)
        on_stack.add(node)
        if depth.get(node, max_depth) < max_depth:
            for edge in edges_of.get(node, []):
                other = neighbour(edge)
                if other in on_stack:
                    skipped.add((edge.source, edge.target, edge.kind))
                    warnings.append(f"Ciclo rilevato tra {node} e {other}: arco ignorato")
                elif other not in visited:
                    visit(other)
        on_stack.discard(node)
        postorder.append(node)

    visit(start)
    order = list(reversed(postorder))

    mass: dict[str, dict[str, Decimal]] = {start: {"CERTO": amount, "POSSIBILE": ZERO}}
    flows: dict[tuple[str, str, str], Decimal] = defaultdict(Decimal)
    flow_depth: dict[tuple[str, str, str], int] = {}
    expanded: set[str] = set()
    truncated = False

    for node in order:
        node_mass = mass.get(node)
        if not node_mass:
            continue
        candidates = [
            e for e in edges_of.get(node, []) if (e.source, e.target, e.kind) not in skipped
        ]
        if not candidates:
            continue
        if depth.get(node, 0) >= max_depth:
            truncated = True
            continue
        denominator = graph.produced.get(node)
        if not denominator or denominator <= 0:
            warnings.append(f"Quantità prodotta sconosciuta per {node}: percorso interrotto")
            continue
        expanded.add(node)
        for edge in candidates:
            for kind, value in node_mass.items():
                if value == 0:
                    continue
                share = value * edge.quantity / denominator
                out_kind = _combine(kind, edge.kind)
                other = neighbour(edge)
                bucket = mass.setdefault(other, {"CERTO": ZERO, "POSSIBILE": ZERO})
                bucket[out_kind] += share
                key = (edge.source, edge.target, out_kind)
                flows[key] += share
                flow_depth.setdefault(key, depth[node] + 1)

    certain: dict[str, Decimal] = {}
    possible: dict[str, Decimal] = {}
    for node, parts in mass.items():
        if node in expanded:
            continue
        if parts["CERTO"] != 0:
            certain[node] = parts["CERTO"]
        if parts["POSSIBILE"] != 0:
            possible[node] = parts["POSSIBILE"]

    edges = [
        TraceEdge(source, target, quantity, kind, flow_depth[(source, target, kind)])
        for (source, target, kind), quantity in sorted(
            flows.items(), key=lambda item: (flow_depth[item[0]], item[0])
        )
    ]
    return TraceResult(edges, certain, possible, warnings, truncated)
