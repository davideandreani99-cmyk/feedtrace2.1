"""Modello dati F1: tenant, utenti, anagrafiche (RF-01), audit (RF-14).

Quantità: Numeric (mai float). Date in UTC. Ogni tabella operativa ha tenant_id (RLS).
"""

import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    ForeignKey,
    Identity,
    Index,
    Integer,
    LargeBinary,
    Numeric,
    String,
    UniqueConstraint,
    func,
    text,
    true,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class IdMixin:
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)


class TenantMixin(IdMixin):
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenant.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class ActiveMixin:
    # Le anagrafiche non si cancellano: si disattivano (RF-01).
    active: Mapped[bool] = mapped_column(Boolean, default=True, server_default=true())


# --- identità e tenant -------------------------------------------------------------
class Tenant(Base):
    __tablename__ = "tenant"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(200))
    vat_number: Mapped[str | None] = mapped_column(String(20), unique=True)
    plan: Mapped[str] = mapped_column(String(30), default="base", server_default="base")
    settings: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}")
    active: Mapped[bool] = mapped_column(Boolean, default=True, server_default=true())
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class AppUser(Base):
    """Utente globale: può appartenere a più tenant tramite Membership."""

    __tablename__ = "app_user"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    email: Mapped[str] = mapped_column(String(320), unique=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    full_name: Mapped[str] = mapped_column(String(200))
    is_superadmin: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    totp_secret: Mapped[str | None] = mapped_column(String(64))
    totp_enabled: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    active: Mapped[bool] = mapped_column(Boolean, default=True, server_default=true())
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class Membership(TenantMixin, Base):
    __tablename__ = "membership"
    __table_args__ = (UniqueConstraint("user_id", "tenant_id"),)

    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("app_user.id"), index=True)
    role: Mapped[str] = mapped_column(String(20))


# --- anagrafiche -------------------------------------------------------------------
class Site(TenantMixin, ActiveMixin, Base):
    __tablename__ = "site"
    __table_args__ = (UniqueConstraint("tenant_id", "asl_code"),)

    name: Mapped[str] = mapped_column(String(200))
    asl_code: Mapped[str] = mapped_column(String(20))
    address: Mapped[str | None] = mapped_column(String(300))
    province: Mapped[str | None] = mapped_column(String(50))
    dop_circuit: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    # contatti dell'allevamento: usati nella simulazione di richiamo (RF-07)
    contact_name: Mapped[str | None] = mapped_column(String(200))
    contact_phone: Mapped[str | None] = mapped_column(String(50))
    contact_email: Mapped[str | None] = mapped_column(String(200))


class Supplier(TenantMixin, ActiveMixin, Base):
    __tablename__ = "supplier"
    __table_args__ = (UniqueConstraint("tenant_id", "vat_number"),)

    name: Mapped[str] = mapped_column(String(200))
    vat_number: Mapped[str | None] = mapped_column(String(20))
    reg_183_number: Mapped[str | None] = mapped_column(String(40))
    medicated_supplier: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default="false"
    )


class RawMaterial(TenantMixin, ActiveMixin, Base):
    __tablename__ = "raw_material"
    __table_args__ = (UniqueConstraint("tenant_id", "code"),)

    code: Mapped[str] = mapped_column(String(40))
    name: Mapped[str] = mapped_column(String(200))
    type: Mapped[str] = mapped_column(String(30))
    unit: Mapped[str] = mapped_column(String(5), default="kg", server_default="kg")
    density_kg_l: Mapped[Decimal | None] = mapped_column(Numeric(8, 4))
    dry_matter_pct: Mapped[Decimal | None] = mapped_column(Numeric(7, 3))
    fat_pct: Mapped[Decimal | None] = mapped_column(Numeric(7, 3))
    linoleic_pct: Mapped[Decimal | None] = mapped_column(Numeric(7, 3))
    dop_category: Mapped[str | None] = mapped_column(String(60))
    requires_analysis: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default="false"
    )
    lot_tracked: Mapped[bool] = mapped_column(Boolean, default=True, server_default=true())


class Container(TenantMixin, ActiveMixin, Base):
    __tablename__ = "container"
    __table_args__ = (UniqueConstraint("site_id", "code"),)

    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id"), index=True)
    code: Mapped[str] = mapped_column(String(40))
    type: Mapped[str] = mapped_column(String(20))
    capacity: Mapped[Decimal | None] = mapped_column(Numeric(18, 3))
    unit: Mapped[str] = mapped_column(String(5), default="kg", server_default="kg")
    consumption_policy: Mapped[str] = mapped_column(
        String(20), default="FIFO", server_default="FIFO"
    )
    negative_threshold_kg: Mapped[Decimal] = mapped_column(
        Numeric(18, 3), default=Decimal("0"), server_default="0"
    )
    medicated_only: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    medicated_contaminated: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default="false"
    )
    # contenitore virtuale di un impianto (D10); null per i contenitori reali
    plant_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("plant.id"))


class ContainerAllowedMaterial(TenantMixin, Base):
    __tablename__ = "container_allowed_material"
    __table_args__ = (UniqueConstraint("container_id", "material_id"),)

    container_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("container.id"), index=True)
    material_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("raw_material.id"))


class Plant(TenantMixin, ActiveMixin, Base):
    __tablename__ = "plant"
    __table_args__ = (UniqueConstraint("site_id", "code"),)

    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id"), index=True)
    code: Mapped[str] = mapped_column(String(40))
    name: Mapped[str] = mapped_column(String(200))
    type: Mapped[str] = mapped_column(String(25))
    lot_rule: Mapped[str] = mapped_column(
        String(30), default="PER_CICLO", server_default="PER_CICLO"
    )
    tolerance_pct: Mapped[Decimal] = mapped_column(
        Numeric(7, 3), default=Decimal("0"), server_default="0"
    )
    processing_cost_eur_t: Mapped[Decimal] = mapped_column(
        Numeric(18, 4), default=Decimal("0"), server_default="0"
    )
    medicated_authorized: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default="false"
    )
    medicated_contaminated: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default="false"
    )


class Recipe(TenantMixin, ActiveMixin, Base):
    """Una riga per versione: le versioni non si modificano (RF-01)."""

    __tablename__ = "recipe"
    __table_args__ = (UniqueConstraint("tenant_id", "code", "version"),)

    code: Mapped[str] = mapped_column(String(40))
    name: Mapped[str] = mapped_column(String(200))
    version: Mapped[int] = mapped_column(Integer)
    valid_from: Mapped[date] = mapped_column(Date)
    valid_to: Mapped[date | None] = mapped_column(Date)
    plant_type: Mapped[str] = mapped_column(String(25))
    phase: Mapped[str] = mapped_column(String(20), default="ALTRO", server_default="ALTRO")
    dop: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    medicated: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")

    lines: Mapped[list["RecipeLine"]] = relationship(
        order_by="RecipeLine.position", lazy="select"
    )


class RecipeLine(TenantMixin, Base):
    __tablename__ = "recipe_line"
    __table_args__ = (UniqueConstraint("recipe_id", "material_id"),)

    recipe_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("recipe.id"), index=True)
    material_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("raw_material.id"))
    position: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    kg_per_t: Mapped[Decimal] = mapped_column(Numeric(12, 3))
    default_container_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("container.id"))
    tolerance_pct: Mapped[Decimal | None] = mapped_column(Numeric(7, 3))


class DestinationLot(TenantMixin, ActiveMixin, Base):
    __tablename__ = "destination_lot"
    __table_args__ = (UniqueConstraint("tenant_id", "internal_code"),)

    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id"), index=True)
    internal_code: Mapped[str] = mapped_column(String(40))
    external_code: Mapped[str | None] = mapped_column(String(40), index=True)  # codice Pig'UP
    description: Mapped[str | None] = mapped_column(String(300))
    phase: Mapped[str] = mapped_column(String(20), default="ALTRO", server_default="ALTRO")
    head_count: Mapped[int | None] = mapped_column(Integer)
    start_date: Mapped[date | None] = mapped_column(Date)
    end_date: Mapped[date | None] = mapped_column(Date)
    dop: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    status: Mapped[str] = mapped_column(String(10), default="APERTO", server_default="APERTO")


class Location(TenantMixin, ActiveMixin, Base):
    """Capannone / sala / box / valvola."""

    __tablename__ = "location"
    __table_args__ = (UniqueConstraint("site_id", "name"),)

    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id"), index=True)
    name: Mapped[str] = mapped_column(String(100))
    kind: Mapped[str | None] = mapped_column(String(30))


class Occupancy(TenantMixin, Base):
    __tablename__ = "occupancy"

    location_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("location.id"), index=True)
    destination_lot_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("destination_lot.id"), index=True
    )
    date_from: Mapped[date] = mapped_column(Date)
    date_to: Mapped[date | None] = mapped_column(Date)


class AccountingPeriod(TenantMixin, Base):
    """Periodo contabile mensile; la chiusura è usata da F6 (RF-11)."""

    __tablename__ = "accounting_period"
    __table_args__ = (UniqueConstraint("tenant_id", "year", "month"),)

    year: Mapped[int] = mapped_column(Integer)
    month: Mapped[int] = mapped_column(Integer)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


# --- Fase 2: lotti, ingressi, movimenti (RF-02, RF-03) -------------------------------
class Lot(TenantMixin, Base):
    """Lotto di materia prima, di miscela (F3) o lotto sintetico NON ALLOCATO (D7)."""

    __tablename__ = "lot"
    __table_args__ = (
        UniqueConstraint("tenant_id", "site_id", "internal_code"),
        Index(
            "ix_lot_daily_key", "tenant_id", "daily_key", unique=True,
            postgresql_where=text("daily_key IS NOT NULL"),
        ),
        Index("ix_lot_supplier", "tenant_id", "supplier_id", "entry_date"),
    )

    kind: Mapped[str] = mapped_column(String(20), default="MATERIA_PRIMA")
    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id"), index=True)
    internal_code: Mapped[str] = mapped_column(String(60))
    material_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("raw_material.id"), index=True
    )
    supplier_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("supplier.id"))
    supplier_lot: Mapped[str | None] = mapped_column(String(60))
    entry_date: Mapped[date | None] = mapped_column(Date)
    ddt_number: Mapped[str | None] = mapped_column(String(40))
    ddt_date: Mapped[date | None] = mapped_column(Date)
    plate: Mapped[str | None] = mapped_column(String(20))
    initial_qty: Mapped[Decimal | None] = mapped_column(Numeric(18, 3))
    price_eur_t: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    origin_country: Mapped[str | None] = mapped_column(String(60))
    origin_region: Mapped[str | None] = mapped_column(String(60))
    origin_province: Mapped[str | None] = mapped_column(String(60))
    self_produced: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    typical_zone: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    expiry_date: Mapped[date | None] = mapped_column(Date)
    status: Mapped[str] = mapped_column(
        String(20), default="DISPONIBILE", server_default="DISPONIBILE"
    )
    receipt_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("goods_receipt.id"), index=True
    )
    # lotti miscela (F3)
    plant_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("plant.id"))
    recipe_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("recipe.id"))
    lot_date: Mapped[date | None] = mapped_column(Date)
    daily_key: Mapped[str | None] = mapped_column(String(200))
    medicated: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")


class GoodsReceipt(TenantMixin, Base):
    """Ingresso da DDT. I lotti creati sono quelli con receipt_id = id."""

    __tablename__ = "goods_receipt"

    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id"), index=True)
    supplier_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("supplier.id"))
    ddt_number: Mapped[str | None] = mapped_column(String(40))
    ddt_date: Mapped[date | None] = mapped_column(Date)
    plate: Mapped[str | None] = mapped_column(String(20))
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    notes: Mapped[str | None] = mapped_column(String(500))
    operation_id: Mapped[uuid.UUID] = mapped_column()
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("app_user.id"))


class Movement(Base):
    """Registro di carico/scarico IMMUTABILE: correzioni solo con STORNO (RF-14)."""

    __tablename__ = "movement"
    __table_args__ = (
        CheckConstraint("type = 'SVUOTAMENTO' OR quantity <> 0", name="movement_qty_not_zero"),
        UniqueConstraint("reverses_movement_id", name="movement_single_reversal"),
        Index("ix_movement_container_time", "tenant_id", "container_id", "occurred_at", "seq"),
        Index("ix_movement_lot", "tenant_id", "lot_id"),
        Index("ix_movement_operation", "tenant_id", "operation_id"),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    seq: Mapped[int] = mapped_column(BigInteger, Identity(), unique=True)  # ordine di registrazione
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenant.id"))
    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id"))
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    type: Mapped[str] = mapped_column(String(30))
    container_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("container.id"))
    lot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lot.id"))
    quantity: Mapped[Decimal] = mapped_column(Numeric(18, 3))  # kg, con segno
    operation_id: Mapped[uuid.UUID] = mapped_column()
    doc_type: Mapped[str | None] = mapped_column(String(30))
    doc_id: Mapped[uuid.UUID | None] = mapped_column()
    reason: Mapped[str | None] = mapped_column(String(500))
    closes_epoch: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    reverses_movement_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("movement.id"))
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("app_user.id"))


class Operation(Base):
    """Operazione idempotente: id generato dal client; la risposta viene riproposta (CLAUDE.md)."""

    __tablename__ = "operation"

    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenant.id"), primary_key=True)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(30))
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("app_user.id"))
    result: Mapped[dict] = mapped_column(JSONB)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class LotCounter(Base):
    """Progressivo giornaliero per sito dei codici lotto (D14)."""

    __tablename__ = "lot_counter"

    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenant.id"), primary_key=True)
    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id"), primary_key=True)
    kind: Mapped[str] = mapped_column(String(20), primary_key=True)
    day: Mapped[date] = mapped_column(Date, primary_key=True)
    last_value: Mapped[int] = mapped_column(Integer, default=0)


class Cleaning(TenantMixin, Base):
    """Svuotamento / pulizia / flushing di un contenitore (SPEC §5)."""

    __tablename__ = "cleaning"

    container_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("container.id"), index=True)
    type: Mapped[str] = mapped_column(String(20))
    after_medicated: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    operation_id: Mapped[uuid.UUID] = mapped_column()
    notes: Mapped[str | None] = mapped_column(String(500))
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("app_user.id"))


class Attachment(TenantMixin, Base):
    """Allegato (foto/PDF di DDT, cartellino, certificato) collegato a un ingresso o lotto."""

    __tablename__ = "attachment"

    target_type: Mapped[str] = mapped_column(String(20))  # receipt | lot
    target_id: Mapped[uuid.UUID] = mapped_column(index=True)
    filename: Mapped[str] = mapped_column(String(200))
    content_type: Mapped[str] = mapped_column(String(100))
    size: Mapped[int] = mapped_column(Integer)
    data: Mapped[bytes] = mapped_column(LargeBinary)
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("app_user.id"))


# --- Fase 3: produzione miscele e legami di tracciabilità (RF-04) ---------------------
class Production(TenantMixin, Base):
    __tablename__ = "production"
    __table_args__ = (Index("ix_production_plant_time", "tenant_id", "plant_id", "started_at"),)

    plant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("plant.id"))
    recipe_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("recipe.id"))  # versione usata
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    theoretical_qty: Mapped[Decimal] = mapped_column(Numeric(18, 3))  # kg richiesti
    actual_qty: Mapped[Decimal] = mapped_column(Numeric(18, 3))  # kg di miscela ottenuti
    source: Mapped[str] = mapped_column(String(10), default="MANUALE", server_default="MANUALE")
    status: Mapped[str] = mapped_column(
        String(12), default="REGISTRATA", server_default="REGISTRATA"
    )
    mix_lot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lot.id"), index=True)
    destination_container_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("container.id"))
    operation_id: Mapped[uuid.UUID] = mapped_column()
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("app_user.id"))
    notes: Mapped[str | None] = mapped_column(String(500))
    warnings: Mapped[list] = mapped_column(JSONB, default=list, server_default="[]")
    overrides: Mapped[list] = mapped_column(JSONB, default=list, server_default="[]")
    reversed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reversal_reason: Mapped[str | None] = mapped_column(String(500))


class ProductionLine(TenantMixin, Base):
    __tablename__ = "production_line"

    production_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("production.id"), index=True)
    position: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    material_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("raw_material.id"))
    container_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("container.id"))
    theoretical_qty: Mapped[Decimal] = mapped_column(Numeric(18, 3))
    actual_qty: Mapped[Decimal] = mapped_column(Numeric(18, 3))
    deviation_pct: Mapped[Decimal | None] = mapped_column(Numeric(9, 2))
    tolerance_pct: Mapped[Decimal | None] = mapped_column(Numeric(7, 3))
    allocations: Mapped[list] = mapped_column(JSONB, default=list, server_default="[]")


class TraceLink(TenantMixin, Base):
    """Legame di tracciabilità lotto -> lotto, append-only; le correzioni sono righe con segno
    opposto (storno). CERTO = consumo effettivo; POSSIBILE = presenza per TUTTI_PRESENTI."""

    __tablename__ = "trace_link"
    __table_args__ = (
        Index("ix_trace_link_to", "tenant_id", "to_lot_id"),
        Index("ix_trace_link_from", "tenant_id", "from_lot_id"),
    )

    from_lot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lot.id"))
    # destinazione: un lotto (miscela) oppure un lotto di destinazione (scarico), mai entrambi.
    # Le FK dei campi aggiunti in F4 sono create dalla migrazione 0004.
    to_lot_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("lot.id"))
    to_destination_lot_id: Mapped[uuid.UUID | None] = mapped_column()
    discharge_id: Mapped[uuid.UUID | None] = mapped_column()
    quantity: Mapped[Decimal] = mapped_column(Numeric(18, 3))  # con segno
    kind: Mapped[str] = mapped_column(String(10))  # CERTO | POSSIBILE
    production_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("production.id"))
    production_line_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("production_line.id"))
    operation_id: Mapped[uuid.UUID] = mapped_column()
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

# --- Fase 4: scarichi verso lotti di destinazione e import di operazioni (RF-05, RF-06) ---
class Discharge(TenantMixin, Base):
    """Scarico da un contenitore a un lotto di destinazione, per data o periodo."""

    __tablename__ = "discharge"
    __table_args__ = (
        Index("ix_discharge_dest", "tenant_id", "destination_lot_id", "period_to"),
        Index("ix_discharge_container", "tenant_id", "container_id"),
    )

    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id"))
    container_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("container.id"))
    destination_lot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("destination_lot.id"))
    location_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("location.id"))
    period_from: Mapped[date] = mapped_column(Date)
    period_to: Mapped[date] = mapped_column(Date)
    quantity: Mapped[Decimal] = mapped_column(Numeric(18, 3))  # kg
    source: Mapped[str] = mapped_column(String(10), default="MANUALE", server_default="MANUALE")
    status: Mapped[str] = mapped_column(
        String(12), default="REGISTRATO", server_default="REGISTRATO"
    )
    operation_id: Mapped[uuid.UUID] = mapped_column()
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("app_user.id"))
    notes: Mapped[str | None] = mapped_column(String(500))
    import_row_id: Mapped[uuid.UUID | None] = mapped_column()
    production_id: Mapped[uuid.UUID | None] = mapped_column()  # scarico contestuale (carro/broda)
    warnings: Mapped[list] = mapped_column(JSONB, default=list, server_default="[]")
    allocations: Mapped[list] = mapped_column(JSONB, default=list, server_default="[]")
    reversed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reversal_reason: Mapped[str | None] = mapped_column(String(500))


class ImportMapping(TenantMixin, ActiveMixin, Base):
    """Mappatura salvabile per formato di file (es. "Export broda impianto X")."""

    __tablename__ = "import_mapping"
    __table_args__ = (UniqueConstraint("tenant_id", "name"),)

    name: Mapped[str] = mapped_column(String(120))
    entity: Mapped[str] = mapped_column(String(20))
    config: Mapped[dict] = mapped_column(JSONB)


class ImportFile(TenantMixin, Base):
    """File importato: anteprima (PREVIEW) poi applicazione (APPLIED). Idempotente sull'hash."""

    __tablename__ = "import_file"
    __table_args__ = (
        Index(
            "ix_import_file_applied_hash", "tenant_id", "sha256", unique=True,
            postgresql_where=text("status = 'APPLIED'"),
        ),
    )

    entity: Mapped[str] = mapped_column(String(20))
    filename: Mapped[str] = mapped_column(String(200))
    sha256: Mapped[str] = mapped_column(String(64))
    mapping_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("import_mapping.id"))
    mapping_snapshot: Mapped[dict] = mapped_column(JSONB)
    status: Mapped[str] = mapped_column(String(10), default="PREVIEW", server_default="PREVIEW")
    total: Mapped[int] = mapped_column(Integer, default=0)
    ok_count: Mapped[int] = mapped_column(Integer, default=0)
    error_count: Mapped[int] = mapped_column(Integer, default=0)
    duplicate_count: Mapped[int] = mapped_column(Integer, default=0)
    applied_count: Mapped[int] = mapped_column(Integer, default=0)
    failed_count: Mapped[int] = mapped_column(Integer, default=0)
    content: Mapped[bytes] = mapped_column(LargeBinary)
    applied_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("app_user.id"))


class ImportRow(TenantMixin, Base):
    __tablename__ = "import_row"
    __table_args__ = (
        Index(
            "ix_import_row_applied_key", "tenant_id", "applied_key", unique=True,
            postgresql_where=text("applied_key IS NOT NULL"),
        ),
        Index("ix_import_row_file", "tenant_id", "file_id", "line"),
    )

    file_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("import_file.id"))
    line: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(10))  # OK ERROR DUPLICATE APPLIED FAILED
    natural_key: Mapped[str] = mapped_column(String(300))
    raw: Mapped[dict] = mapped_column(JSONB)
    payload: Mapped[dict | None] = mapped_column(JSONB)
    message: Mapped[str | None] = mapped_column(String(500))
    operation_id: Mapped[uuid.UUID | None] = mapped_column()
    result_ref: Mapped[dict | None] = mapped_column(JSONB)
    applied_key: Mapped[str | None] = mapped_column(String(330))


# --- audit (immutabile: trigger + nessun privilegio UPDATE/DELETE) ------------------
class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenant.id"), index=True)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("app_user.id"))
    entity: Mapped[str] = mapped_column(String(60), index=True)
    entity_id: Mapped[uuid.UUID | None] = mapped_column(index=True)
    action: Mapped[str] = mapped_column(String(40))
    before: Mapped[dict | None] = mapped_column(JSONB)
    after: Mapped[dict | None] = mapped_column(JSONB)
    ip: Mapped[str | None] = mapped_column(String(64))
