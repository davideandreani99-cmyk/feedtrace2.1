"""Schemi della Fase 5: tracciabilità avanti/indietro e simulazione di richiamo (RF-07)."""

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel


class NodeContainerOut(BaseModel):
    container_id: uuid.UUID
    container_code: str
    quantity: Decimal  # giacenza attuale del lotto in quel contenitore


class TraceNodeOut(BaseModel):
    id: str  # uuid del lotto oppure "dest:<uuid>" per un lotto di destinazione
    node_type: Literal["LOT", "DESTINATION"]
    label: str
    kind: str  # MATERIA_PRIMA | MISCELA | NON_ALLOCATO | DESTINAZIONE
    status: str | None = None
    depth: int = 0
    material_code: str | None = None
    material_name: str | None = None
    recipe_code: str | None = None
    recipe_version: int | None = None
    supplier_id: uuid.UUID | None = None
    supplier_name: str | None = None
    supplier_lot: str | None = None
    ddt_number: str | None = None
    ddt_date: date | None = None
    entry_date: date | None = None
    external_code: str | None = None  # codice Pig'UP
    site_name: str | None = None
    containers: list[NodeContainerOut] = []
    analyses: list[dict] = []  # analisi di laboratorio: disponibili con la Fase 6 (RF-08)


class TraceEdgeOut(BaseModel):
    source: str
    target: str
    quantity: Decimal  # kg attribuiti
    kind: str  # CERTO | POSSIBILE
    depth: int


class TraceResultRow(BaseModel):
    node_id: str
    certain_kg: Decimal
    possible_kg: Decimal


class TraceOut(BaseModel):
    direction: Literal["backward", "forward"]
    starts: list[str]
    start_label: str
    amount: Decimal
    nodes: list[TraceNodeOut]
    edges: list[TraceEdgeOut]
    results: list[TraceResultRow]  # foglie: lotti MP (indietro) o lotti di destinazione (avanti)
    warnings: list[str] = []
    truncated: bool = False
    generated_at: datetime


class RecallDestinationOut(BaseModel):
    destination_lot_id: uuid.UUID
    code: str
    external_code: str | None
    status: str
    phase: str | None
    head_count: int | None
    site_name: str | None
    certain_kg: Decimal
    possible_kg: Decimal
    first_period: date | None
    last_period: date | None
    contact_name: str | None
    contact_phone: str | None
    contact_email: str | None


class RecallMixLotOut(BaseModel):
    lot_id: uuid.UUID
    code: str
    recipe_code: str | None
    kg: Decimal


class RecallStockOut(BaseModel):
    lot_id: uuid.UUID
    lot_code: str
    container_id: uuid.UUID
    container_code: str
    quantity: Decimal


class RecallOut(BaseModel):
    """Simulazione di richiamo: tutto ciò che serve in un'unica schermata stampabile."""

    lot: TraceNodeOut
    total_certain_kg: Decimal
    total_possible_kg: Decimal
    destinations: list[RecallDestinationOut]
    mix_lots: list[RecallMixLotOut]
    remaining_stock: list[RecallStockOut]  # ancora in giacenza: da bloccare subito
    warnings: list[str] = []
    truncated: bool = False
    generated_at: datetime
