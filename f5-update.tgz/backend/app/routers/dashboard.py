import uuid
from datetime import UTC, datetime, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import func, select

from app.deps import Ctx, require
from app.models import (
    Container,
    Discharge,
    GoodsReceipt,
    ImportFile,
    Lot,
    Movement,
    Plant,
    Production,
    RawMaterial,
    Recipe,
)
from app.routers.stock import anomalies, containers_summary
from app.schemas_stock import AnomalyOut, ContainerSummaryOut
from domain.enums import LotStatus
from domain.permissions import Permission

router = APIRouter(tags=["dashboard"])


class BlockedLotOut(BaseModel):
    lot_id: uuid.UUID
    lot_code: str
    material_code: str | None
    status: str
    stock_kg: Decimal
    containers: list[str]


class ContaminatedOut(BaseModel):
    type: str  # CONTENITORE | IMPIANTO
    code: str


class DeviationOut(BaseModel):
    production_id: uuid.UUID
    started_at: datetime
    recipe_code: str
    message: str


class ImportIssueOut(BaseModel):
    file_id: uuid.UUID
    filename: str
    entity: str
    status: str
    error_count: int
    failed_count: int


class RecentOut(BaseModel):
    receipts_7d: int
    productions_7d: int
    discharges_7d: int


class DashboardOut(BaseModel):
    generated_at: datetime
    total_stock_kg: Decimal
    containers: list[ContainerSummaryOut]
    blocked_lots: list[BlockedLotOut]  # in quarantena, non conformi o bloccati con giacenza
    contaminated: list[ContaminatedOut]
    expiring_prescriptions: list[dict]  # REV in scadenza: disponibili con la Fase 6
    negative_stock: list[AnomalyOut]
    deviations: list[DeviationOut]
    import_issues: list[ImportIssueOut]
    recent: RecentOut


@router.get("/dashboard", response_model=DashboardOut)
def dashboard(ctx: Ctx = Depends(require(Permission.STOCK_READ))):
    """Cruscotto: giacenze, lotti bloccati, contaminazioni, anomalie, scostamenti, import in errore."""
    db, tenant = ctx.db, ctx.tenant_id
    now = datetime.now(UTC)
    containers = containers_summary(site_id=None, active=True, ctx=ctx)

    blocked_statuses = [LotStatus.IN_QUARANTENA.value, LotStatus.NON_CONFORME.value, LotStatus.BLOCCATO.value]
    blocked: dict[uuid.UUID, BlockedLotOut] = {}
    rows = db.execute(
        select(Lot.id, Lot.internal_code, RawMaterial.code, Lot.status, Container.code,
               func.sum(Movement.quantity))
        .join(Movement, Movement.lot_id == Lot.id)
        .join(Container, Container.id == Movement.container_id)
        .outerjoin(RawMaterial, RawMaterial.id == Lot.material_id)
        .where(Lot.tenant_id == tenant, Lot.status.in_(blocked_statuses))
        .group_by(Lot.id, Lot.internal_code, RawMaterial.code, Lot.status, Container.code)
        .having(func.sum(Movement.quantity) > 0)
    ).all()
    for lot_id, code, material, status, container, quantity in rows:
        item = blocked.setdefault(lot_id, BlockedLotOut(
            lot_id=lot_id, lot_code=code, material_code=material, status=status,
            stock_kg=Decimal("0"), containers=[]))
        item.stock_kg += quantity
        item.containers.append(container)

    contaminated = [
        ContaminatedOut(type="CONTENITORE", code=c) for (c,) in db.execute(
            select(Container.code).where(Container.tenant_id == tenant,
                                         Container.medicated_contaminated.is_(True)))
    ] + [
        ContaminatedOut(type="IMPIANTO", code=c) for (c,) in db.execute(
            select(Plant.code).where(Plant.tenant_id == tenant, Plant.medicated_contaminated.is_(True)))
    ]

    deviations: list[DeviationOut] = []
    for production, recipe_code in db.execute(
        select(Production, Recipe.code)
        .join(Recipe, Recipe.id == Production.recipe_id)
        .where(Production.tenant_id == tenant, Production.status == "REGISTRATA",
               Production.started_at >= now - timedelta(days=30))
        .order_by(Production.started_at.desc()).limit(200)
    ):
        for warning in production.warnings:
            if warning.get("code") == "DEVIATION":
                deviations.append(DeviationOut(production_id=production.id, started_at=production.started_at,
                                               recipe_code=recipe_code, message=warning["message"]))
    issues = [
        ImportIssueOut(file_id=f.id, filename=f.filename, entity=f.entity, status=f.status,
                       error_count=f.error_count, failed_count=f.failed_count)
        for f in db.scalars(
            select(ImportFile)
            .where(ImportFile.tenant_id == tenant, ImportFile.status.in_(["PREVIEW", "APPLIED"]),
                   (ImportFile.error_count > 0) | (ImportFile.failed_count > 0))
            .order_by(ImportFile.created_at.desc()).limit(20)
        )
    ]
    week = now - timedelta(days=7)

    def count(model, column) -> int:
        return db.scalar(select(func.count()).select_from(model)
                         .where(model.tenant_id == tenant, column >= week)) or 0

    return DashboardOut(
        generated_at=now,
        total_stock_kg=sum((c.total for c in containers), Decimal("0")),
        containers=containers,
        blocked_lots=list(blocked.values()),
        contaminated=contaminated,
        expiring_prescriptions=[],
        negative_stock=anomalies(ctx=ctx),
        deviations=deviations[:50],
        import_issues=issues,
        recent=RecentOut(
            receipts_7d=count(GoodsReceipt, GoodsReceipt.received_at),
            productions_7d=count(Production, Production.started_at),
            discharges_7d=count(Discharge, Discharge.created_at),
        ),
    )
