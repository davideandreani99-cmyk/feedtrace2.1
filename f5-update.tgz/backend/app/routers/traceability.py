import uuid
from datetime import date, datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, Query

from app.deps import Ctx, require
from app.schemas_trace import RecallOut, TraceOut
from app.services import traceability as service
from domain.permissions import Permission

router = APIRouter(prefix="/traceability", tags=["traceability"])


@router.get("/backward", response_model=TraceOut)
def backward(
    lot_id: uuid.UUID | None = Query(None, description="Lotto (MP o miscela)"),
    destination_lot_id: uuid.UUID | None = Query(None, description="Lotto di destinazione"),
    container_id: uuid.UUID | None = Query(None, description="Contenitore (con `at`)"),
    at: datetime | None = Query(None, description="Data/ora per la composizione del contenitore"),
    quantity: Decimal | None = Query(None, gt=0, description="kg da tracciare (default: tutto)"),
    ctx: Ctx = Depends(require(Permission.STOCK_READ)),
):
    """Tracciabilità all'indietro: fino ai lotti di materia prima, con fornitore, DDT e quote
    attribuite, distinguendo legami CERTI e POSSIBILI."""
    return service.trace_backward(
        ctx, lot_id=lot_id, destination_lot_id=destination_lot_id, container_id=container_id,
        at=at, quantity=quantity,
    )


@router.get("/forward", response_model=TraceOut)
def forward(
    lot_id: uuid.UUID | None = Query(None, description="Lotto MP o miscela"),
    supplier_id: uuid.UUID | None = Query(None, description="Fornitore (con periodo di ingresso)"),
    date_from: date | None = None,
    date_to: date | None = None,
    ctx: Ctx = Depends(require(Permission.STOCK_READ)),
):
    """Tracciabilità in avanti: miscele, contenitori e lotti di destinazione raggiunti."""
    return service.trace_forward(
        ctx, lot_id=lot_id, supplier_id=supplier_id, date_from=date_from, date_to=date_to
    )


@router.get("/recall/{lot_id}", response_model=RecallOut)
def recall(lot_id: uuid.UUID, ctx: Ctx = Depends(require(Permission.STOCK_READ))):
    """Simulazione di richiamo da un lotto: destinazioni coinvolte con quantità e contatti."""
    return service.recall(ctx, lot_id)
