import re
import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response

from app.deps import Ctx, require
from app.reports import builders
from app.reports.render import Report, render_pdf, render_xlsx
from app.services import traceability as trace_service
from domain.permissions import Permission

router = APIRouter(prefix="/reports", tags=["reports"])

PDF = "application/pdf"
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def _respond(report: Report, fmt: str) -> Response:
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", report.filename)[:80] or "report"
    if fmt == "xlsx":
        return Response(render_xlsx(report), media_type=XLSX,
                        headers={"Content-Disposition": f'attachment; filename="{name}.xlsx"'})
    return Response(render_pdf(report), media_type=PDF,
                    headers={"Content-Disposition": f'attachment; filename="{name}.pdf"'})


Format = Literal["pdf", "xlsx"]


@router.get("/traceability")
def traceability_report(
    direction: Literal["backward", "forward"],
    format: Format = "pdf",
    lot_id: uuid.UUID | None = None,
    destination_lot_id: uuid.UUID | None = None,
    container_id: uuid.UUID | None = None,
    at: datetime | None = None,
    quantity: Decimal | None = Query(None, gt=0),
    supplier_id: uuid.UUID | None = None,
    date_from: date | None = None,
    date_to: date | None = None,
    ctx: Ctx = Depends(require(Permission.STOCK_READ)),
):
    """Scheda di tracciabilità in PDF o Excel (stessi parametri degli endpoint di tracciabilità)."""
    if direction == "backward":
        trace = trace_service.trace_backward(
            ctx, lot_id=lot_id, destination_lot_id=destination_lot_id, container_id=container_id,
            at=at, quantity=quantity,
        )
    else:
        trace = trace_service.trace_forward(
            ctx, lot_id=lot_id, supplier_id=supplier_id, date_from=date_from, date_to=date_to
        )
    return _respond(builders.traceability_report(ctx, trace), format)


@router.get("/recall/{lot_id}")
def recall_report(
    lot_id: uuid.UUID, format: Format = "pdf",
    ctx: Ctx = Depends(require(Permission.STOCK_READ)),
):
    """Simulazione di richiamo stampabile (schermata unica)."""
    return _respond(builders.recall_report(ctx, trace_service.recall(ctx, lot_id)), format)


@router.get("/ledger")
def ledger(
    site_id: uuid.UUID, date_from: date, date_to: date, format: Format = "pdf",
    ctx: Ctx = Depends(require(Permission.STOCK_READ)),
):
    """Registro di carico e scarico per sito e periodo (ASL / ente di controllo)."""
    return _respond(builders.ledger_report(ctx, site_id, date_from, date_to), format)
