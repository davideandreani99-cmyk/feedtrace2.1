"""Tracciabilità avanti e indietro, simulazione di richiamo (RF-07).

I legami (`trace_link`) sono scritti insieme ai movimenti, quindi la query è un'esplorazione per
livelli (una query per livello, indici su (tenant, lotto)); le quote sono calcolate dal dominio
puro (`domain.traceability`).
"""

import uuid
from collections import defaultdict
from datetime import UTC, date, datetime
from decimal import ROUND_HALF_UP, Decimal

from fastapi import HTTPException
from sqlalchemy import func, or_, select

from app.deps import Ctx
from app.models import (
    Container,
    DestinationLot,
    Discharge,
    Lot,
    Movement,
    RawMaterial,
    Recipe,
    Site,
    Supplier,
    TraceLink,
)
from app.schemas_trace import (
    NodeContainerOut,
    RecallDestinationOut,
    RecallMixLotOut,
    RecallOut,
    RecallStockOut,
    TraceEdgeOut,
    TraceNodeOut,
    TraceOut,
    TraceResultRow,
)
from app.services import stock
from domain.traceability import MAX_DEPTH, Edge, Graph, TraceEdge, TraceResult, trace

DEST = "dest:"
ZERO = Decimal("0")


def _q(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.001"), rounding=ROUND_HALF_UP)


def _split(node: str) -> tuple[bool, uuid.UUID]:
    return (True, uuid.UUID(node[len(DEST):])) if node.startswith(DEST) else (False, uuid.UUID(node))


# --- costruzione del grafo, un livello per query ---------------------------------------------
def load_graph(
    ctx: Ctx, start_ids: set[str], direction: str, max_depth: int = MAX_DEPTH
) -> tuple[list[Edge], set[str]]:
    db = ctx.db
    edges: dict[tuple[str, str, str], Decimal] = defaultdict(Decimal)
    nodes = set(start_ids)
    frontier = set(start_ids)
    for _ in range(max_depth + 1):  # un livello in più per rilevare il troncamento
        lots = [_split(n)[1] for n in frontier if not _split(n)[0]]
        dests = [_split(n)[1] for n in frontier if _split(n)[0]]
        if direction == "backward":
            condition = or_(
                TraceLink.to_lot_id.in_(lots), TraceLink.to_destination_lot_id.in_(dests)
            )
        else:
            condition = TraceLink.from_lot_id.in_(lots)
        rows = db.execute(
            select(
                TraceLink.from_lot_id, TraceLink.to_lot_id, TraceLink.to_destination_lot_id,
                TraceLink.kind, func.sum(TraceLink.quantity),
            )
            .where(TraceLink.tenant_id == ctx.tenant_id, condition)
            .group_by(
                TraceLink.from_lot_id, TraceLink.to_lot_id, TraceLink.to_destination_lot_id,
                TraceLink.kind,
            )
            .having(func.sum(TraceLink.quantity) != 0)
        ).all()
        new_nodes: set[str] = set()
        for from_id, to_lot, to_dest, kind, quantity in rows:
            source = str(from_id)
            target = str(to_lot) if to_lot else f"{DEST}{to_dest}"
            edges[(source, target, kind)] += quantity
            node = source if direction == "backward" else target
            if node not in nodes and not node.startswith(DEST):
                new_nodes.add(node)
        frontier = new_nodes
        nodes |= new_nodes
        if not frontier:
            break
    all_nodes = set(nodes)
    for source, target, _ in edges:
        all_nodes.update((source, target))
    return [Edge(s, t, q, k) for (s, t, k), q in edges.items()], all_nodes


def _produced(ctx: Ctx, edges: list[Edge], nodes: set[str]) -> dict[str, Decimal]:
    """Denominatore delle quote: kg prodotti dalla miscela; per gli altri lotti i kg consumati
    (legami CERTI uscenti); per un lotto di destinazione i kg ricevuti (legami CERTI entranti)."""
    certain_out: dict[str, Decimal] = defaultdict(Decimal)
    received: dict[str, Decimal] = defaultdict(Decimal)
    for edge in edges:
        if edge.kind == "CERTO":
            certain_out[edge.source] += edge.quantity
            if edge.target.startswith(DEST):
                received[edge.target] += edge.quantity
    lot_ids = [_split(n)[1] for n in nodes if not n.startswith(DEST)]
    result: dict[str, Decimal] = {}
    for lot in ctx.db.scalars(
        select(Lot).where(Lot.id.in_(lot_ids or [uuid.uuid4()]), Lot.tenant_id == ctx.tenant_id)
    ):
        if lot.kind == "MISCELA" and lot.initial_qty:
            result[str(lot.id)] = lot.initial_qty
        elif certain_out.get(str(lot.id)):
            result[str(lot.id)] = certain_out[str(lot.id)]
    result.update(received)
    return result

# --- anagrafica dei nodi -------------------------------------------------------------------------
def _node_details(ctx: Ctx, node_ids: set[str], depths: dict[str, int]) -> list[TraceNodeOut]:
    db = ctx.db
    lot_ids = [_split(n)[1] for n in node_ids if not n.startswith(DEST)]
    dest_ids = [_split(n)[1] for n in node_ids if n.startswith(DEST)]
    lots = {row.id: row for row in db.scalars(select(Lot).where(Lot.id.in_(lot_ids or [uuid.uuid4()]), Lot.tenant_id == ctx.tenant_id))}
    dests = {row.id: row for row in db.scalars(select(DestinationLot).where(
        DestinationLot.id.in_(dest_ids or [uuid.uuid4()]), DestinationLot.tenant_id == ctx.tenant_id))}
    materials = {row.id: row for row in db.scalars(select(RawMaterial).where(
        RawMaterial.id.in_([x.material_id for x in lots.values() if x.material_id] or [uuid.uuid4()])))}
    suppliers = {row.id: row for row in db.scalars(select(Supplier).where(
        Supplier.id.in_([x.supplier_id for x in lots.values() if x.supplier_id] or [uuid.uuid4()])))}
    recipes = {row.id: row for row in db.scalars(select(Recipe).where(
        Recipe.id.in_([x.recipe_id for x in lots.values() if x.recipe_id] or [uuid.uuid4()])))}
    sites = {row.id: row for row in db.scalars(select(Site).where(
        Site.id.in_([x.site_id for x in dests.values()] or [uuid.uuid4()])))}
    placed: dict[uuid.UUID, list[NodeContainerOut]] = defaultdict(list)
    for lot_id, container_id, code, quantity in db.execute(
        select(Movement.lot_id, Movement.container_id, Container.code, func.sum(Movement.quantity))
        .join(Container, Container.id == Movement.container_id)
        .where(Movement.tenant_id == ctx.tenant_id, Movement.lot_id.in_(lot_ids or [uuid.uuid4()]))
        .group_by(Movement.lot_id, Movement.container_id, Container.code)
        .having(func.sum(Movement.quantity) != 0)
    ):
        placed[lot_id].append(NodeContainerOut(container_id=container_id, container_code=code, quantity=_q(quantity)))

    out: list[TraceNodeOut] = []
    for node in sorted(node_ids, key=lambda n: (depths.get(n, 0), n)):
        is_dest, key = _split(node)
        if is_dest:
            dest = dests.get(key)
            if dest is None:
                continue
            site = sites.get(dest.site_id)
            out.append(TraceNodeOut(
                id=node, node_type="DESTINATION", label=dest.internal_code, kind="DESTINAZIONE",
                status=dest.status, depth=depths.get(node, 0), external_code=dest.external_code,
                site_name=site.name if site else None))
            continue
        lot = lots.get(key)
        if lot is None:
            continue
        material, supplier, recipe = (materials.get(lot.material_id), suppliers.get(lot.supplier_id),
                                      recipes.get(lot.recipe_id))
        out.append(TraceNodeOut(
            id=node, node_type="LOT", label=lot.internal_code, kind=lot.kind, status=lot.status,
            depth=depths.get(node, 0),
            material_code=material.code if material else None,
            material_name=material.name if material else None,
            recipe_code=recipe.code if recipe else None,
            recipe_version=recipe.version if recipe else None,
            supplier_id=lot.supplier_id, supplier_name=supplier.name if supplier else None,
            supplier_lot=lot.supplier_lot, ddt_number=lot.ddt_number, ddt_date=lot.ddt_date,
            entry_date=lot.entry_date, containers=placed.get(key, []),
        ))
    return out


# --- esecuzione ------------------------------------------------------------------------------------
def _run(
    ctx: Ctx, starts: dict[str, Decimal | None], direction: str, max_depth: int = MAX_DEPTH
) -> tuple[TraceResult, set[str], dict[str, int], Graph]:
    edges, nodes = load_graph(ctx, set(starts), direction, max_depth)
    graph = Graph.build(edges, _produced(ctx, edges, nodes))
    merged = TraceResult([], {}, {}, [], False)
    flows: dict[tuple[str, str, str], tuple[Decimal, int]] = {}
    for start, amount in starts.items():
        result = trace(graph, start, direction, amount, max_depth)
        for node, value in result.certain.items():
            merged.certain[node] = merged.certain.get(node, ZERO) + value
        for node, value in result.possible.items():
            merged.possible[node] = merged.possible.get(node, ZERO) + value
        for w in result.warnings:
            if w not in merged.warnings:
                merged.warnings.append(w)
        merged.truncated = merged.truncated or result.truncated
        for e in result.edges:
            key = (e.source, e.target, e.kind)
            prev = flows.get(key, (ZERO, e.depth))
            flows[key] = (prev[0] + e.quantity, min(prev[1], e.depth))
    merged.edges = [TraceEdge(s, t, q, k, d) for (s, t, k), (q, d) in flows.items()]
    depths: dict[str, int] = {s: 0 for s in starts}
    for e in merged.edges:
        if direction == "backward":
            depths[e.source] = min(depths.get(e.source, e.depth), e.depth)
            depths[e.target] = min(depths.get(e.target, e.depth - 1), e.depth - 1)
        else:
            depths[e.target] = min(depths.get(e.target, e.depth), e.depth)
            depths[e.source] = min(depths.get(e.source, e.depth - 1), e.depth - 1)
    return merged, nodes, depths, graph


def _assemble(
    ctx: Ctx, direction: str, starts: dict[str, Decimal | None], label: str,
    merged: TraceResult, depths: dict[str, int], graph: Graph,
) -> TraceOut:
    visible = set(depths) | set(merged.certain) | set(merged.possible)
    nodes = _node_details(ctx, visible, depths)
    known = {n.id for n in nodes}
    edges = [
        TraceEdgeOut(source=e.source, target=e.target, quantity=_q(e.quantity), kind=e.kind, depth=e.depth)
        for e in merged.edges if e.source in known and e.target in known and _q(e.quantity) != 0
    ]
    results = [
        TraceResultRow(node_id=n, certain_kg=_q(merged.certain.get(n, ZERO)),
                       possible_kg=_q(merged.possible.get(n, ZERO)))
        for n in sorted(set(merged.certain) | set(merged.possible)) if n in known
    ]
    amount = sum((v if v is not None else graph.produced.get(s, ZERO) for s, v in starts.items()), ZERO)
    return TraceOut(
        direction=direction, starts=list(starts), start_label=label, amount=_q(amount), nodes=nodes,
        edges=edges, results=results, warnings=merged.warnings, truncated=merged.truncated,
        generated_at=datetime.now(UTC),
    )


def _lot(ctx: Ctx, lot_id: uuid.UUID) -> Lot:
    lot = ctx.db.scalar(select(Lot).where(Lot.id == lot_id, Lot.tenant_id == ctx.tenant_id))
    if lot is None:
        raise HTTPException(status_code=404, detail="Lotto non trovato")
    return lot


def trace_backward(
    ctx: Ctx, *, lot_id: uuid.UUID | None, destination_lot_id: uuid.UUID | None,
    container_id: uuid.UUID | None, at: datetime | None, quantity: Decimal | None,
) -> TraceOut:
    chosen = [x for x in (lot_id, destination_lot_id, container_id) if x is not None]
    if len(chosen) != 1:
        raise HTTPException(
            status_code=422, detail="Indica uno solo tra lot_id, destination_lot_id, container_id")
    starts: dict[str, Decimal | None] = {}
    if lot_id is not None:
        lot = _lot(ctx, lot_id)
        starts[str(lot.id)] = quantity if quantity is not None else lot.initial_qty
        label = lot.internal_code
    elif destination_lot_id is not None:
        dest = ctx.db.scalar(select(DestinationLot).where(
            DestinationLot.id == destination_lot_id, DestinationLot.tenant_id == ctx.tenant_id))
        if dest is None:
            raise HTTPException(status_code=404, detail="Lotto di destinazione non trovato")
        starts[f"{DEST}{dest.id}"] = quantity
        label = dest.internal_code
    else:
        container = ctx.db.scalar(select(Container).where(
            Container.id == container_id, Container.tenant_id == ctx.tenant_id))
        if container is None:
            raise HTTPException(status_code=404, detail="Contenitore non trovato")
        when = at.replace(tzinfo=UTC) if at is not None and at.tzinfo is None else at
        for row in stock.load_stock(ctx.db, ctx.tenant_id, container.id, when):
            if row.quantity > 0:
                starts[str(row.lot_id)] = row.quantity
        label = f"{container.code}" + (f" al {when:%d/%m/%Y %H:%M}" if when else "")
        if not starts:
            raise HTTPException(status_code=404, detail="Il contenitore è vuoto alla data indicata")
    merged, _nodes, depths, graph = _run(ctx, starts, "backward")
    return _assemble(ctx, "backward", starts, label, merged, depths, graph)


def trace_forward(
    ctx: Ctx, *, lot_id: uuid.UUID | None, supplier_id: uuid.UUID | None,
    date_from: date | None, date_to: date | None,
) -> TraceOut:
    if (lot_id is None) == (supplier_id is None):
        raise HTTPException(status_code=422, detail="Indica uno solo tra lot_id e supplier_id")
    starts: dict[str, Decimal | None] = {}
    if lot_id is not None:
        lot = _lot(ctx, lot_id)
        starts[str(lot.id)] = None
        label = lot.internal_code
    else:
        supplier = ctx.db.scalar(select(Supplier).where(
            Supplier.id == supplier_id, Supplier.tenant_id == ctx.tenant_id))
        if supplier is None:
            raise HTTPException(status_code=404, detail="Fornitore non trovato")
        stmt = select(Lot.id).where(Lot.tenant_id == ctx.tenant_id, Lot.supplier_id == supplier.id)
        if date_from:
            stmt = stmt.where(Lot.entry_date >= date_from)
        if date_to:
            stmt = stmt.where(Lot.entry_date <= date_to)
        for (lid,) in ctx.db.execute(stmt.limit(500)):
            starts[str(lid)] = None
        label = supplier.name
        if not starts:
            raise HTTPException(status_code=404, detail="Nessun lotto del fornitore nel periodo")
    merged, _nodes, depths, graph = _run(ctx, starts, "forward")
    return _assemble(ctx, "forward", starts, label, merged, depths, graph)


# --- simulazione di richiamo -----------------------------------------------------------------------
def recall(ctx: Ctx, lot_id: uuid.UUID) -> RecallOut:
    lot = _lot(ctx, lot_id)
    starts: dict[str, Decimal | None] = {str(lot.id): None}
    merged, _nodes, depths, graph = _run(ctx, starts, "forward")
    trace_out = _assemble(ctx, "forward", starts, lot.internal_code, merged, depths, graph)
    by_id = {n.id: n for n in trace_out.nodes}
    dest_ids = [_split(r.node_id)[1] for r in trace_out.results if r.node_id.startswith(DEST)]

    details = {
        d.id: d for d in ctx.db.scalars(select(DestinationLot).where(
            DestinationLot.id.in_(dest_ids or [uuid.uuid4()]), DestinationLot.tenant_id == ctx.tenant_id))
    }
    sites = {s.id: s for s in ctx.db.scalars(select(Site).where(
        Site.id.in_([d.site_id for d in details.values()] or [uuid.uuid4()])))}
    periods = {
        d_id: (first, last)
        for d_id, first, last in ctx.db.execute(
            select(Discharge.destination_lot_id, func.min(Discharge.period_from), func.max(Discharge.period_to))
            .where(Discharge.tenant_id == ctx.tenant_id, Discharge.status == "REGISTRATO",
                   Discharge.destination_lot_id.in_(dest_ids or [uuid.uuid4()]))
            .group_by(Discharge.destination_lot_id)
        )
    }
    destinations = []
    for row in trace_out.results:
        if not row.node_id.startswith(DEST):
            continue
        dest = details.get(_split(row.node_id)[1])
        if dest is None:
            continue
        site = sites.get(dest.site_id)
        first, last = periods.get(dest.id, (None, None))
        destinations.append(RecallDestinationOut(
            destination_lot_id=dest.id, code=dest.internal_code, external_code=dest.external_code,
            status=dest.status, phase=dest.phase, head_count=dest.head_count,
            site_name=site.name if site else None, certain_kg=row.certain_kg,
            possible_kg=row.possible_kg, first_period=first, last_period=last,
            contact_name=site.contact_name if site else None,
            contact_phone=site.contact_phone if site else None,
            contact_email=site.contact_email if site else None,
        ))
    destinations.sort(key=lambda d: (-d.certain_kg, d.code))

    inflow: dict[str, Decimal] = defaultdict(Decimal)
    for edge in trace_out.edges:
        inflow[edge.target] += edge.quantity
    mix_lots = [
        RecallMixLotOut(lot_id=uuid.UUID(n.id), code=n.label, recipe_code=n.recipe_code, kg=inflow.get(n.id, ZERO))
        for n in trace_out.nodes if n.node_type == "LOT" and n.kind == "MISCELA"
    ]
    remaining = [
        RecallStockOut(lot_id=uuid.UUID(n.id), lot_code=n.label, container_id=c.container_id,
                       container_code=c.container_code, quantity=c.quantity)
        for n in trace_out.nodes if n.node_type == "LOT" for c in n.containers if c.quantity > 0
    ]
    return RecallOut(
        lot=by_id[str(lot.id)],
        total_certain_kg=sum((d.certain_kg for d in destinations), ZERO),
        total_possible_kg=sum((d.possible_kg for d in destinations), ZERO),
        destinations=destinations, mix_lots=mix_lots, remaining_stock=remaining,
        warnings=trace_out.warnings, truncated=trace_out.truncated, generated_at=datetime.now(UTC),
    )
