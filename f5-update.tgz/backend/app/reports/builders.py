"""Costruzione dei report (SPEC §6.12): scheda di tracciabilità, richiamo, registro di carico/scarico."""

import uuid
from collections import defaultdict
from datetime import UTC, date, datetime, time, timedelta
from decimal import Decimal
from zoneinfo import ZoneInfo

from fastapi import HTTPException
from sqlalchemy import and_, case, func, select

from app.deps import Ctx
from app.models import (
    AppUser,
    Container,
    GoodsReceipt,
    Lot,
    Movement,
    RawMaterial,
    Recipe,
    Site,
    Tenant,
)
from app.reports.render import Report, ReportTable, generated_now
from app.schemas_trace import RecallOut, TraceNodeOut, TraceOut

ROME = ZoneInfo("Europe/Rome")
ZERO = Decimal("0")
LEDGER_MAX_ROWS = 50000

KIND_LABEL = {
    "MATERIA_PRIMA": "Materia prima", "MISCELA": "Miscela", "NON_ALLOCATO": "Non allocato",
    "DESTINAZIONE": "Lotto di destinazione",
}


def header_meta(ctx: Ctx, site: Site | None = None) -> list[tuple[str, str]]:
    tenant = ctx.db.get(Tenant, ctx.tenant_id)
    company = tenant.name + (f" (P.IVA {tenant.vat_number})" if tenant and tenant.vat_number else "")
    meta = [("Azienda", company)]
    if site is not None:
        meta.append(("Sito", f"{site.name} (codice aziendale {site.asl_code})"))
    meta += [("Generato il", generated_now()),
             ("Utente", f"{ctx.user.full_name} ({ctx.user.email})")]
    return meta


def _node_lines(nodes: list[TraceNodeOut]) -> dict[str, TraceNodeOut]:
    return {n.id: n for n in nodes}


# --- scheda di tracciabilità --------------------------------------------------------------------
def traceability_report(ctx: Ctx, trace: TraceOut) -> Report:
    nodes = _node_lines(trace.nodes)
    forward = trace.direction == "forward"
    direction = "in avanti (a quali lotti è arrivato)" if forward else "all'indietro (da dove proviene)"
    summary = ReportTable(
        "Riepilogo",
        ["Partenza", "Direzione", "Quantità tracciata (kg)", "Nodi", "Legami"],
        [[trace.start_label, direction, trace.amount, len(trace.nodes), len(trace.edges)]],
        numeric={2, 3, 4},
    )
    if forward:
        rows = []
        for r in trace.results:
            n = nodes[r.node_id]
            rows.append([n.label, n.external_code, n.site_name, n.status, r.certain_kg, r.possible_kg])
        results = ReportTable(
            "Lotti di destinazione raggiunti",
            ["Lotto", "Codice Pig'UP", "Sito", "Stato", "kg certi", "kg possibili"], rows,
            numeric={4, 5}, widths=[2, 2, 3, 1.2, 1.6, 1.6],
        )
    else:
        rows = []
        for r in trace.results:
            n = nodes[r.node_id]
            rows.append([n.label, n.material_name or n.material_code, n.supplier_name, n.supplier_lot,
                         n.ddt_number, n.ddt_date, n.status, r.certain_kg, r.possible_kg])
        results = ReportTable(
            "Lotti di materia prima di provenienza",
            ["Lotto", "Materia prima", "Fornitore", "Lotto forn.", "DDT", "Data DDT", "Stato",
             "kg certi", "kg possibili"], rows, numeric={7, 8},
            widths=[2, 2.4, 2.4, 1.5, 1.3, 1.3, 1.5, 1.4, 1.4],
        )
    path_rows = [
        [nodes[e.source].label if e.source in nodes else e.source,
         nodes[e.target].label if e.target in nodes else e.target,
         KIND_LABEL.get(nodes[e.source].kind, "") if e.source in nodes else "", e.quantity, e.kind, e.depth]
        for e in trace.edges
    ]
    path = ReportTable("Percorso (quantità attribuite)",
                       ["Da", "A", "Tipo di origine", "kg", "Legame", "Livello"], path_rows,
                       numeric={3, 5}, widths=[2.5, 2.5, 1.8, 1.4, 1.2, 0.8])
    containers = [
        [n.label, c.container_code, c.quantity]
        for n in trace.nodes for c in n.containers if c.quantity > 0
    ]
    stock = ReportTable("Giacenze attuali dei lotti coinvolti", ["Lotto", "Contenitore", "kg"],
                        containers, numeric={2}, widths=[3, 3, 1.2])
    notes = [
        "Legame CERTO = consumo effettivo registrato; POSSIBILE = presenza nel contenitore per la "
        "politica TUTTI_PRESENTI. Le quote assumono la miscela omogenea: la quantità di un lotto "
        "attribuita a un valle/monte è proporzionale ai kg del lotto miscela.",
        "Le analisi di laboratorio dei lotti saranno riportate quando disponibili (Fase 6).",
        *[f"Avviso: {w}" for w in trace.warnings],
    ]
    if trace.truncated:
        notes.append("Profondità massima di ricerca raggiunta: il percorso potrebbe proseguire.")
    return Report(
        title=f"Scheda di tracciabilità — {trace.start_label}",
        meta=header_meta(ctx), tables=[summary, results, path, stock], notes=notes,
        filename=f"tracciabilita-{trace.direction}-{trace.start_label}",
    )


# --- richiamo ---------------------------------------------------------------------------------------
def recall_report(ctx: Ctx, recall: RecallOut) -> Report:
    lot = recall.lot
    info = ReportTable(
        "Lotto da richiamare",
        ["Lotto", "Tipo", "Materia prima / ricetta", "Fornitore", "Lotto forn.", "DDT", "Data DDT", "Stato"],
        [[lot.label, KIND_LABEL.get(lot.kind, lot.kind), lot.material_name or lot.recipe_code,
          lot.supplier_name, lot.supplier_lot, lot.ddt_number, lot.ddt_date, lot.status]],
    )
    destinations = ReportTable(
        "Lotti di destinazione coinvolti",
        ["Lotto", "Pig'UP", "Sito", "Fase", "Capi", "kg certi", "kg possibili", "Dal", "Al",
         "Referente", "Telefono", "Email"],
        [[d.code, d.external_code, d.site_name, d.phase, d.head_count, d.certain_kg, d.possible_kg,
          d.first_period, d.last_period, d.contact_name, d.contact_phone, d.contact_email]
         for d in recall.destinations],
        numeric={4, 5, 6}, widths=[1.6, 1.4, 2, 1.2, 0.8, 1.3, 1.3, 1.3, 1.3, 1.8, 1.5, 2.2],
    )
    mixes = ReportTable("Lotti miscela coinvolti", ["Lotto miscela", "Ricetta", "kg del lotto richiamato"],
                        [[m.code, m.recipe_code, m.kg] for m in recall.mix_lots], numeric={2})
    remaining = ReportTable(
        "Giacenze residue da bloccare", ["Lotto", "Contenitore", "kg"],
        [[s.lot_code, s.container_code, s.quantity] for s in recall.remaining_stock], numeric={2})
    totals = ReportTable(
        "Totali", ["Lotti di destinazione", "kg certi", "kg possibili"],
        [[len(recall.destinations), recall.total_certain_kg, recall.total_possible_kg]], numeric={0, 1, 2})
    return Report(
        title=f"Simulazione di richiamo — {lot.label}", meta=header_meta(ctx),
        tables=[info, totals, destinations, mixes, remaining],
        notes=["Simulazione: non registra alcuna operazione. I kg sono stime proporzionali alla quota "
               "del lotto nelle miscele (miscela omogenea).", *[f"Avviso: {w}" for w in recall.warnings]],
        filename=f"richiamo-{lot.label}",
    )


# --- registro di carico/scarico ----------------------------------------------------------------------
def _bounds(date_from: date, date_to: date) -> tuple[datetime, datetime]:
    start = datetime.combine(date_from, time.min, ROME).astimezone(UTC)
    end = datetime.combine(date_to + timedelta(days=1), time.min, ROME).astimezone(UTC)
    return start, end


def _article(kind: str, material_code: str | None, recipe_code: str | None) -> str:
    if kind == "MISCELA":
        return f"Miscela {recipe_code or ''}".strip()
    if kind == "NON_ALLOCATO":
        return "Non allocato"
    return material_code or "—"


def ledger_report(ctx: Ctx, site_id: uuid.UUID, date_from: date, date_to: date) -> Report:
    db = ctx.db
    site = db.scalar(select(Site).where(Site.id == site_id, Site.tenant_id == ctx.tenant_id))
    if site is None:
        raise HTTPException(status_code=404, detail="Sito non trovato")
    if date_from > date_to:
        raise HTTPException(status_code=422, detail="La data di inizio segue la data di fine")
    start, end = _bounds(date_from, date_to)

    movements = (
        select(
            Movement.occurred_at, Movement.type, Container.code, Lot.internal_code, Lot.kind,
            RawMaterial.code, Recipe.code, Movement.quantity, Movement.doc_type, GoodsReceipt.ddt_number,
            Movement.reason, AppUser.full_name,
        )
        .join(Container, Container.id == Movement.container_id)
        .join(Lot, Lot.id == Movement.lot_id)
        .outerjoin(RawMaterial, RawMaterial.id == Lot.material_id)
        .outerjoin(Recipe, Recipe.id == Lot.recipe_id)
        .outerjoin(AppUser, AppUser.id == Movement.user_id)
        .outerjoin(GoodsReceipt, and_(Movement.doc_type == "goods_receipt", GoodsReceipt.id == Movement.doc_id))
        .where(Movement.tenant_id == ctx.tenant_id, Movement.site_id == site.id,
               Movement.occurred_at >= start, Movement.occurred_at < end, Movement.quantity != 0)
        .order_by(Movement.occurred_at, Movement.seq)
        .limit(LEDGER_MAX_ROWS + 1)
    )
    rows = db.execute(movements).all()
    truncated = len(rows) > LEDGER_MAX_ROWS
    rows = rows[:LEDGER_MAX_ROWS]

    transfer = "TRASFERIMENTO"
    summary_cols = (Lot.kind, RawMaterial.code, Recipe.code)

    def grouped(*conditions):
        in_q = func.coalesce(func.sum(case((and_(Movement.quantity > 0, Movement.type != transfer), Movement.quantity), else_=0)), 0)
        out_q = func.coalesce(func.sum(case((and_(Movement.quantity < 0, Movement.type != transfer), Movement.quantity), else_=0)), 0)
        return db.execute(
            select(*summary_cols, func.sum(Movement.quantity), in_q, out_q)
            .join(Lot, Lot.id == Movement.lot_id)
            .outerjoin(RawMaterial, RawMaterial.id == Lot.material_id)
            .outerjoin(Recipe, Recipe.id == Lot.recipe_id)
            .where(Movement.tenant_id == ctx.tenant_id, Movement.site_id == site.id, *conditions)
            .group_by(*summary_cols)
        ).all()

    opening: dict[str, Decimal] = defaultdict(Decimal)
    for kind, mat, rec, total, _in, _out in grouped(Movement.occurred_at < start):
        opening[_article(kind, mat, rec)] += total
    loads: dict[str, Decimal] = defaultdict(Decimal)
    unloads: dict[str, Decimal] = defaultdict(Decimal)
    for kind, mat, rec, _total, q_in, q_out in grouped(Movement.occurred_at >= start, Movement.occurred_at < end):
        key = _article(kind, mat, rec)
        loads[key] += q_in
        unloads[key] += q_out
    articles = sorted(set(opening) | set(loads) | set(unloads))
    summary = ReportTable(
        "Riepilogo per articolo (kg)",
        ["Articolo", "Giacenza iniziale", "Carichi", "Scarichi", "Giacenza finale"],
        [[a, opening[a], loads[a], unloads[a], opening[a] + loads[a] + unloads[a]] for a in articles
         if any((opening[a], loads[a], unloads[a]))],
        numeric={1, 2, 3, 4}, widths=[3, 1.5, 1.5, 1.5, 1.5],
    )
    detail = ReportTable(
        "Movimenti",
        ["Data e ora", "Tipo", "Contenitore", "Lotto", "Articolo", "kg", "Documento", "Operatore", "Motivo"],
        [[occurred, mtype, container, lot_code, _article(kind, mat, rec), quantity,
          (f"DDT {ddt}" if ddt else (doc or "")), user or "", reason or ""]
         for occurred, mtype, container, lot_code, kind, mat, rec, quantity, doc, ddt, reason, user in rows],
        numeric={5}, widths=[1.6, 2, 1.4, 2.2, 1.8, 1.3, 1.5, 1.6, 2],
    )
    notes = ["I travasi tra contenitori dello stesso sito non sono conteggiati in carichi e scarichi.",
             "Il registro include storni e rettifiche: nessun movimento viene mai modificato o cancellato."]
    if truncated:
        notes.append(f"Registro troncato a {LEDGER_MAX_ROWS} righe: restringi il periodo.")
    return Report(
        title=f"Registro di carico e scarico dal {date_from:%d/%m/%Y} al {date_to:%d/%m/%Y}",
        meta=header_meta(ctx, site) + [("Periodo", f"{date_from:%d/%m/%Y} - {date_to:%d/%m/%Y} (ora italiana)")],
        tables=[summary, detail], notes=notes, filename=f"registro-{site.asl_code}-{date_from}-{date_to}",
    )
