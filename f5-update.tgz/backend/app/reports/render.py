"""Motore dei report: una descrizione unica (`Report`) resa in PDF (reportlab) e XLSX (openpyxl).

Ogni report ha intestazione con azienda, sito, data di generazione e utente (SPEC §6.12).
"""

import io
from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from decimal import Decimal
from typing import Any
from xml.sax.saxutils import escape
from zoneinfo import ZoneInfo

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

ROME = ZoneInfo("Europe/Rome")
PDF_MAX_ROWS = 5000  # oltre, il PDF viene troncato e si rimanda all'Excel


@dataclass
class ReportTable:
    title: str
    columns: list[str]
    rows: list[list[Any]]
    numeric: set[int] = field(default_factory=set)  # colonne numeriche (allineate a destra)
    widths: list[float] | None = None  # larghezze relative delle colonne


@dataclass
class Report:
    title: str
    meta: list[tuple[str, str]]
    tables: list[ReportTable]
    notes: list[str] = field(default_factory=list)
    filename: str = "report"
    landscape: bool = True


def fmt_number(value: Decimal | int | float, decimals: int = 3) -> str:
    text = f"{value:,.{decimals}f}"
    return text.replace(",", "§").replace(".", ",").replace("§", ".")


def fmt_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "sì" if value else "no"
    if isinstance(value, Decimal):
        return fmt_number(value)
    if isinstance(value, datetime):
        return value.astimezone(ROME).strftime("%d/%m/%Y %H:%M")
    if isinstance(value, date):
        return value.strftime("%d/%m/%Y")
    return str(value)


def generated_now() -> str:
    return datetime.now(UTC).astimezone(ROME).strftime("%d/%m/%Y %H:%M")


# --- PDF ---------------------------------------------------------------------------------------
def render_pdf(report: Report) -> bytes:
    buffer = io.BytesIO()
    page = landscape(A4) if report.landscape else A4
    doc = SimpleDocTemplate(
        buffer, pagesize=page, leftMargin=12 * mm, rightMargin=12 * mm, topMargin=14 * mm,
        bottomMargin=14 * mm, title=report.title, author="FeedTrace", pageCompression=0,
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("t", parent=styles["Title"], fontSize=15, alignment=0, spaceAfter=4)
    heading = ParagraphStyle("h", parent=styles["Heading3"], fontSize=10.5, spaceBefore=8, spaceAfter=3)
    cell = ParagraphStyle("c", parent=styles["BodyText"], fontSize=7.5, leading=9)
    cell_right = ParagraphStyle("cr", parent=cell, alignment=2)
    head = ParagraphStyle("hd", parent=cell, fontName="Helvetica-Bold")
    head_right = ParagraphStyle("hdr", parent=head, alignment=2)
    note = ParagraphStyle("n", parent=cell, fontSize=8, leading=10)

    story: list[Any] = [Paragraph(escape(report.title), title_style)]
    meta = Table([[Paragraph(f"<b>{escape(k)}</b>", cell), Paragraph(escape(v), cell)] for k, v in report.meta],
                 colWidths=[32 * mm, None], hAlign="LEFT")
    meta.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
                              ("TOPPADDING", (0, 0), (-1, -1), 1)]))
    story += [meta, Spacer(1, 4 * mm)]
    available = page[0] - 24 * mm

    for table in report.tables:
        story.append(Paragraph(escape(table.title), heading))
        rows = table.rows
        truncated = len(rows) > PDF_MAX_ROWS
        if truncated:
            rows = rows[:PDF_MAX_ROWS]
        data = [[Paragraph(escape(c), head_right if i in table.numeric else head)
                 for i, c in enumerate(table.columns)]]
        for row in rows:
            data.append([
                Paragraph(escape(fmt_value(v)), cell_right if i in table.numeric else cell)
                for i, v in enumerate(row)
            ])
        if not rows:
            data.append([Paragraph("Nessun dato", cell)] + [""] * (len(table.columns) - 1))
        weights = table.widths or [1.0] * len(table.columns)
        total = sum(weights)
        t = Table(data, colWidths=[available * w / total for w in weights], repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e5ece6")),
            ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#b9c4bb")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f6f8f6")]),
            ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ]))
        story.append(t)
        if truncated:
            story.append(Paragraph(
                f"Elenco troncato a {PDF_MAX_ROWS} righe: scarica l'Excel per l'elenco completo.", note))
    for text in report.notes:
        story += [Spacer(1, 2 * mm), Paragraph(escape(text), note)]

    footer = f"{report.title} — generato il {generated_now()}"

    def decorate(canvas, document) -> None:  # piè di pagina con numero di pagina
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor("#5d6b60"))
        canvas.drawString(12 * mm, 8 * mm, footer)
        canvas.drawRightString(page[0] - 12 * mm, 8 * mm, f"Pagina {document.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
    return buffer.getvalue()


# --- XLSX --------------------------------------------------------------------------------------
def render_xlsx(report: Report) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Report"
    bold = Font(bold=True)
    fill = PatternFill("solid", fgColor="E5ECE6")
    ws.append([report.title])
    ws["A1"].font = Font(bold=True, size=14)
    for key, value in report.meta:
        ws.append([key, value])
        ws.cell(row=ws.max_row, column=1).font = bold
    ws.append([])
    widths: dict[int, int] = {}

    def track(column: int, value: Any) -> None:
        widths[column] = max(widths.get(column, 8), min(len(fmt_value(value)) + 2, 50))

    for table in report.tables:
        ws.append([table.title])
        ws.cell(row=ws.max_row, column=1).font = Font(bold=True, size=11)
        ws.append(table.columns)
        for i, column in enumerate(table.columns, start=1):
            cell = ws.cell(row=ws.max_row, column=i)
            cell.font, cell.fill = bold, fill
            track(i, column)
        for row in table.rows:
            ws.append([float(v) if isinstance(v, Decimal) else
                       (v.astimezone(ROME).replace(tzinfo=None) if isinstance(v, datetime) else v)
                       for v in row])
            for i, value in enumerate(row, start=1):
                cell = ws.cell(row=ws.max_row, column=i)
                if isinstance(value, Decimal):
                    cell.number_format = "#,##0.000"
                    cell.alignment = Alignment(horizontal="right")
                elif isinstance(value, datetime):
                    cell.number_format = "dd/mm/yyyy hh:mm"
                elif isinstance(value, date):
                    cell.number_format = "dd/mm/yyyy"
                track(i, value)
        ws.append([])
    for text in report.notes:
        ws.append([text])
    for column, width in widths.items():
        ws.column_dimensions[get_column_letter(column)].width = width
    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()
