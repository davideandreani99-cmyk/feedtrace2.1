"""Attribuzione delle quantità lungo la catena di tracciabilità (RF-07, SPEC §6.7).

Scenario base: lotti MP A (10 t) e B (2 t consumati) → miscela M (12 t prodotti) → destinazioni
D1 (6 t) e D2 (6 t).
"""

from decimal import Decimal as D

from domain.traceability import Edge, Graph, trace


def base_graph() -> Graph:
    return Graph.build(
        edges=[
            Edge("A", "M", D("10000"), "CERTO"),
            Edge("B", "M", D("2000"), "CERTO"),
            Edge("M", "dest:D1", D("6000"), "CERTO"),
            Edge("M", "dest:D2", D("6000"), "CERTO"),
        ],
        produced={"M": D("12000"), "dest:D1": D("6000"), "dest:D2": D("6000"),
                  "A": D("10000"), "B": D("2000")},
    )


def q(value: D) -> D:
    return value.quantize(D("0.001"))


# --- all'indietro --------------------------------------------------------------------
def test_indietro_da_un_lotto_di_destinazione_quote_proporzionali():
    result = trace(base_graph(), "dest:D1", "backward")
    assert {k: q(v) for k, v in result.certain.items()} == {"A": D("5000.000"), "B": D("1000.000")}
    assert result.possible == {}
    assert not result.truncated and result.warnings == []


def test_indietro_da_un_lotto_miscela_con_quantita_indicata():
    result = trace(base_graph(), "M", "backward", amount=D("3000"))
    assert {k: q(v) for k, v in result.certain.items()} == {"A": D("2500.000"), "B": D("500.000")}
    full = trace(base_graph(), "M", "backward")
    assert {k: q(v) for k, v in full.certain.items()} == {"A": D("10000.000"), "B": D("2000.000")}


def test_archi_con_quantita_attribuite_per_la_vista_grafica():
    result = trace(base_graph(), "dest:D1", "backward")
    flows = {(e.source, e.target, e.kind): q(e.quantity) for e in result.edges}
    assert flows == {
        ("M", "dest:D1", "CERTO"): D("6000.000"),
        ("A", "M", "CERTO"): D("5000.000"),
        ("B", "M", "CERTO"): D("1000.000"),
    }
    depths = {(e.source, e.target): e.depth for e in result.edges}
    assert depths[("M", "dest:D1")] == 1 and depths[("A", "M")] == 2


# --- in avanti -----------------------------------------------------------------------
def test_avanti_da_un_lotto_mp_raggiunge_le_destinazioni_per_quota():
    result = trace(base_graph(), "A", "forward")
    assert {k: q(v) for k, v in result.certain.items()} == {
        "dest:D1": D("5000.000"), "dest:D2": D("5000.000")}
    small = trace(base_graph(), "B", "forward")
    assert {k: q(v) for k, v in small.certain.items()} == {
        "dest:D1": D("1000.000"), "dest:D2": D("1000.000")}


def test_avanti_da_una_miscela():
    result = trace(base_graph(), "M", "forward")
    assert {k: q(v) for k, v in result.certain.items()} == {
        "dest:D1": D("6000.000"), "dest:D2": D("6000.000")}


# --- legami POSSIBILI -------------------------------------------------------------------
def test_un_legame_possibile_rende_possibile_tutto_il_percorso():
    graph = Graph.build(
        edges=[
            Edge("A", "M", D("1000"), "CERTO"),
            Edge("C", "M", D("500"), "POSSIBILE"),
            Edge("M", "dest:D", D("1000"), "CERTO"),
        ],
        produced={"M": D("1000"), "dest:D": D("1000"), "A": D("1000"), "C": D("500")},
    )
    back = trace(graph, "dest:D", "backward")
    assert {k: q(v) for k, v in back.certain.items()} == {"A": D("1000.000")}
    assert {k: q(v) for k, v in back.possible.items()} == {"C": D("500.000")}
    forward = trace(graph, "C", "forward")
    assert forward.certain == {}
    assert {k: q(v) for k, v in forward.possible.items()} == {"dest:D": D("500.000")}


# --- miscela usata come ingrediente di un'altra miscela -----------------------------------
def test_catena_a_piu_livelli_premiscela():
    graph = Graph.build(
        edges=[
            Edge("X", "P", D("1000"), "CERTO"),
            Edge("P", "M", D("300"), "CERTO"),
            Edge("A", "M", D("700"), "CERTO"),
            Edge("M", "dest:D", D("1000"), "CERTO"),
        ],
        produced={"P": D("1000"), "M": D("1000"), "dest:D": D("1000"),
                  "X": D("1000"), "A": D("700")},
    )
    back = trace(graph, "dest:D", "backward")
    assert {k: q(v) for k, v in back.certain.items()} == {"X": D("300.000"), "A": D("700.000")}
    fwd = trace(graph, "X", "forward")
    assert {k: q(v) for k, v in fwd.certain.items()} == {"dest:D": D("300.000")}


def test_percorsi_multipli_sullo_stesso_lotto_si_sommano():
    graph = Graph.build(
        edges=[
            Edge("A", "M1", D("500"), "CERTO"), Edge("A", "M2", D("500"), "CERTO"),
            Edge("M1", "dest:D", D("400"), "CERTO"), Edge("M2", "dest:D", D("600"), "CERTO"),
        ],
        produced={"M1": D("1000"), "M2": D("1000"), "dest:D": D("1000"), "A": D("1000")},
    )
    back = trace(graph, "dest:D", "backward")
    # M1: 400 × 500/1000 = 200 ; M2: 600 × 500/1000 = 300
    assert {k: q(v) for k, v in back.certain.items()} == {"A": D("500.000")}


# --- limiti e casi anomali -------------------------------------------------------------------
def test_profondita_massima_segnalata():
    edges = [Edge(f"L{i}", f"L{i + 1}", D("100"), "CERTO") for i in range(6)]
    graph = Graph.build(edges, produced={f"L{i}": D("100") for i in range(7)})
    result = trace(graph, "L6", "backward", max_depth=3)
    assert result.truncated is True
    assert set(result.certain) == {"L3"}  # si ferma a profondità 3
    full = trace(graph, "L6", "backward", max_depth=10)
    assert full.truncated is False and set(full.certain) == {"L0"}


def test_cicli_non_mandano_in_loop():
    graph = Graph.build(
        edges=[Edge("A", "B", D("10"), "CERTO"), Edge("B", "A", D("10"), "CERTO")],
        produced={"A": D("10"), "B": D("10")},
    )
    result = trace(graph, "A", "backward")
    assert any("ciclo" in w.lower() for w in result.warnings)


def test_quantita_prodotta_sconosciuta_segnalata_e_trattata_come_foglia():
    graph = Graph.build(
        edges=[Edge("A", "M", D("100"), "CERTO"), Edge("M", "dest:D", D("100"), "CERTO")],
        produced={"dest:D": D("100"), "A": D("100")},  # M senza quantità prodotta
    )
    result = trace(graph, "dest:D", "backward")
    assert any("M" in w for w in result.warnings)
    assert {k: q(v) for k, v in result.certain.items()} == {"M": D("100.000")}


def test_nodo_senza_archi_e_foglia_di_se_stesso():
    graph = Graph.build(edges=[], produced={"A": D("100")})
    result = trace(graph, "A", "backward", amount=D("50"))
    assert {k: q(v) for k, v in result.certain.items()} == {"A": D("50.000")}
    assert result.edges == []
