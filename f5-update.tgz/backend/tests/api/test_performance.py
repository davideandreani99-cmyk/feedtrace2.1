"""Benchmark RF-07: tracciabilità < 2 s su ~200.000 movimenti (≈ 3 anni di un sito medio).

Non gira nella suite normale: RUN_PERF=1 pytest tests/api/test_performance.py -s
"""

import os
import time
import uuid

import pytest
from sqlalchemy import text

from app import provisioning
from app.db import admin_engine
from tests.api.conftest import API, PASSWORD

pytestmark = pytest.mark.skipif(os.environ.get("RUN_PERF") != "1", reason="benchmark: RUN_PERF=1")

N_CONTAINERS, N_MP, N_MIX, N_DEST, N_MOVEMENTS = 40, 400, 1500, 1500, 200_000
LIMIT_SECONDS = 2.0


def seed(tenant_id: uuid.UUID):
    site_id = uuid.uuid4()
    containers = [uuid.uuid4() for _ in range(N_CONTAINERS)]
    mp = [uuid.uuid4() for _ in range(N_MP)]
    mix = [uuid.uuid4() for _ in range(N_MIX)]
    dest = [uuid.uuid4() for _ in range(N_DEST)]
    t = {"t": tenant_id, "s": site_id}
    with admin_engine.begin() as c:
        c.execute(text("insert into site (id, tenant_id, name, asl_code) values (:s, :t, 'Sito benchmark', 'PERF001')"), t)
        c.execute(text("insert into container (id, tenant_id, site_id, code, type) "
                       "select u, :t, :s, 'PC-' || row_number() over (), 'SILO' from unnest(CAST(:ids AS uuid[])) as x(u)"),
                  {**t, "ids": containers})
        c.execute(text("insert into lot (id, tenant_id, kind, site_id, internal_code, entry_date, initial_qty, status) "
                       "select u, :t, 'MATERIA_PRIMA', :s, 'PERF-MP-' || row_number() over (), current_date, 10000, 'DISPONIBILE' "
                       "from unnest(CAST(:ids AS uuid[])) as x(u)"), {**t, "ids": mp})
        c.execute(text("insert into lot (id, tenant_id, kind, site_id, internal_code, entry_date, initial_qty, status) "
                       "select u, :t, 'MISCELA', :s, 'PERF-MX-' || row_number() over (), current_date, 10000, 'DISPONIBILE' "
                       "from unnest(CAST(:ids AS uuid[])) as x(u)"), {**t, "ids": mix})
        c.execute(text("insert into destination_lot (id, tenant_id, site_id, internal_code, external_code) "
                       "select u, :t, :s, 'PERF-D-' || row_number() over (), 'PIG-' || row_number() over () "
                       "from unnest(CAST(:ids AS uuid[])) as x(u)"), {**t, "ids": dest})
        # ogni miscela da 6 lotti MP; ogni lotto di destinazione da 25 miscele
        c.execute(text("insert into trace_link (id, tenant_id, from_lot_id, to_lot_id, quantity, kind, operation_id, occurred_at) "
                       "select gen_random_uuid(), :t, (CAST(:mp AS uuid[]))[1 + floor(random() * :nmp)::int], m.u, 1000, 'CERTO', "
                       "gen_random_uuid(), now() from unnest(CAST(:mix AS uuid[])) as m(u), generate_series(1, 6)"),
                  {**t, "mp": mp, "mix": mix, "nmp": N_MP})
        c.execute(text("insert into trace_link (id, tenant_id, from_lot_id, to_destination_lot_id, quantity, kind, operation_id, occurred_at) "
                       "select gen_random_uuid(), :t, (CAST(:mix AS uuid[]))[1 + floor(random() * :nmix)::int], d.u, 400, 'CERTO', "
                       "gen_random_uuid(), now() from unnest(CAST(:dest AS uuid[])) as d(u), generate_series(1, 25)"),
                  {**t, "mix": mix, "dest": dest, "nmix": N_MIX})
        c.execute(text("insert into movement (id, tenant_id, site_id, occurred_at, type, container_id, lot_id, quantity, operation_id) "
                       "select gen_random_uuid(), :t, :s, now() - random() * interval '1000 days', 'CARICO_INGRESSO', "
                       "(CAST(:cont AS uuid[]))[1 + floor(random() * :nc)::int], "
                       "(CAST(:lots AS uuid[]))[1 + floor(random() * :nl)::int], "
                       "(random() * 1000 + 1)::numeric(18,3), gen_random_uuid() from generate_series(1, :n)"),
                  {**t, "cont": containers, "nc": N_CONTAINERS, "lots": mp + mix, "nl": N_MP + N_MIX, "n": N_MOVEMENTS})
        c.execute(text("analyze movement"))
        c.execute(text("analyze trace_link"))
    return {"site": site_id, "container": containers[0], "mp": mp[0], "mix": mix[0], "dest": dest[0]}


def timed(client, headers, path, params=None, runs=3):
    best = None
    for _ in range(runs):
        start = time.perf_counter()
        r = client.get(f"{API}{path}", params=params, headers=headers)
        elapsed = time.perf_counter() - start
        assert r.status_code == 200, r.text
        best = elapsed if best is None else min(best, elapsed)
    return best, r.json()


def test_tracciabilita_sotto_i_2_secondi_su_200k_movimenti(client):
    tenant_id = provisioning.create_tenant(f"Benchmark {uuid.uuid4().hex[:6]}")
    ids = seed(tenant_id)
    email = f"perf{uuid.uuid4().hex[:8]}@example.test"
    user_id = provisioning.create_user(email, PASSWORD, "Utente benchmark")
    provisioning.add_membership(user_id, tenant_id, "ADMIN")
    token = client.post(f"{API}/auth/login", json={"email": email, "password": PASSWORD}).json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    with admin_engine.connect() as c:
        movements = c.execute(text("select count(*) from movement where tenant_id = :t"), {"t": tenant_id}).scalar()
        links = c.execute(text("select count(*) from trace_link where tenant_id = :t"), {"t": tenant_id}).scalar()
    print(f"\nDataset: {movements} movimenti, {links} legami")

    results = {}
    results["indietro da lotto di destinazione"], back = timed(
        client, headers, "/traceability/backward", {"destination_lot_id": str(ids["dest"])})
    results["indietro da lotto miscela"], _ = timed(
        client, headers, "/traceability/backward", {"lot_id": str(ids["mix"])})
    results["avanti da lotto MP"], forward = timed(
        client, headers, "/traceability/forward", {"lot_id": str(ids["mp"])})
    results["richiamo da lotto MP"], recall = timed(client, headers, f"/traceability/recall/{ids['mp']}")
    results["composizione contenitore (indietro)"], _ = timed(
        client, headers, "/traceability/backward", {"container_id": str(ids["container"])})
    results["giacenza contenitore a una data"], _ = timed(client, headers, f"/containers/{ids['container']}/stock")
    results["elenco contenitori con giacenze"], _ = timed(client, headers, "/stock/containers")
    results["cruscotto"], _ = timed(client, headers, "/dashboard")

    print(f"Nodi (indietro dest): {len(back['nodes'])}, (avanti MP): {len(forward['nodes'])}, "
          f"destinazioni richiamate: {len(recall['destinations'])}")
    for name, seconds in results.items():
        print(f"  {seconds * 1000:8.0f} ms  {name}")
    slow = {k: v for k, v in results.items() if v > LIMIT_SECONDS and k.startswith(("indietro", "avanti", "richiamo", "composizione"))}
    assert not slow, f"Tracciabilità oltre {LIMIT_SECONDS} s: {slow}"
