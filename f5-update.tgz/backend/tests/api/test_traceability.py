"""Fase 5 (RF-07, RF-12): tracciabilità avanti/indietro, richiamo, report PDF/XLSX, cruscotto.

Scenario ("chain"): lotti MP A (10 t, fornitore 1) e B (5 t, fornitore 2) di mais, C (4 t) di soia;
una produzione di 10 t (mais 7000 da A, soia 3000 da C) → lotto miscela M1; M1 scaricato:
6000 kg su LD-1, 3000 kg su LD-2, 1000 kg restano nel silo di prodotto finito.
"""

import io
import uuid
from datetime import datetime, timedelta
from decimal import Decimal as D
from zoneinfo import ZoneInfo

import pytest
from openpyxl import load_workbook
from sqlalchemy.orm import Session

from app.db import admin_engine
from app.models import Plant
from tests.api.conftest import API, create_material, create_site
from tests.api.test_discharges import create_dest, discharge
from tests.api.test_op_import import DISCHARGE_MAPPING, csv_bytes, day, upload
from tests.api.test_production import create_plant, create_recipe, produce
from tests.api.test_stock import (
    create_container,
    create_supplier,
    get_stock,
    post_op,
    post_receipt,
)

ROME = ZoneInfo("Europe/Rome")


def today():
    return datetime.now(ROME).date()


@pytest.fixture
def chain(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    client.patch(f"{API}/sites/{site['id']}", headers=acc.headers, json={
        "contact_name": "Mario Rossi", "contact_phone": "0521000000",
        "contact_email": "allevamento@example.test"})
    s1, s2 = create_supplier(client, acc), create_supplier(client, acc)
    mais, soia = create_material(client, acc, code="MAIS"), create_material(client, acc, code="SOIA")
    silo_m = create_container(client, acc, site, code="SILO-M")
    silo_s = create_container(client, acc, site, code="SILO-S")
    pf = create_container(client, acc, site, code="SILO-PF")
    lot_a = post_receipt(client, acc, site, silo_m, mais, "10", s1, unit="t", supplier_lot="LF-A").json()["lots"][0]
    lot_b = post_receipt(client, acc, site, silo_m, mais, "5", s2, unit="t", supplier_lot="LF-B").json()["lots"][0]
    lot_c = post_receipt(client, acc, site, silo_s, soia, "4", s2, unit="t", supplier_lot="LF-C").json()["lots"][0]
    plant = create_plant(client, acc, site, code="MIX1")
    recipe = create_recipe(client, acc, "R1", [(mais, 700, silo_m), (soia, 300, silo_s)])
    production = produce(client, acc, plant, recipe, 10, destination_container_id=pf["id"]).json()
    d1, d2 = create_dest(client, acc, site, "LD-1", "PIG-1"), create_dest(client, acc, site, "LD-2", "PIG-2")
    assert discharge(client, acc, pf, d1, "6000").status_code == 201
    assert discharge(client, acc, pf, d2, "3000").status_code == 201
    return {"acc": acc, "site": site, "s1": s1, "s2": s2, "mais": mais, "soia": soia, "silo_m": silo_m,
            "silo_s": silo_s, "pf": pf, "a": lot_a, "b": lot_b, "c": lot_c, "plant": plant,
            "recipe": recipe, "production": production, "d1": d1, "d2": d2}


def get_trace(client, acc, kind, **params):
    r = client.get(f"{API}/traceability/{kind}", params=params, headers=acc.headers)
    return r


def by_label(trace):
    labels = {n["id"]: n["label"] for n in trace["nodes"]}
    return {labels[r["node_id"]]: (D(r["certain_kg"]), D(r["possible_kg"])) for r in trace["results"]}


# --- all'indietro --------------------------------------------------------------------------
def test_indietro_da_un_lotto_di_destinazione(client, chain):
    c = chain
    r = get_trace(client, c["acc"], "backward", destination_lot_id=c["d1"]["id"])
    assert r.status_code == 200, r.text
    trace = r.json()
    assert trace["direction"] == "backward" and trace["start_label"] == "LD-1"
    assert D(trace["amount"]) == D("6000")
    assert by_label(trace) == {c["a"]["internal_code"]: (D("4200"), D("0")),
                               c["c"]["internal_code"]: (D("1800"), D("0"))}
    nodes = {n["label"]: n for n in trace["nodes"]}
    node_a = nodes[c["a"]["internal_code"]]
    assert node_a["supplier_name"] == c["s1"]["name"] and node_a["supplier_lot"] == "LF-A"
    assert node_a["ddt_number"] == "DDT-1" and node_a["kind"] == "MATERIA_PRIMA"
    assert node_a["material_code"] == "MAIS" and node_a["status"] == "DISPONIBILE"
    mix = nodes[c["production"]["mix_lot_code"]]
    assert mix["kind"] == "MISCELA" and mix["recipe_code"] == "R1"
    assert nodes["LD-1"]["external_code"] == "PIG-1" and nodes["LD-1"]["node_type"] == "DESTINATION"
    edges = {(e["source"], e["target"]): (D(e["quantity"]), e["kind"], e["depth"]) for e in trace["edges"]}
    assert edges[(c["production"]["mix_lot_id"], f"dest:{c['d1']['id']}")] == (D("6000"), "CERTO", 1)
    assert edges[(c["a"]["id"], c["production"]["mix_lot_id"])] == (D("4200"), "CERTO", 2)
    assert trace["truncated"] is False and trace["warnings"] == []


def test_indietro_da_un_lotto_miscela_e_con_quantita(client, chain):
    c, mix = chain, chain["production"]["mix_lot_id"]
    full = get_trace(client, c["acc"], "backward", lot_id=mix).json()
    assert by_label(full) == {c["a"]["internal_code"]: (D("7000"), D("0")),
                              c["c"]["internal_code"]: (D("3000"), D("0"))}
    part = get_trace(client, c["acc"], "backward", lot_id=mix, quantity="5000").json()
    assert by_label(part) == {c["a"]["internal_code"]: (D("3500"), D("0")),
                              c["c"]["internal_code"]: (D("1500"), D("0"))}


def test_indietro_da_un_contenitore_a_una_data(client, chain):
    c = chain
    now = get_trace(client, c["acc"], "backward", container_id=c["pf"]["id"]).json()
    assert by_label(now) == {c["a"]["internal_code"]: (D("700"), D("0")),
                             c["c"]["internal_code"]: (D("300"), D("0"))}
    before = (datetime.now(ROME) - timedelta(days=1)).isoformat()
    r = get_trace(client, c["acc"], "backward", container_id=c["pf"]["id"], at=before)
    assert r.status_code == 404 and "vuoto" in r.json()["detail"]


def test_indietro_da_un_lotto_mp_e_il_lotto_stesso(client, chain):
    c = chain
    trace = get_trace(client, c["acc"], "backward", lot_id=c["b"]["id"]).json()
    assert by_label(trace) == {c["b"]["internal_code"]: (D("5000"), D("0"))}
    assert trace["edges"] == []


# --- in avanti --------------------------------------------------------------------------------
def test_avanti_da_un_lotto_mp_raggiunge_le_destinazioni(client, chain):
    c = chain
    trace = get_trace(client, c["acc"], "forward", lot_id=c["a"]["id"]).json()
    assert by_label(trace) == {"LD-1": (D("4200"), D("0")), "LD-2": (D("2100"), D("0"))}
    nodes = {n["label"]: n for n in trace["nodes"]}
    mix = nodes[c["production"]["mix_lot_code"]]
    assert [(x["container_code"], D(x["quantity"])) for x in mix["containers"]] == [("SILO-PF", D("1000"))]
    own = nodes[c["a"]["internal_code"]]
    assert [(x["container_code"], D(x["quantity"])) for x in own["containers"]] == [("SILO-M", D("3000"))]
    assert nodes["LD-2"]["external_code"] == "PIG-2" and nodes["LD-2"]["site_name"] == c["site"]["name"]


def test_avanti_da_un_lotto_non_usato_non_raggiunge_nessuno(client, chain):
    trace = get_trace(client, chain["acc"], "forward", lot_id=chain["b"]["id"]).json()
    assert trace["results"] == [] and trace["edges"] == []


def test_avanti_per_fornitore_e_periodo(client, chain):
    c = chain
    t = today().isoformat()
    trace = get_trace(client, c["acc"], "forward", supplier_id=c["s2"]["id"], date_from=t, date_to=t).json()
    assert by_label(trace) == {"LD-1": (D("1800"), D("0")), "LD-2": (D("900"), D("0"))}
    only_a = get_trace(client, c["acc"], "forward", supplier_id=c["s1"]["id"], date_from=t, date_to=t).json()
    assert by_label(only_a) == {"LD-1": (D("4200"), D("0")), "LD-2": (D("2100"), D("0"))}
    y = (today() - timedelta(days=2)).isoformat()
    assert get_trace(client, c["acc"], "forward", supplier_id=c["s1"]["id"], date_from=y, date_to=y).status_code == 404


# --- miscela usata come ingrediente (più livelli) ----------------------------------------------------------
def test_catena_con_premiscela_a_due_livelli(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    mais, soia = create_material(client, acc, code="MAIS"), create_material(client, acc, code="SOIA")
    premix = create_material(client, acc, code="PREMIX", type="PREMISCELA")
    silo_m, silo_s = create_container(client, acc, site, code="S-M"), create_container(client, acc, site, code="S-S")
    silo_pre, pf = create_container(client, acc, site, code="S-PRE"), create_container(client, acc, site, code="S-PF")
    lot_a = post_receipt(client, acc, site, silo_m, mais, "10", supplier, unit="t").json()["lots"][0]
    lot_c = post_receipt(client, acc, site, silo_s, soia, "4", supplier, unit="t").json()["lots"][0]
    plant = create_plant(client, acc, site, code="MIX1")
    r_pre = create_recipe(client, acc, "R-PRE", [(mais, 1000, silo_m)])
    r_fin = create_recipe(client, acc, "R-FIN", [(premix, 500, silo_pre), (soia, 500, silo_s)])
    pre = produce(client, acc, plant, r_pre, 2, destination_container_id=silo_pre["id"]).json()
    fin = produce(client, acc, plant, r_fin, 2, destination_container_id=pf["id"]).json()
    dest = create_dest(client, acc, site, "LD-1", "PIG-1")
    assert discharge(client, acc, pf, dest, "2000").status_code == 201

    back = get_trace(client, acc, "backward", destination_lot_id=dest["id"]).json()
    assert by_label(back) == {lot_a["internal_code"]: (D("1000"), D("0")),
                              lot_c["internal_code"]: (D("1000"), D("0"))}
    assert {n["label"] for n in back["nodes"] if n["kind"] == "MISCELA"} == {pre["mix_lot_code"], fin["mix_lot_code"]}
    assert max(e["depth"] for e in back["edges"]) == 3
    fwd = get_trace(client, acc, "forward", lot_id=lot_a["id"]).json()
    assert by_label(fwd) == {"LD-1": (D("1000"), D("0"))}


# --- legami POSSIBILI distinti ---------------------------------------------------------------------------------
def test_legami_certi_e_possibili_restano_distinti(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    mais = create_material(client, acc, code="MAIS")
    silo = create_container(client, acc, site, code="TP", policy="TUTTI_PRESENTI")
    lot_x = post_receipt(client, acc, site, silo, mais, "10", supplier, unit="t").json()["lots"][0]
    lot_y = post_receipt(client, acc, site, silo, mais, "5", supplier, unit="t").json()["lots"][0]
    plant = create_plant(client, acc, site)
    recipe = create_recipe(client, acc, "R1", [(mais, 1000, silo)])
    out = produce(client, acc, plant, recipe, 6).json()
    trace = get_trace(client, acc, "backward", lot_id=out["mix_lot_id"]).json()
    assert by_label(trace) == {lot_x["internal_code"]: (D("4000"), D("4000")),
                               lot_y["internal_code"]: (D("2000"), D("2000"))}
    kinds = {e["kind"] for e in trace["edges"]}
    assert kinds == {"CERTO", "POSSIBILE"}


# --- storno e tracciabilità ---------------------------------------------------------------------------------------
def test_lo_storno_di_uno_scarico_si_riflette_nella_tracciabilita(client, chain):
    c = chain
    discharges = client.get(f"{API}/discharges", params={"destination_lot_id": c["d2"]["id"]},
                            headers=c["acc"].headers).json()
    assert post_op(client, c["acc"], f"/discharges/{discharges[0]['id']}/storno", {"reason": "errore"}).status_code == 201
    trace = get_trace(client, c["acc"], "forward", lot_id=c["a"]["id"]).json()
    assert by_label(trace) == {"LD-1": (D("4200"), D("0"))}
    recall = client.get(f"{API}/traceability/recall/{c['a']['id']}", headers=c["acc"].headers).json()
    assert [d["code"] for d in recall["destinations"]] == ["LD-1"]


# --- richiamo ---------------------------------------------------------------------------------------------------------
def test_simulazione_di_richiamo(client, chain):
    c = chain
    r = client.get(f"{API}/traceability/recall/{c['a']['id']}", headers=c["acc"].headers)
    assert r.status_code == 200, r.text
    recall = r.json()
    assert recall["lot"]["label"] == c["a"]["internal_code"] and recall["lot"]["supplier_name"] == c["s1"]["name"]
    first, second = recall["destinations"]
    assert (first["code"], D(first["certain_kg"]), first["external_code"]) == ("LD-1", D("4200"), "PIG-1")
    assert (second["code"], D(second["certain_kg"])) == ("LD-2", D("2100"))
    assert first["contact_name"] == "Mario Rossi" and first["contact_phone"] == "0521000000"
    assert first["contact_email"] == "allevamento@example.test"
    assert first["first_period"] == first["last_period"] == today().isoformat()
    assert D(recall["total_certain_kg"]) == D("6300") and D(recall["total_possible_kg"]) == D("0")
    assert [(m["code"], D(m["kg"])) for m in recall["mix_lots"]] == [(c["production"]["mix_lot_code"], D("7000"))]
    remaining = {(s["lot_code"], s["container_code"]): D(s["quantity"]) for s in recall["remaining_stock"]}
    assert remaining == {(c["a"]["internal_code"], "SILO-M"): D("3000"),
                         (c["production"]["mix_lot_code"], "SILO-PF"): D("1000")}


# --- parametri, permessi, isolamento ------------------------------------------------------------------------------------
def test_parametri_non_validi_e_lotti_inesistenti(client, chain):
    acc, c = chain["acc"], chain
    assert get_trace(client, acc, "backward").status_code == 422
    assert get_trace(client, acc, "backward", lot_id=c["a"]["id"], destination_lot_id=c["d1"]["id"]).status_code == 422
    assert get_trace(client, acc, "backward", lot_id=str(uuid.uuid4())).status_code == 404
    assert get_trace(client, acc, "backward", destination_lot_id=str(uuid.uuid4())).status_code == 404
    assert get_trace(client, acc, "forward").status_code == 422
    assert get_trace(client, acc, "forward", lot_id=c["a"]["id"], supplier_id=c["s1"]["id"]).status_code == 422
    assert client.get(f"{API}/traceability/recall/{uuid.uuid4()}", headers=acc.headers).status_code == 404


def test_permessi_e_isolamento_tra_aziende(client, chain, make_account):
    c = chain
    assert client.get(f"{API}/traceability/forward", params={"lot_id": c["a"]["id"]}).status_code == 401
    auditor = make_account("AUDITOR", c["acc"].tenant_id)
    assert get_trace(client, auditor, "forward", lot_id=c["a"]["id"]).status_code == 200
    intruder = make_account("ADMIN")
    assert get_trace(client, intruder, "forward", lot_id=c["a"]["id"]).status_code == 404
    assert get_trace(client, intruder, "backward", destination_lot_id=c["d1"]["id"]).status_code == 404
    assert get_trace(client, intruder, "forward", supplier_id=c["s1"]["id"]).status_code == 404
    assert client.get(f"{API}/traceability/recall/{c['a']['id']}", headers=intruder.headers).status_code == 404


# --- report PDF / XLSX --------------------------------------------------------------------------------------------------------
def sheet_values(content: bytes):
    ws = load_workbook(io.BytesIO(content)).active
    return [[cell for cell in row] for row in ws.iter_rows(values_only=True)]


def flat(content: bytes):
    return [v for row in sheet_values(content) for v in row if v is not None]


def test_scheda_di_tracciabilita_pdf_e_xlsx(client, chain):
    c = chain
    params = {"direction": "backward", "destination_lot_id": c["d1"]["id"]}
    pdf = client.get(f"{API}/reports/traceability", params=params, headers=c["acc"].headers)
    assert pdf.status_code == 200 and pdf.headers["content-type"] == "application/pdf"
    assert pdf.content.startswith(b"%PDF-") and "attachment" in pdf.headers["content-disposition"]
    assert c["a"]["internal_code"].encode() in pdf.content and b"Azienda" in pdf.content
    assert b"Scheda" in pdf.content and b"tracciabilit" in pdf.content

    xlsx = client.get(f"{API}/reports/traceability", params={**params, "format": "xlsx"}, headers=c["acc"].headers)
    assert xlsx.status_code == 200 and xlsx.headers["content-disposition"].endswith('.xlsx"')
    values = flat(xlsx.content)
    assert c["a"]["internal_code"] in values and c["s1"]["name"] in values
    assert 4200.0 in values and 1800.0 in values  # kg attribuiti come numeri
    assert "Azienda" in values and any("Mario" in str(v) or c["acc"].email in str(v) for v in values)

    fwd = client.get(f"{API}/reports/traceability", headers=c["acc"].headers,
                     params={"direction": "forward", "lot_id": c["a"]["id"], "format": "xlsx"})
    assert "PIG-1" in flat(fwd.content) and 2100.0 in flat(fwd.content)


def test_report_di_richiamo(client, chain):
    c = chain
    pdf = client.get(f"{API}/reports/recall/{c['a']['id']}", headers=c["acc"].headers)
    assert pdf.status_code == 200 and pdf.content.startswith(b"%PDF-")
    assert b"PIG-1" in pdf.content and b"Mario" in pdf.content and b"richiamo" in pdf.content
    xlsx = client.get(f"{API}/reports/recall/{c['a']['id']}", params={"format": "xlsx"}, headers=c["acc"].headers)
    values = flat(xlsx.content)
    assert "LD-1" in values and "allevamento@example.test" in values and 4200.0 in values


def summary_rows(content: bytes):
    rows = sheet_values(content)
    start = next(i for i, r in enumerate(rows) if r and r[0] == "Riepilogo per articolo (kg)")
    out = {}
    for r in rows[start + 2:]:
        if not r or r[0] is None:
            break
        out[r[0]] = tuple(r[1:5])
    return out


def test_registro_di_carico_e_scarico(client, chain):
    c = chain
    params = {"site_id": c["site"]["id"], "date_from": today().isoformat(), "date_to": today().isoformat()}
    xlsx = client.get(f"{API}/reports/ledger", params={**params, "format": "xlsx"}, headers=c["acc"].headers)
    assert xlsx.status_code == 200, xlsx.text
    rows = summary_rows(xlsx.content)
    assert rows["MAIS"] == (0.0, 15000.0, -7000.0, 8000.0)
    assert rows["SOIA"] == (0.0, 4000.0, -3000.0, 1000.0)
    assert rows["Miscela R1"] == (0.0, 10000.0, -9000.0, 1000.0)
    values = flat(xlsx.content)
    assert c["a"]["internal_code"] in values and "CARICO_INGRESSO" in values
    assert any("DDT DDT-1" == v for v in values)
    pdf = client.get(f"{API}/reports/ledger", params=params, headers=c["acc"].headers)
    assert pdf.content.startswith(b"%PDF-") and b"Registro" in pdf.content

    # periodo successivo: giacenza iniziale = finale precedente, nessun movimento
    later = {**params, "date_from": (today() + timedelta(days=1)).isoformat(),
             "date_to": (today() + timedelta(days=2)).isoformat(), "format": "xlsx"}
    rows_later = summary_rows(client.get(f"{API}/reports/ledger", params=later, headers=c["acc"].headers).content)
    assert rows_later["MAIS"] == (8000.0, 0.0, 0.0, 8000.0)


def test_registro_parametri_permessi_e_isolamento(client, chain, make_account):
    c = chain
    base = {"site_id": c["site"]["id"], "date_from": today().isoformat(), "date_to": today().isoformat()}
    inverted = {**base, "date_from": (today() + timedelta(days=3)).isoformat()}
    assert client.get(f"{API}/reports/ledger", params=inverted, headers=c["acc"].headers).status_code == 422
    auditor = make_account("AUDITOR", c["acc"].tenant_id)
    assert client.get(f"{API}/reports/ledger", params=base, headers=auditor.headers).status_code == 200
    intruder = make_account("ADMIN")
    assert client.get(f"{API}/reports/ledger", params=base, headers=intruder.headers).status_code == 404
    assert client.get(f"{API}/reports/ledger", params=base).status_code == 401


# --- cruscotto ----------------------------------------------------------------------------------------------------------------------
def test_cruscotto(client, chain):
    c, acc = chain, chain["acc"]
    soia_q = create_material(client, acc, code="SOIAQ", requires_analysis=True)
    silo_q = create_container(client, acc, c["site"], code="SILO-Q")
    post_receipt(client, acc, c["site"], silo_q, soia_q, "2", c["s1"], unit="t")
    empty = create_container(client, acc, c["site"], code="SILO-VUOTO")
    post_op(client, acc, "/outflows", {"container_id": empty["id"], "quantity": "50", "reason": "Scarto di prova"})
    plant2 = create_plant(client, acc, c["site"], code="MIX2", tolerance_pct="2")
    produce(client, acc, plant2, c["recipe"], 1, destination_container_id=c["pf"]["id"],
            lines=[{"material_id": c["mais"]["id"], "actual_quantity": "800"}])
    with Session(admin_engine) as db:
        db.get(Plant, uuid.UUID(c["plant"]["id"])).medicated_contaminated = True
        db.commit()
    mapping = {**DISCHARGE_MAPPING, "columns": {"date": "Data", "container": "Silo", "location": "Valvola", "quantity": "Kg"}}
    upload(client, acc, "discharges", csv_bytes("Data;Silo;Valvola;Kg", f"{day()};SILO-PF;V99;5"), mapping)

    r = client.get(f"{API}/dashboard", headers=acc.headers)
    assert r.status_code == 200, r.text
    board = r.json()
    assert D(board["total_stock_kg"]) == sum(D(x["total"]) for x in board["containers"])
    blocked = {b["lot_code"]: b for b in board["blocked_lots"]}
    assert len(blocked) == 1 and next(iter(blocked.values()))["status"] == "IN_QUARANTENA"
    assert D(next(iter(blocked.values()))["stock_kg"]) == D("2000") and board["blocked_lots"][0]["containers"] == ["SILO-Q"]
    assert any(a["container_code"] == "SILO-VUOTO" for a in board["negative_stock"])
    assert [d["recipe_code"] for d in board["deviations"]] == ["R1"] and "MAIS" in board["deviations"][0]["message"]
    assert {"type": "IMPIANTO", "code": "MIX1"} in board["contaminated"]
    assert [i["status"] for i in board["import_issues"]] == ["PREVIEW"] and board["import_issues"][0]["error_count"] == 1
    assert board["recent"]["productions_7d"] == 2 and board["recent"]["receipts_7d"] >= 4
    assert board["recent"]["discharges_7d"] == 2 and board["expiring_prescriptions"] == []
    assert get_stock(client, acc, c["pf"])["total"]


def test_cruscotto_permessi_e_isolamento(client, chain, make_account):
    c = chain
    assert client.get(f"{API}/dashboard").status_code == 401
    intruder = make_account("ADMIN")
    board = client.get(f"{API}/dashboard", headers=intruder.headers).json()
    assert board["containers"] == [] and board["blocked_lots"] == [] and D(board["total_stock_kg"]) == 0
    veterinario = make_account("VETERINARIO", c["acc"].tenant_id)
    assert client.get(f"{API}/dashboard", headers=veterinario.headers).status_code == 200


def test_contatti_del_sito_nell_anagrafica(client, chain):
    site = client.get(f"{API}/sites/{chain['site']['id']}", headers=chain["acc"].headers).json()
    assert site["contact_name"] == "Mario Rossi" and site["contact_phone"] == "0521000000"
