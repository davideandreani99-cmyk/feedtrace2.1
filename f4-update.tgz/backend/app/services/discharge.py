"""Scarichi verso lotti di destinazione (RF-05, SPEC §6.5)."""

import uuid
from collections import defaultdict
from datetime import UTC, datetime
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import func, select

from app import audit
from app.deps import Ctx
from app.models import (
    Container,
    DestinationLot,
    Discharge,
    Location,
    Lot,
    Movement,
    Occupancy,
    RawMaterial,
    Recipe,
    TraceLink,
)
from app.schemas_discharge import (
    DestinationSummaryOut,
    DischargeAllocationOut,
    DischargeIn,
    DischargeOut,
    SummaryLotOut,
    SummaryMonthOut,
    SummaryRecipeOut,
)
from app.schemas_stock import StornoIn, WarningOut
from app.services import operations, stock
from domain.discharge import ensure_not_future, validate_period
from domain.enums import LotKind, MovementType
from domain.occupancy import resolve_occupancy


def _bad(message: str) -> HTTPException:
    return HTTPException(status_code=422, detail=message)


def _kg(quantity: Decimal, unit: str) -> Decimal:
    return (quantity * 1000 if unit == "t" else quantity).quantize(Decimal("0.001"))


def _resolve_destination(ctx: Ctx, p: DischargeIn, period_from, period_to):
    db = ctx.db
    if p.destination_lot_id is not None:
        lot = db.scalar(
            select(DestinationLot).where(
                DestinationLot.id == p.destination_lot_id,
                DestinationLot.tenant_id == ctx.tenant_id,
            )
        )
        if lot is None:
            raise _bad("Lotto di destinazione non trovato")
        return lot, None
    location = db.scalar(
        select(Location).where(Location.id == p.location_id, Location.tenant_id == ctx.tenant_id)
    )
    if location is None:
        raise _bad("Luogo non trovato")
    occupancies = [
        (o.destination_lot_id, o.date_from, o.date_to)
        for o in db.scalars(
            select(Occupancy).where(
                Occupancy.location_id == location.id, Occupancy.tenant_id == ctx.tenant_id
            )
        )
    ]
    lot_id, error = resolve_occupancy(period_from, period_to, occupancies)
    if error:
        raise _bad(f"{location.name}: {error}")
    lot = db.scalar(
        select(DestinationLot).where(
            DestinationLot.id == lot_id, DestinationLot.tenant_id == ctx.tenant_id
        )
    )
    return lot, location.id


def discharge_out(ctx: Ctx, d: Discharge) -> DischargeOut:
    container = ctx.db.get(Container, d.container_id)
    dest = ctx.db.get(DestinationLot, d.destination_lot_id)
    return DischargeOut(
        id=d.id,
        container_id=d.container_id,
        container_code=container.code,
        destination_lot_id=d.destination_lot_id,
        destination_code=dest.internal_code,
        external_code=dest.external_code,
        location_id=d.location_id,
        period_from=d.period_from,
        period_to=d.period_to,
        quantity=d.quantity,
        status=d.status,
        source=d.source,
        allocations=[DischargeAllocationOut(**a) for a in d.allocations],
        warnings=[WarningOut(**w) for w in d.warnings],
        notes=d.notes,
        reversal_reason=d.reversal_reason,
    )


def create_discharge(
    ctx: Ctx,
    p: DischargeIn,
    operation_id: uuid.UUID,
    *,
    source: str = "MANUALE",
    import_row_id: uuid.UUID | None = None,
    production_id: uuid.UUID | None = None,
) -> DischargeOut:
    db = ctx.db
    try:
        period_from, period_to = validate_period(p.period_from, p.period_to)
        ensure_not_future(period_to, datetime.now(UTC))
    except ValueError as exc:
        raise _bad(str(exc)) from exc

    container = stock.lock_containers(ctx, [p.container_id])[p.container_id]
    dest, location_id = _resolve_destination(ctx, p, period_from, period_to)
    if not dest.active:
        raise _bad("Lotto di destinazione disattivato")
    if dest.status == "CHIUSO":
        raise HTTPException(
            status_code=409,
            detail=f"Il lotto di destinazione {dest.internal_code} è chiuso: riaprilo con "
            "una motivazione per registrare nuovi scarichi",
        )
    if dest.site_id != container.site_id:
        raise _bad("Il contenitore e il lotto di destinazione appartengono a siti diversi")

    kg = _kg(p.quantity, p.unit)
    now = datetime.now(UTC)  # il movimento è datato alla registrazione (ADR D27)
    discharge = Discharge(
        id=uuid.uuid4(),
        tenant_id=ctx.tenant_id,
        site_id=container.site_id,
        container_id=container.id,
        destination_lot_id=dest.id,
        location_id=location_id,
        period_from=period_from,
        period_to=period_to,
        quantity=kg,
        source=source,
        operation_id=operation_id,
        user_id=ctx.user.id,
        notes=p.notes,
        import_row_id=import_row_id,
        production_id=production_id,
        warnings=[],
        allocations=[],
    )
    db.add(discharge)
    db.flush()

    outcome = stock.consume_from_container(
        ctx, container, kg, MovementType.SCARICO_DESTINAZIONE, now, operation_id,
        doc_type="discharge", doc_id=discharge.id, reason=p.notes,
    )
    certain = [(m.lot_id, -m.quantity) for m in outcome.movements]
    possible = [(a.lot_id, a.quantity) for a in outcome.possible_links]
    for lot_id, quantity in certain:
        db.add(TraceLink(
            tenant_id=ctx.tenant_id, from_lot_id=lot_id, to_destination_lot_id=dest.id,
            quantity=quantity, kind="CERTO", discharge_id=discharge.id,
            operation_id=operation_id, occurred_at=now))
    for lot_id, quantity in possible:
        db.add(TraceLink(
            tenant_id=ctx.tenant_id, from_lot_id=lot_id, to_destination_lot_id=dest.id,
            quantity=quantity, kind="POSSIBILE", discharge_id=discharge.id,
            operation_id=operation_id, occurred_at=now))

    codes = {
        lot.id: lot.internal_code
        for lot in db.scalars(
            select(Lot).where(Lot.id.in_([lot_id for lot_id, _ in certain + possible] or [uuid.uuid4()]))
        )
    }
    discharge.allocations = [
        {"lot_id": str(lot_id), "lot_code": codes[lot_id], "quantity": str(quantity), "kind": kind}
        for kind, rows in (("CERTO", certain), ("POSSIBILE", possible))
        for lot_id, quantity in rows
    ]
    warnings: list[WarningOut] = []
    negative = stock.negative_warning(container, outcome.total_before - kg, outcome.shortfall)
    if negative:
        warnings.append(WarningOut(**negative))
    if (dest.start_date and period_from < dest.start_date) or (
        dest.end_date and period_to > dest.end_date
    ):
        warnings.append(
            WarningOut(
                code="PERIOD_OUTSIDE_LOT",
                message=f"Il periodo dello scarico esce dalle date del lotto {dest.internal_code}",
            )
        )
    discharge.warnings = [w.model_dump() for w in warnings]
    db.flush()
    out = discharge_out(ctx, discharge)
    audit.record(
        ctx, "discharges", discharge.id, "CREATE", None,
        {"container": container.code, "destination": dest.internal_code, "quantity": str(kg),
         "period": f"{period_from}/{period_to}", "source": source},
    )
    return out


def storno_discharge(
    ctx: Ctx, discharge_id: uuid.UUID, payload: StornoIn, operation_id: uuid.UUID
) -> DischargeOut:
    db = ctx.db
    discharge = db.scalar(
        select(Discharge)
        .where(Discharge.id == discharge_id, Discharge.tenant_id == ctx.tenant_id)
        .with_for_update()
    )
    if discharge is None:
        raise HTTPException(status_code=404, detail="Scarico non trovato")
    if discharge.status == "STORNATO":
        raise HTTPException(status_code=409, detail="Scarico già stornato")
    movements = list(
        db.scalars(
            select(Movement)
            .where(
                Movement.tenant_id == ctx.tenant_id,
                Movement.doc_type == "discharge",
                Movement.doc_id == discharge.id,
                Movement.type != MovementType.STORNO.value,
                Movement.quantity != 0,
            )
            .order_by(Movement.seq)
        )
    )
    done = operations._already_reversed(ctx, [m.id for m in movements])
    pending = [m for m in movements if m.id not in done]
    containers = stock.lock_containers(ctx, [discharge.container_id])
    now = datetime.now(UTC)
    for movement in pending:
        operations._reverse(
            ctx, movement, containers[movement.container_id], operation_id, payload.reason, now
        )
    for link in db.scalars(
        select(TraceLink).where(
            TraceLink.tenant_id == ctx.tenant_id, TraceLink.discharge_id == discharge.id
        )
    ).all():
        db.add(TraceLink(
            tenant_id=ctx.tenant_id, from_lot_id=link.from_lot_id,
            to_destination_lot_id=link.to_destination_lot_id, quantity=-link.quantity,
            kind=link.kind, discharge_id=discharge.id, operation_id=operation_id, occurred_at=now))
    discharge.status = "STORNATO"
    discharge.reversed_at = now
    discharge.reversal_reason = payload.reason
    db.flush()
    audit.record(ctx, "discharges", discharge.id, "STORNO", None, {"reason": payload.reason})
    return discharge_out(ctx, discharge)


def destination_summary(ctx: Ctx, dest: DestinationLot) -> DestinationSummaryOut:
    """Riepilogo del lotto di destinazione: kg per ricetta/fase/mese, lotti miscela e MP.

    I kg dei lotti MP sono quelli confluiti nei lotti miscela coinvolti, non rapportati alla
    quota scaricata: l'attribuzione proporzionale è la tracciabilità all'indietro (Fase 5).
    """
    db = ctx.db
    total, count = db.execute(
        select(func.coalesce(func.sum(Discharge.quantity), 0), func.count()).where(
            Discharge.tenant_id == ctx.tenant_id,
            Discharge.destination_lot_id == dest.id,
            Discharge.status == "REGISTRATO",
        )
    ).one()
    rows = db.execute(
        select(TraceLink.from_lot_id, Discharge.period_to, func.sum(TraceLink.quantity))
        .join(Discharge, Discharge.id == TraceLink.discharge_id)
        .where(
            TraceLink.tenant_id == ctx.tenant_id,
            TraceLink.to_destination_lot_id == dest.id,
            TraceLink.kind == "CERTO",
        )
        .group_by(TraceLink.from_lot_id, Discharge.period_to)
    ).all()
    lot_ids = {r[0] for r in rows}
    lots = {
        lot.id: lot
        for lot in db.scalars(select(Lot).where(Lot.id.in_(list(lot_ids) or [uuid.uuid4()])))
    }
    recipes = {
        r.id: r
        for r in db.scalars(
            select(Recipe).where(
                Recipe.id.in_([lot.recipe_id for lot in lots.values() if lot.recipe_id] or [uuid.uuid4()])
            )
        )
    }
    materials = {
        m.id: m
        for m in db.scalars(
            select(RawMaterial).where(
                RawMaterial.id.in_([lot.material_id for lot in lots.values() if lot.material_id] or [uuid.uuid4()])
            )
        )
    }

    by_recipe: dict[tuple, Decimal] = defaultdict(Decimal)
    by_phase: dict[str, Decimal] = defaultdict(Decimal)
    by_month: dict[str, Decimal] = defaultdict(Decimal)
    per_lot: dict[uuid.UUID, Decimal] = defaultdict(Decimal)
    for lot_id, period_to, quantity in rows:
        lot = lots[lot_id]
        per_lot[lot_id] += quantity
        by_month[f"{period_to:%Y-%m}"] += quantity
        if lot.kind == LotKind.MISCELA.value and lot.recipe_id in recipes:
            recipe = recipes[lot.recipe_id]
            by_recipe[(recipe.code, recipe.phase, f"{recipe.code} v{recipe.version}")] += quantity
            by_phase[recipe.phase] += quantity
        elif lot.kind == LotKind.NON_ALLOCATO.value:
            by_recipe[(None, None, "Non allocato")] += quantity
            by_phase["NON_ALLOCATO"] += quantity
        else:
            material = materials.get(lot.material_id)
            label = f"{material.code} (mangime acquistato)" if material else lot.internal_code
            by_recipe[(None, "ACQUISTATO", label)] += quantity
            by_phase["ACQUISTATO"] += quantity

    mix_ids = [i for i, lot in lots.items() if lot.kind == LotKind.MISCELA.value]
    material_rows = []
    if mix_ids:
        material_rows = db.execute(
            select(TraceLink.from_lot_id, func.sum(TraceLink.quantity))
            .where(
                TraceLink.tenant_id == ctx.tenant_id,
                TraceLink.to_lot_id.in_(mix_ids),
                TraceLink.kind == "CERTO",
            )
            .group_by(TraceLink.from_lot_id)
            .having(func.sum(TraceLink.quantity) != 0)
        ).all()
    source_lots = {
        lot.id: lot
        for lot in db.scalars(
            select(Lot).where(Lot.id.in_([r[0] for r in material_rows] or [uuid.uuid4()]))
        )
    }
    return DestinationSummaryOut(
        destination_lot_id=dest.id,
        code=dest.internal_code,
        external_code=dest.external_code,
        status=dest.status,
        head_count=dest.head_count,
        discharges_count=count,
        total_kg=total,
        by_recipe=[
            SummaryRecipeOut(recipe_code=code, phase=phase, description=description, kg=kg)
            for (code, phase, description), kg in sorted(by_recipe.items(), key=lambda i: i[0][2])
            if kg != 0
        ],
        by_phase=[{"phase": phase, "kg": str(kg)} for phase, kg in sorted(by_phase.items()) if kg != 0],
        by_month=[SummaryMonthOut(month=m, kg=kg) for m, kg in sorted(by_month.items()) if kg != 0],
        mix_lots=[
            SummaryLotOut(lot_id=i, lot_code=lots[i].internal_code, kind=lots[i].kind, kg=per_lot[i])
            for i in sorted(mix_ids, key=lambda i: lots[i].internal_code)
            if per_lot[i] != 0
        ],
        material_lots=[
            SummaryLotOut(lot_id=i, lot_code=source_lots[i].internal_code,
                          kind=source_lots[i].kind, kg=q)
            for i, q in sorted(material_rows, key=lambda r: source_lots[r[0]].internal_code)
        ],
    )
