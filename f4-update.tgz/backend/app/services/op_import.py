"""Import di ingressi, produzioni, scarichi e inventari da CSV/XLSX (RF-06).

Flusso: carica il file → anteprima riga per riga (validazione, duplicati) → conferma →
operazioni generate nella stessa transazione. Un file già importato (hash) o una riga già
importata (chiave naturale) non vengono duplicati; le righe restano collegate al file.
"""

import csv
import io
import uuid
from datetime import UTC, date, datetime, time
from decimal import Decimal
from zoneinfo import ZoneInfo

from fastapi import HTTPException
from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app import audit
from app.deps import Ctx
from app.importing import MAX_FILE_BYTES, read_rows
from app.models import (
    Container,
    DestinationLot,
    ImportFile,
    ImportRow,
    Location,
    Operation,
    Plant,
    RawMaterial,
    Recipe,
    Site,
    Supplier,
)
from app.schemas_discharge import DischargeIn
from app.schemas_opimport import ImportMappingConfig
from app.schemas_production import ProductionIn
from app.schemas_stock import InventoryIn, ReceiptIn
from app.services import discharge as discharge_service
from app.services import operations
from app.services import production as production_service
from app.services.receipts import create_receipt
from domain.importing import (
    apply_code_map,
    file_sha256,
    natural_key,
    operation_id_for,
    parse_amount,
    parse_when,
    row_hash,
    validate_mapping,
)
from domain.parsing import parse_bool_it
from domain.permissions import Permission, has_permission
from domain.production import recipe_valid_on

ROME = ZoneInfo("Europe/Rome")
MAX_ROWS = 5000


class RowError(Exception):
    """Errore di una singola riga, con messaggio per l'utente."""


# --- ricerca per codice nelle anagrafiche del tenant ------------------------------------
class Lookups:
    def __init__(self, ctx: Ctx) -> None:
        db, tid = ctx.db, ctx.tenant_id
        self.sites = {}
        for s in db.scalars(select(Site).where(Site.tenant_id == tid, Site.active.is_(True))):
            self.sites[s.asl_code.lower()] = s
            self.sites.setdefault(s.name.lower(), s)
        self.containers: dict[str, list[Container]] = {}
        for c in db.scalars(select(Container).where(Container.tenant_id == tid,
                                                    Container.active.is_(True),
                                                    Container.plant_id.is_(None))):
            self.containers.setdefault(c.code.lower(), []).append(c)
        self.destinations: dict[str, DestinationLot] = {}
        for d in db.scalars(select(DestinationLot).where(DestinationLot.tenant_id == tid,
                                                         DestinationLot.active.is_(True))):
            self.destinations[d.internal_code.lower()] = d
            if d.external_code:
                self.destinations.setdefault(d.external_code.lower(), d)
        self.locations: dict[str, list[Location]] = {}
        for loc in db.scalars(select(Location).where(Location.tenant_id == tid,
                                                     Location.active.is_(True))):
            self.locations.setdefault(loc.name.lower(), []).append(loc)
        self.plants: dict[str, list[Plant]] = {}
        for p in db.scalars(select(Plant).where(Plant.tenant_id == tid, Plant.active.is_(True))):
            self.plants.setdefault(p.code.lower(), []).append(p)
        self.recipes: dict[str, list[Recipe]] = {}
        for r in db.scalars(select(Recipe).where(Recipe.tenant_id == tid, Recipe.active.is_(True))):
            self.recipes.setdefault(r.code.lower(), []).append(r)
        self.materials = {
            m.code.lower(): m
            for m in db.scalars(select(RawMaterial).where(RawMaterial.tenant_id == tid,
                                                          RawMaterial.active.is_(True)))
        }
        self.suppliers: dict[str, Supplier] = {}
        for s in db.scalars(select(Supplier).where(Supplier.tenant_id == tid,
                                                   Supplier.active.is_(True))):
            self.suppliers[s.name.lower()] = s
            if s.vat_number:
                self.suppliers.setdefault(s.vat_number.lower(), s)

    def site(self, code: str | None) -> Site | None:
        if not code:
            return None
        site = self.sites.get(code.strip().lower())
        if site is None:
            raise RowError(f"sito '{code}' non trovato")
        return site

    def _pick(self, items, site: Site | None, what: str, code: str):
        if site is not None:
            items = [i for i in items if i.site_id == site.id]
        if not items:
            raise RowError(f"{what} '{code}' non trovato")
        if len(items) > 1:
            raise RowError(f"{what} '{code}' è presente in più siti: indica il sito")
        return items[0]

    def container(self, code: str, site_code: str | None) -> Container:
        return self._pick(self.containers.get(code.strip().lower(), []), self.site(site_code),
                          "contenitore", code)

    def location(self, name: str, site_code: str | None) -> Location:
        return self._pick(self.locations.get(name.strip().lower(), []), self.site(site_code),
                          "luogo", name)

    def plant(self, code: str, site_code: str | None) -> Plant:
        return self._pick(self.plants.get(code.strip().lower(), []), self.site(site_code),
                          "impianto", code)

    def destination(self, code: str) -> DestinationLot:
        lot = self.destinations.get(code.strip().lower())
        if lot is None:
            raise RowError(f"lotto di destinazione '{code}' non trovato")
        return lot

    def material(self, code: str) -> RawMaterial:
        material = self.materials.get(code.strip().lower())
        if material is None:
            raise RowError(f"materia prima '{code}' non trovata")
        return material

    def supplier(self, key: str) -> Supplier:
        supplier = self.suppliers.get(key.strip().lower())
        if supplier is None:
            raise RowError(f"fornitore '{key}' non trovato")
        return supplier

    def recipe(self, code: str, day: date) -> Recipe:
        valid = [r for r in self.recipes.get(code.strip().lower(), [])
                 if recipe_valid_on(r.valid_from, r.valid_to, day)]
        if not valid:
            raise RowError(f"ricetta '{code}' non valida il {day:%d/%m/%Y}")
        return max(valid, key=lambda r: r.version)


# --- lettura di una riga secondo la mappatura -------------------------------------------
class RowReader:
    def __init__(self, config: ImportMappingConfig, row: dict[str, str]) -> None:
        self.config = config
        self.row = {k.strip().lower(): v for k, v in row.items()}

    def get(self, field: str, *, mapped: bool = True) -> str | None:
        header = self.config.columns.get(field)
        value = self.row.get(header.strip().lower()) if header else None
        if value is None or str(value).strip() == "":
            value = self.config.defaults.get(field)
        if value is None or str(value).strip() == "":
            return None
        text = str(value).strip()
        if mapped and field in self.config.code_maps:
            text = apply_code_map(text, self.config.code_maps[field])
        return text

    def need(self, field: str) -> str:
        value = self.get(field)
        if value is None:
            raise RowError(f"valore mancante: {field}")
        return value

    def amount(self, field: str) -> Decimal:
        try:
            return parse_amount(self.need(field), self.config.decimal_separator)
        except ValueError as exc:
            raise RowError(f"{field}: {exc}") from exc

    def when(self, *fields: str) -> datetime:
        for field in fields:
            value = self.get(field, mapped=False)
            if value:
                try:
                    return parse_when(value, self.config.date_format)
                except ValueError as exc:
                    raise RowError(f"{field}: {exc}") from exc
        raise RowError(f"valore mancante: {' oppure '.join(fields)}")


def _utc_iso(moment: datetime) -> str | None:
    """Data/ora letta dal file (ora italiana) → ISO UTC.

    Senza orario: oggi = adesso (None, istante della registrazione); un giorno passato =
    mezzogiorno. Evita date nel futuro e conflitti con i movimenti della giornata."""
    if moment.hour == 0 and moment.minute == 0 and moment.second == 0:
        if moment.date() == datetime.now(ROME).date():
            return None
        moment = datetime.combine(moment.date(), time(12, 0))
    return moment.replace(tzinfo=ROME).astimezone(UTC).isoformat()


def _unit(reader: RowReader, allowed: tuple[str, ...]) -> str:
    unit = (reader.get("unit") or reader.config.default_unit).lower()
    if unit not in allowed:
        raise RowError(f"unità '{unit}' non ammessa (ammesse: {', '.join(allowed)})")
    return unit


def parse_discharge(reader: RowReader, lk: Lookups) -> tuple[dict, datetime]:
    end = reader.when("date_to", "date")
    start = reader.when("date_from") if reader.get("date_from", mapped=False) else None
    container = lk.container(reader.need("container"), reader.get("site"))
    payload: dict = {
        "container_id": str(container.id),
        "period_from": start.date().isoformat() if start else None,
        "period_to": end.date().isoformat(),
        "quantity": str(reader.amount("quantity")),
        "unit": _unit(reader, ("kg", "t")),
        "notes": reader.get("notes"),
    }
    if reader.get("destination_lot"):
        payload["destination_lot_id"] = str(lk.destination(reader.need("destination_lot")).id)
    else:
        payload["location_id"] = str(lk.location(reader.need("location"), reader.get("site")).id)
    DischargeIn.model_validate(payload)
    return payload, end


def parse_receipt(reader: RowReader, lk: Lookups) -> tuple[dict, datetime]:
    when = reader.when("date")
    container = lk.container(reader.need("container"), reader.get("site"))
    material = lk.material(reader.need("material"))
    supplier = lk.supplier(reader.need("supplier")) if reader.get("supplier") else None
    self_produced = parse_bool_it(reader.get("self_produced") or "no")
    if supplier is None and not self_produced:
        raise RowError("valore mancante: supplier (o self_produced = sì)")
    price = reader.get("price_eur_t")
    payload = {
        "site_id": str(container.site_id),
        "supplier_id": str(supplier.id) if supplier else None,
        "ddt_number": reader.get("ddt_number"),
        "ddt_date": when.date().isoformat(),
        "plate": reader.get("plate"),
        "lines": [{
            "material_id": str(material.id),
            "supplier_lot": reader.get("supplier_lot"),
            "unit": _unit(reader, ("kg", "t", "l")),
            "allocations": [{"container_id": str(container.id),
                             "quantity": str(reader.amount("quantity"))}],
            "price_eur_t": str(parse_amount(price, reader.config.decimal_separator)) if price else None,
            "self_produced": supplier is None,
        }],
    }
    ReceiptIn.model_validate(payload)
    return payload, when


def parse_production(reader: RowReader, lk: Lookups) -> tuple[dict, datetime]:
    when = reader.when("datetime", "date")
    plant = lk.plant(reader.need("plant"), reader.get("site"))
    recipe = lk.recipe(reader.need("recipe"), when.date())
    payload: dict = {
        "plant_id": str(plant.id),
        "recipe_id": str(recipe.id),
        "quantity": str(reader.amount("quantity")),
        "unit": _unit(reader, ("kg", "t")),
        "started_at": _utc_iso(when),
        "notes": reader.get("notes"),
    }
    if reader.get("destination_container"):
        payload["destination_container_id"] = str(
            lk.container(reader.need("destination_container"), reader.get("site")).id)
    ProductionIn.model_validate(payload)
    return payload, when


def parse_inventory(reader: RowReader, lk: Lookups) -> tuple[dict, datetime]:
    when = reader.when("date")
    container = lk.container(reader.need("container"), reader.get("site"))
    payload = {
        "container_id": str(container.id),
        "measured_quantity": str(reader.amount("measured_quantity")),
        "unit": _unit(reader, ("kg", "t")),
        "occurred_at": _utc_iso(when),
        "reason": reader.get("reason") or "Import inventario da file",
    }
    InventoryIn.model_validate({k: v for k, v in payload.items() if k != "container_id"})
    return payload, when


PARSERS = {
    "discharges": parse_discharge,
    "receipts": parse_receipt,
    "productions": parse_production,
    "inventories": parse_inventory,
}


def _message(exc: Exception) -> str:
    if isinstance(exc, ValidationError):
        return "; ".join(
            f"{'.'.join(str(p) for p in err['loc']) or 'riga'}: {err['msg']}" for err in exc.errors()
        )
    if isinstance(exc, HTTPException):
        return str(exc.detail)
    return str(exc)


# --- anteprima ---------------------------------------------------------------------------
def create_preview(
    ctx: Ctx, entity: str, mapping_id: uuid.UUID | None, config: ImportMappingConfig,
    filename: str, content: bytes,
) -> ImportFile:
    db = ctx.db
    errors = validate_mapping(entity, config.columns, config.defaults)
    if errors:
        raise HTTPException(status_code=422, detail="; ".join(errors))
    if len(content) > MAX_FILE_BYTES:
        raise HTTPException(status_code=413, detail="File troppo grande (massimo 5 MB)")
    sha = file_sha256(content)
    done = db.scalar(select(ImportFile).where(
        ImportFile.tenant_id == ctx.tenant_id, ImportFile.sha256 == sha,
        ImportFile.status == "APPLIED"))
    if done is not None:
        raise HTTPException(
            status_code=409,
            detail=f"Questo file è già stato importato (import {done.id}, "
            f"{done.applied_at:%d/%m/%Y %H:%M})",
        )
    try:
        rows = read_rows(filename, content)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail="File non leggibile") from exc
    if not rows:
        raise HTTPException(status_code=422, detail="Il file non contiene righe")
    if len(rows) > MAX_ROWS:
        raise HTTPException(status_code=413, detail=f"Troppe righe (massimo {MAX_ROWS})")

    for old in db.scalars(select(ImportFile).where(
            ImportFile.tenant_id == ctx.tenant_id, ImportFile.sha256 == sha,
            ImportFile.status == "PREVIEW")):
        old.status = "DISCARDED"  # nuova anteprima dello stesso file (es. mappatura cambiata)

    file = ImportFile(
        tenant_id=ctx.tenant_id, entity=entity, filename=filename[:200], sha256=sha,
        mapping_id=mapping_id, mapping_snapshot=config.model_dump(), status="PREVIEW",
        content=content, user_id=ctx.user.id,
    )
    db.add(file)
    db.flush()

    lookups = Lookups(ctx)
    parser = PARSERS[entity]
    keys = [natural_key([RowReader(config, r).get(f, mapped=False) or "" for f in config.natural_key])
            if config.natural_key else row_hash(r) for r in rows]
    already = {
        k for (k,) in db.execute(
            select(ImportRow.applied_key).where(
                ImportRow.tenant_id == ctx.tenant_id,
                ImportRow.applied_key.in_([f"{entity}:{k}" for k in keys]),
            )
        )
    }
    seen: dict[str, int] = {}
    counts = {"OK": 0, "ERROR": 0, "DUPLICATE": 0}
    for index, (raw, key) in enumerate(zip(rows, keys, strict=True)):
        line = index + 2  # riga 1 = intestazione
        status, message, payload = "OK", None, None
        if f"{entity}:{key}" in already:
            status, message = "DUPLICATE", "Riga già importata in precedenza"
        elif key in seen:
            status, message = "DUPLICATE", f"Riga ripetuta nel file (uguale alla riga {seen[key]})"
        else:
            try:
                payload, when = parser(RowReader(config, raw), lookups)
                payload["_when"] = when.isoformat()
            except (RowError, ValidationError, ValueError, HTTPException) as exc:
                status, message = "ERROR", _message(exc)
            seen[key] = line
        counts[status] += 1
        db.add(ImportRow(
            tenant_id=ctx.tenant_id, file_id=file.id, line=line, status=status,
            natural_key=key[:300], raw=raw, payload=payload, message=message,
        ))
    file.total = len(rows)
    file.ok_count, file.error_count, file.duplicate_count = (
        counts["OK"], counts["ERROR"], counts["DUPLICATE"])
    db.flush()
    audit.record(ctx, "op-imports", file.id, "PREVIEW", None,
                 {"entity": entity, "filename": filename, **counts})
    return file


# --- applicazione ------------------------------------------------------------------------
def _run(ctx: Ctx, entity: str, payload: dict, operation_id: uuid.UUID, row: ImportRow) -> dict:
    data = {k: v for k, v in payload.items() if k != "_when"}
    if entity == "discharges":
        out = discharge_service.create_discharge(
            ctx, DischargeIn.model_validate(data), operation_id, source="IMPORT",
            import_row_id=row.id)
        ref = {"discharge_id": str(out.id)}
    elif entity == "receipts":
        out = create_receipt(ctx, ReceiptIn.model_validate(data), operation_id)
        ref = {"receipt_id": str(out.id)}
    elif entity == "productions":
        out = production_service.create_production(
            ctx, ProductionIn.model_validate(data), operation_id)
        ref = {"production_id": str(out.id), "mix_lot": out.mix_lot_code}
    else:
        container_id = uuid.UUID(data.pop("container_id"))
        out = operations.inventory(ctx, container_id, InventoryIn.model_validate(data), operation_id)
        ref = {"operation_id": str(out.operation_id)}
    ctx.db.add(Operation(tenant_id=ctx.tenant_id, id=operation_id, kind=f"IMPORT_{entity}".upper()[:30],
                         user_id=ctx.user.id, result=out.model_dump(mode="json")))
    ctx.db.flush()
    return ref


def apply_file(ctx: Ctx, file_id: uuid.UUID, *, strict: bool) -> ImportFile:
    db = ctx.db
    file = db.scalar(select(ImportFile).where(
        ImportFile.id == file_id, ImportFile.tenant_id == ctx.tenant_id).with_for_update())
    if file is None:
        raise HTTPException(status_code=404, detail="Import non trovato")
    if file.status != "PREVIEW":
        raise HTTPException(status_code=409, detail=f"Import già {file.status.lower()}")
    needed = Permission.INVENTORY_WRITE if file.entity == "inventories" else Permission.MOVEMENTS_WRITE
    if not has_permission(ctx.role, needed):
        raise HTTPException(status_code=403, detail="Permesso negato per questo tipo di import")
    if strict and file.error_count:
        raise HTTPException(
            status_code=409,
            detail=f"Import rifiutato: {file.error_count} righe in errore da correggere",
        )
    already_applied = db.scalar(select(ImportFile).where(
        ImportFile.tenant_id == ctx.tenant_id, ImportFile.sha256 == file.sha256,
        ImportFile.status == "APPLIED"))
    if already_applied is not None:
        raise HTTPException(status_code=409, detail="Questo file è già stato importato")

    rows = list(db.scalars(select(ImportRow).where(
        ImportRow.file_id == file.id, ImportRow.status == "OK")))
    rows.sort(key=lambda r: ((r.payload or {}).get("_when", ""), r.line))  # in ordine cronologico
    applied = failed = 0
    for row in rows:
        key = f"{file.entity}:{row.natural_key}"
        operation_id = operation_id_for(ctx.tenant_id, file.entity, row.natural_key)
        try:
            with db.begin_nested():
                if db.get(Operation, (ctx.tenant_id, operation_id)) is not None:
                    raise RowError("Riga già registrata (operazione esistente)")
                ref = _run(ctx, file.entity, row.payload or {}, operation_id, row)
                row.status, row.operation_id, row.result_ref, row.applied_key = (
                    "APPLIED", operation_id, ref, key)
                db.flush()
            applied += 1
        except (RowError, ValidationError, ValueError, HTTPException, IntegrityError) as exc:
            if strict:
                db.rollback()
                raise HTTPException(
                    status_code=409,
                    detail=f"Import annullato alla riga {row.line}: {_message(exc)}",
                ) from exc
            row.status = "FAILED"
            row.message = (_message(exc) if not isinstance(exc, IntegrityError)
                           else "Riga già importata")[:500]
            failed += 1
    file.status = "APPLIED"
    file.applied_count = applied
    file.failed_count = failed
    file.applied_at = datetime.now(UTC)
    db.flush()
    audit.record(ctx, "op-imports", file.id, "APPLY", None,
                 {"entity": file.entity, "applied": applied, "failed": failed})
    return file


def report_csv(file: ImportFile, rows: list[ImportRow]) -> str:
    """Riepilogo righe ok/scartate scaricabile (CSV con separatore ';')."""
    columns: list[str] = []
    for row in rows:
        for column in row.raw:
            if column not in columns:
                columns.append(column)
    buffer = io.StringIO()
    writer = csv.writer(buffer, delimiter=";")
    writer.writerow(["riga", "stato", "messaggio", "chiave", *columns])
    for row in rows:
        writer.writerow([row.line, row.status, row.message or "", row.natural_key,
                         *[row.raw.get(c, "") for c in columns]])
    return buffer.getvalue()
