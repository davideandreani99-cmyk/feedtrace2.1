"""Produzione delle miscele: batch, carro, broda (RF-04, SPEC §6.4)."""

import uuid
from datetime import UTC, datetime
from decimal import Decimal
from zoneinfo import ZoneInfo

from fastapi import HTTPException
from sqlalchemy import select

from app import audit
from app.deps import Ctx
from app.models import (
    Container,
    Discharge,
    Lot,
    Movement,
    Plant,
    Production,
    ProductionLine,
    RawMaterial,
    Recipe,
    RecipeLine,
    TraceLink,
)
from app.schemas_production import (
    AllocationOut,
    ProductionIn,
    ProductionLineOut,
    ProductionOut,
)
from app.schemas_discharge import DischargeIn
from app.schemas_stock import StornoIn, WarningOut
from app.services import discharge as discharge_service
from app.services import operations, stock
from app.services.receipts import next_progressive
from domain.enums import ContainerType, LotKind, LotRule, LotStatus, MovementType
from domain.permissions import Permission, has_permission
from domain.production import (
    blocked_lots,
    daily_key,
    deviation_pct,
    exceeds_tolerance,
    medicated_errors,
    mix_lot_code,
    recipe_valid_on,
    theoretical_kg,
)
from domain.units import convert_to_kg

ROME = ZoneInfo("Europe/Rome")


def _bad(message: str) -> HTTPException:
    return HTTPException(status_code=422, detail=message)


def _kg(quantity: Decimal, unit: str) -> Decimal:
    return (quantity * 1000 if unit == "t" else quantity).quantize(Decimal("0.001"))


def get_plant_container(ctx: Ctx, plant: Plant) -> Container:
    """Contenitore virtuale dell'impianto (D10): destinazione per scarichi diretti (F4)."""
    container = ctx.db.scalar(
        select(Container).where(
            Container.tenant_id == ctx.tenant_id, Container.plant_id == plant.id
        )
    )
    if container is None:
        container = Container(
            tenant_id=ctx.tenant_id,
            site_id=plant.site_id,
            code=f"IMP-{plant.code}",
            type=ContainerType.IMPIANTO.value,
            unit="kg",
            consumption_policy="PROPORZIONALE",
            plant_id=plant.id,
        )
        ctx.db.add(container)
        ctx.db.flush()
    return container


def get_mix_lot(ctx: Ctx, plant: Plant, recipe: Recipe, day) -> Lot:
    """Regola lotto miscela per impianto (SPEC §6.4): per ciclo oppure giornaliero per ricetta."""
    rule = LotRule(plant.lot_rule)
    key = None
    if rule == LotRule.GIORNALIERO_PER_RICETTA:
        key = daily_key(plant.id, recipe.id, day)
        existing = ctx.db.scalar(
            select(Lot).where(Lot.tenant_id == ctx.tenant_id, Lot.daily_key == key)
        )
        if existing is not None:
            return existing
        code = mix_lot_code(rule, plant.code, day, recipe.code, recipe.version, None)
    else:
        progressive = next_progressive(ctx, plant.site_id, day, kind="MX")
        code = mix_lot_code(rule, plant.code, day, recipe.code, recipe.version, progressive)
    lot = Lot(
        tenant_id=ctx.tenant_id,
        kind=LotKind.MISCELA.value,
        site_id=plant.site_id,
        internal_code=code,
        plant_id=plant.id,
        recipe_id=recipe.id,
        lot_date=day,
        entry_date=day,
        daily_key=key,
        medicated=recipe.medicated,
        initial_qty=Decimal("0"),
        status=LotStatus.DISPONIBILE.value,
    )
    ctx.db.add(lot)
    ctx.db.flush()
    return lot


def production_out(ctx: Ctx, production: Production) -> ProductionOut:
    db = ctx.db
    recipe = db.get(Recipe, production.recipe_id)
    mix = db.get(Lot, production.mix_lot_id)
    lines = list(
        db.scalars(
            select(ProductionLine)
            .where(
                ProductionLine.production_id == production.id,
                ProductionLine.tenant_id == ctx.tenant_id,
            )
            .order_by(ProductionLine.position)
        )
    )
    codes = {
        m.id: m.code
        for m in db.scalars(
            select(RawMaterial).where(RawMaterial.id.in_([ln.material_id for ln in lines] or [uuid.uuid4()]))
        )
    }
    return ProductionOut(
        id=production.id,
        plant_id=production.plant_id,
        recipe_id=production.recipe_id,
        recipe_code=recipe.code,
        recipe_version=recipe.version,
        status=production.status,
        source=production.source,
        started_at=production.started_at,
        ended_at=production.ended_at,
        theoretical_qty=production.theoretical_qty,
        actual_qty=production.actual_qty,
        mix_lot_id=production.mix_lot_id,
        mix_lot_code=mix.internal_code,
        destination_container_id=production.destination_container_id,
        lines=[
            ProductionLineOut(
                material_id=ln.material_id,
                material_code=codes[ln.material_id],
                container_id=ln.container_id,
                theoretical_qty=ln.theoretical_qty,
                actual_qty=ln.actual_qty,
                deviation_pct=ln.deviation_pct,
                tolerance_pct=ln.tolerance_pct,
                allocations=[AllocationOut(**a) for a in ln.allocations],
            )
            for ln in lines
        ],
        warnings=[WarningOut(**w) for w in production.warnings],
        overrides=production.overrides,
        notes=production.notes,
        reversal_reason=production.reversal_reason,
        discharges=[
            discharge_service.discharge_out(ctx, d)
            for d in db.scalars(
                select(Discharge)
                .where(Discharge.tenant_id == ctx.tenant_id, Discharge.production_id == production.id)
                .order_by(Discharge.created_at)
            )
        ],
    )


def create_production(ctx: Ctx, payload: ProductionIn, operation_id: uuid.UUID) -> ProductionOut:
    db = ctx.db
    plant = db.scalar(
        select(Plant)
        .where(Plant.id == payload.plant_id, Plant.tenant_id == ctx.tenant_id)
        .with_for_update()  # serializza le produzioni dello stesso impianto (lotto giornaliero)
    )
    if plant is None or not plant.active:
        raise _bad("Impianto non trovato o disattivato")
    recipe = db.scalar(
        select(Recipe).where(Recipe.id == payload.recipe_id, Recipe.tenant_id == ctx.tenant_id)
    )
    if recipe is None or not recipe.active:
        raise _bad("Ricetta non trovata o disattivata")
    if recipe.plant_type != plant.type:
        raise _bad(f"La ricetta {recipe.code} è per impianti di tipo {recipe.plant_type}")

    errors = medicated_errors(
        recipe.medicated, plant.medicated_authorized, plant.medicated_contaminated,
        rev_valid=False,  # la gestione delle REV arriva in Fase 6
    )
    if errors:
        raise _bad("; ".join(errors))

    if payload.direct_discharges and payload.destination_container_id is not None:
        raise _bad(
            "Gli scarichi contestuali sono ammessi solo senza contenitore di destinazione "
            "(la miscela passa dal contenitore dell'impianto)"
        )
    produced_kg = _kg(payload.quantity, payload.unit)
    output_kg = _kg(payload.actual_quantity, payload.unit) if payload.actual_quantity else produced_kg

    recipe_lines = list(
        db.scalars(
            select(RecipeLine)
            .where(RecipeLine.recipe_id == recipe.id, RecipeLine.tenant_id == ctx.tenant_id)
            .order_by(RecipeLine.position)
        )
    )
    materials = {
        m.id: m
        for m in db.scalars(
            select(RawMaterial).where(RawMaterial.id.in_([rl.material_id for rl in recipe_lines]))
        )
    }
    overrides_in = {line.material_id: line for line in payload.lines}
    unknown = set(overrides_in) - {rl.material_id for rl in recipe_lines}
    if unknown:
        raise _bad("Una riga indicata non appartiene alla ricetta")

    if payload.destination_container_id is not None:
        destination = db.scalar(
            select(Container).where(
                Container.id == payload.destination_container_id,
                Container.tenant_id == ctx.tenant_id,
            )
        )
        if destination is None:
            raise _bad("Contenitore di destinazione non trovato")
    else:
        destination = get_plant_container(ctx, plant)

    line_container: dict[uuid.UUID, uuid.UUID | None] = {}
    for rl in recipe_lines:
        material = materials[rl.material_id]
        override = overrides_in.get(material.id)
        container_id = (
            override.container_id if override and override.container_id else rl.default_container_id
        )
        if material.lot_tracked and container_id is None:
            raise _bad(f"Contenitore di prelievo mancante per {material.code}")
        line_container[material.id] = container_id

    ids = [destination.id] + [cid for cid in line_container.values() if cid is not None]
    containers = stock.lock_containers(ctx, ids)
    for container in containers.values():
        if container.site_id != plant.site_id:
            raise _bad(f"Il contenitore {container.code} appartiene a un altro sito")
    occurred_at = stock.resolve_occurred_at(ctx, payload.started_at, list(containers))
    day = occurred_at.astimezone(ROME).date()
    if not recipe_valid_on(recipe.valid_from, recipe.valid_to, day):
        raise _bad(f"La ricetta {recipe.code} (versione {recipe.version}) non è valida il {day}")

    mix = get_mix_lot(ctx, plant, recipe, day)
    production = Production(
        tenant_id=ctx.tenant_id,
        plant_id=plant.id,
        recipe_id=recipe.id,
        started_at=occurred_at,
        ended_at=payload.ended_at,
        theoretical_qty=produced_kg,
        actual_qty=output_kg,
        mix_lot_id=mix.id,
        destination_container_id=destination.id,
        operation_id=operation_id,
        user_id=ctx.user.id,
        notes=payload.notes,
    )
    db.add(production)
    db.flush()

    warnings: list[WarningOut] = []
    used_lot_ids: set[uuid.UUID] = set()
    line_rows: list[ProductionLine] = []

    for position, rl in enumerate(recipe_lines):
        material = materials[rl.material_id]
        override = overrides_in.get(material.id)
        theoretical = theoretical_kg(rl.kg_per_t, produced_kg)
        if override is not None and override.actual_quantity is not None:
            try:
                actual = convert_to_kg(override.actual_quantity, override.unit, material.density_kg_l)
            except ValueError as exc:
                raise _bad(f"{material.code}: {exc}") from exc
        else:
            actual = theoretical
        tolerance = rl.tolerance_pct if rl.tolerance_pct is not None else plant.tolerance_pct
        deviation = deviation_pct(theoretical, actual)
        if exceeds_tolerance(deviation, tolerance):
            warnings.append(
                WarningOut(
                    code="DEVIATION",
                    message=f"{material.code}: scostamento {deviation}% oltre la tolleranza "
                    f"({tolerance}%)",
                )
            )

        line = ProductionLine(
            id=uuid.uuid4(),
            tenant_id=ctx.tenant_id,
            production_id=production.id,
            position=position,
            material_id=material.id,
            container_id=line_container[material.id],
            theoretical_qty=theoretical,
            actual_qty=actual,
            deviation_pct=deviation,
            tolerance_pct=tolerance,
            allocations=[],
        )
        allocations: list[dict] = []
        if material.lot_tracked and actual > 0:
            container = containers[line_container[material.id]]
            outcome = stock.consume_from_container(
                ctx, container, actual, MovementType.PRELIEVO_PRODUZIONE, occurred_at,
                operation_id, doc_type="production", doc_id=production.id,
            )
            for movement in outcome.movements:
                taken = -movement.quantity
                used_lot_ids.add(movement.lot_id)
                allocations.append({"lot_id": str(movement.lot_id), "quantity": str(taken)})
                db.add(
                    TraceLink(
                        tenant_id=ctx.tenant_id, from_lot_id=movement.lot_id, to_lot_id=mix.id,
                        quantity=taken, kind="CERTO", production_id=production.id,
                        production_line_id=line.id, operation_id=operation_id,
                        occurred_at=occurred_at,
                    )
                )
            for possible in outcome.possible_links:
                db.add(
                    TraceLink(
                        tenant_id=ctx.tenant_id, from_lot_id=possible.lot_id, to_lot_id=mix.id,
                        quantity=possible.quantity, kind="POSSIBILE", production_id=production.id,
                        production_line_id=line.id, operation_id=operation_id,
                        occurred_at=occurred_at,
                    )
                )
            negative = stock.negative_warning(
                container, outcome.total_before - actual, outcome.shortfall
            )
            if negative:
                warnings.append(WarningOut(**negative))
        line.allocations = allocations
        db.add(line)
        line_rows.append(line)
    db.flush()

    # lotti usati: nomi per il riepilogo e blocchi per stato (SPEC §6.4)
    lots = {
        lot.id: lot
        for lot in db.scalars(select(Lot).where(Lot.id.in_(list(used_lot_ids) or [uuid.uuid4()])))
    }
    for line in line_rows:
        line.allocations = [
            {**a, "lot_code": lots[uuid.UUID(a["lot_id"])].internal_code} for a in line.allocations
        ]
    blocked = blocked_lots(
        [
            (lot.internal_code, LotStatus(lot.status))
            for lot in lots.values()
            if lot.kind != LotKind.NON_ALLOCATO.value
        ]
    )
    overrides: list[dict] = []
    if blocked:
        listing = ", ".join(f"{code} ({status})" for code, status in blocked)
        if not payload.override_reason:
            raise _bad(
                f"Lotti non utilizzabili in produzione: {listing}. Solo il Responsabile può "
                "procedere con un override motivato"
            )
        if not has_permission(ctx.role, Permission.INVENTORY_WRITE):
            raise HTTPException(
                status_code=403,
                detail="L'override sui lotti bloccati è riservato al Responsabile",
            )
        overrides.append(
            {
                "type": "BLOCKED_LOTS",
                "lots": [code for code, _ in blocked],
                "reason": payload.override_reason,
                "user_id": str(ctx.user.id),
                "at": datetime.now(UTC).isoformat(),
            }
        )
        warnings.append(
            WarningOut(code="OVERRIDE", message=f"Override sui lotti bloccati: {listing}")
        )

    stock.add_movement(
        ctx, container=destination, lot_id=mix.id, quantity=output_kg,
        mtype=MovementType.CARICO_PRODUZIONE, occurred_at=occurred_at,
        operation_id=operation_id, doc_type="production", doc_id=production.id,
    )
    mix.initial_qty = (mix.initial_qty or Decimal("0")) + output_kg
    db.flush()
    if destination.capacity is not None and destination.unit == "kg":
        total = stock.total_of(stock.load_stock(db, ctx.tenant_id, destination.id))
        if total > destination.capacity:
            warnings.append(
                WarningOut(
                    code="CAPACITY_EXCEEDED",
                    message=f"Capacità superata nel contenitore {destination.code} "
                    f"({total} kg su {destination.capacity})",
                )
            )

    for index, direct in enumerate(payload.direct_discharges):
        done = discharge_service.create_discharge(
            ctx,
            DischargeIn(
                container_id=destination.id,
                destination_lot_id=direct.destination_lot_id,
                location_id=direct.location_id,
                period_to=day,
                quantity=direct.quantity,
                unit=direct.unit,
            ),
            uuid.uuid5(operation_id, f"discharge-{index}"),
            production_id=production.id,
        )
        warnings.extend(done.warnings)

    production.warnings = [w.model_dump() for w in warnings]
    production.overrides = overrides
    db.flush()
    out = production_out(ctx, production)
    audit.record(
        ctx, "productions", production.id, "CREATE", None,
        {"recipe": recipe.code, "version": recipe.version, "mix_lot": mix.internal_code,
         "quantity": str(output_kg)},
    )
    if overrides:
        audit.record(ctx, "productions", production.id, "OVERRIDE", None, overrides[0])
    return out


def storno_production(
    ctx: Ctx, production_id: uuid.UUID, payload: StornoIn, operation_id: uuid.UUID
) -> ProductionOut:
    """Storna una produzione: movimenti contrari, legami compensati, lotto miscela ridotto."""
    db = ctx.db
    production = db.scalar(
        select(Production)
        .where(Production.id == production_id, Production.tenant_id == ctx.tenant_id)
        .with_for_update()
    )
    if production is None:
        raise HTTPException(status_code=404, detail="Produzione non trovata")
    if production.status == "STORNATA":
        raise HTTPException(status_code=409, detail="Produzione già stornata")

    for linked in db.scalars(
        select(Discharge).where(
            Discharge.tenant_id == ctx.tenant_id,
            Discharge.production_id == production.id,
            Discharge.status == "REGISTRATO",
        )
    ).all():
        discharge_service.storno_discharge(
            ctx, linked.id, payload, uuid.uuid5(operation_id, f"storno-discharge-{linked.id}")
        )

    movements = list(
        db.scalars(
            select(Movement)
            .where(
                Movement.tenant_id == ctx.tenant_id,
                Movement.doc_type == "production",
                Movement.doc_id == production.id,
                Movement.type != MovementType.STORNO.value,
                Movement.quantity != 0,
            )
            .order_by(Movement.seq)
        )
    )
    done = operations._already_reversed(ctx, [m.id for m in movements])
    pending = [m for m in movements if m.id not in done]
    containers = stock.lock_containers(ctx, [m.container_id for m in pending] or [production.destination_container_id])
    now = datetime.now(UTC)
    for movement in pending:
        operations._reverse(
            ctx, movement, containers[movement.container_id], operation_id, payload.reason, now
        )
    for link in db.scalars(
        select(TraceLink).where(
            TraceLink.tenant_id == ctx.tenant_id, TraceLink.production_id == production.id
        )
    ).all():
        db.add(
            TraceLink(
                tenant_id=ctx.tenant_id, from_lot_id=link.from_lot_id, to_lot_id=link.to_lot_id,
                quantity=-link.quantity, kind=link.kind, production_id=production.id,
                production_line_id=link.production_line_id, operation_id=operation_id,
                occurred_at=now,
            )
        )
    mix = db.get(Lot, production.mix_lot_id)
    mix.initial_qty = (mix.initial_qty or Decimal("0")) - production.actual_qty
    production.status = "STORNATA"
    production.reversed_at = now
    production.reversal_reason = payload.reason
    db.flush()
    audit.record(
        ctx, "productions", production.id, "STORNO", None,
        {"reason": payload.reason, "movements": len(pending)},
    )
    return production_out(ctx, production)
