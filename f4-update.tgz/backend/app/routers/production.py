import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select

from app.deps import Ctx, require
from app.idempotency import run_idempotent
from app.models import DestinationLot, Lot, Production, TraceLink
from app.schemas_production import (
    LinkDestinationOut,
    LinkLotOut,
    LotLinksOut,
    ProductionIn,
    ProductionOut,
)
from app.schemas_stock import StornoIn
from app.services import production as service
from domain.permissions import Permission

router = APIRouter(tags=["production"])


@router.post("/productions", response_model=ProductionOut, status_code=201)
def post_production(payload: ProductionIn, ctx: Ctx = Depends(require(Permission.MOVEMENTS_WRITE))):
    """Registra una produzione (batch, carro, broda). Idempotente su `operation_id`."""
    return run_idempotent(
        ctx, payload.operation_id, "PRODUCTION",
        lambda op: service.create_production(ctx, payload, op),
    )


@router.get("/productions", response_model=list[ProductionOut])
def list_productions(
    plant_id: uuid.UUID | None = None,
    recipe_id: uuid.UUID | None = None,
    mix_lot_id: uuid.UUID | None = None,
    status: str | None = None,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    ctx: Ctx = Depends(require(Permission.STOCK_READ)),
):
    stmt = select(Production).where(Production.tenant_id == ctx.tenant_id)
    if plant_id:
        stmt = stmt.where(Production.plant_id == plant_id)
    if recipe_id:
        stmt = stmt.where(Production.recipe_id == recipe_id)
    if mix_lot_id:
        stmt = stmt.where(Production.mix_lot_id == mix_lot_id)
    if status:
        stmt = stmt.where(Production.status == status)
    if date_from:
        stmt = stmt.where(Production.started_at >= date_from)
    if date_to:
        stmt = stmt.where(Production.started_at <= date_to)
    rows = ctx.db.scalars(stmt.order_by(Production.started_at.desc()).limit(limit).offset(offset))
    return [service.production_out(ctx, p) for p in rows]


@router.get("/productions/{production_id}", response_model=ProductionOut)
def get_production(production_id: uuid.UUID, ctx: Ctx = Depends(require(Permission.STOCK_READ))):
    production = ctx.db.scalar(
        select(Production).where(
            Production.id == production_id, Production.tenant_id == ctx.tenant_id
        )
    )
    if production is None:
        raise HTTPException(status_code=404, detail="Produzione non trovata")
    return service.production_out(ctx, production)


@router.post(
    "/productions/{production_id}/storno", response_model=ProductionOut, status_code=201
)
def storno_production(
    production_id: uuid.UUID, payload: StornoIn,
    ctx: Ctx = Depends(require(Permission.INVENTORY_WRITE)),
):
    return run_idempotent(
        ctx, payload.operation_id, "STORNO_PRODUCTION",
        lambda op: service.storno_production(ctx, production_id, payload, op),
    )


@router.get("/lots/{lot_id}/links", response_model=LotLinksOut)
def lot_links(lot_id: uuid.UUID, ctx: Ctx = Depends(require(Permission.STOCK_READ))):
    """Un livello di tracciabilità: da quali lotti proviene e verso quali è andato (CERTI/POSSIBILI)."""
    lot = ctx.db.scalar(select(Lot).where(Lot.id == lot_id, Lot.tenant_id == ctx.tenant_id))
    if lot is None:
        raise HTTPException(status_code=404, detail="Lotto non trovato")

    def collect(match_col, other_col) -> list[LinkLotOut]:
        rows = ctx.db.execute(
            select(other_col, Lot.internal_code, TraceLink.kind, func.sum(TraceLink.quantity))
            .join(Lot, Lot.id == other_col)
            .where(TraceLink.tenant_id == ctx.tenant_id, match_col == lot_id)
            .group_by(other_col, Lot.internal_code, TraceLink.kind)
            .having(func.sum(TraceLink.quantity) != 0)
            .order_by(Lot.internal_code)
        ).all()
        return [LinkLotOut(lot_id=r[0], lot_code=r[1], kind=r[2], quantity=r[3]) for r in rows]

    dest_rows = ctx.db.execute(
        select(TraceLink.to_destination_lot_id, DestinationLot.internal_code,
               DestinationLot.external_code, TraceLink.kind, func.sum(TraceLink.quantity))
        .join(DestinationLot, DestinationLot.id == TraceLink.to_destination_lot_id)
        .where(TraceLink.tenant_id == ctx.tenant_id, TraceLink.from_lot_id == lot_id)
        .group_by(TraceLink.to_destination_lot_id, DestinationLot.internal_code,
                  DestinationLot.external_code, TraceLink.kind)
        .having(func.sum(TraceLink.quantity) != 0)
        .order_by(DestinationLot.internal_code)
    ).all()
    return LotLinksOut(
        sources=collect(TraceLink.to_lot_id, TraceLink.from_lot_id),
        targets=collect(TraceLink.from_lot_id, TraceLink.to_lot_id),
        destinations=[
            LinkDestinationOut(destination_lot_id=r[0], destination_code=r[1], external_code=r[2],
                               kind=r[3], quantity=r[4])
            for r in dest_rows
        ],
    )
