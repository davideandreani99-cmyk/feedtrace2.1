import json
import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import Response
from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app import audit
from app.deps import Ctx, require
from app.models import ImportFile, ImportMapping, ImportRow
from app.schemas_opimport import (
    ImportFileOut,
    ImportMappingConfig,
    ImportMappingIn,
    ImportMappingOut,
    ImportRowOut,
)
from app.services import op_import
from domain.importing import ENTITIES, validate_mapping
from domain.permissions import Permission

router = APIRouter(tags=["op-imports"])
PERM = Permission.IMPORT_OPERATIONS


# --- mappature salvabili per formato -----------------------------------------------------
def _check_mapping(payload: ImportMappingIn) -> None:
    errors = validate_mapping(payload.entity, payload.config.columns, payload.config.defaults)
    if errors:
        raise HTTPException(status_code=422, detail="; ".join(errors))


def _load_mapping(ctx: Ctx, mapping_id: uuid.UUID) -> ImportMapping:
    mapping = ctx.db.scalar(select(ImportMapping).where(
        ImportMapping.id == mapping_id, ImportMapping.tenant_id == ctx.tenant_id))
    if mapping is None:
        raise HTTPException(status_code=404, detail="Mappatura non trovata")
    return mapping


@router.get("/import-mappings", response_model=list[ImportMappingOut])
def list_mappings(
    entity: str | None = None, ctx: Ctx = Depends(require(PERM))
):
    stmt = select(ImportMapping).where(
        ImportMapping.tenant_id == ctx.tenant_id, ImportMapping.active.is_(True))
    if entity:
        stmt = stmt.where(ImportMapping.entity == entity)
    return list(ctx.db.scalars(stmt.order_by(ImportMapping.name)))


@router.post("/import-mappings", response_model=ImportMappingOut, status_code=201)
def create_mapping(payload: ImportMappingIn, ctx: Ctx = Depends(require(PERM))):
    _check_mapping(payload)
    mapping = ImportMapping(tenant_id=ctx.tenant_id, name=payload.name, entity=payload.entity,
                            config=payload.config.model_dump())
    ctx.db.add(mapping)
    try:
        ctx.db.flush()
    except IntegrityError as exc:
        ctx.db.rollback()
        raise HTTPException(status_code=409, detail="Esiste già una mappatura con questo nome") from exc
    ctx.db.refresh(mapping)
    out = ImportMappingOut.model_validate(mapping)
    audit.record(ctx, "import-mappings", mapping.id, "CREATE", None, out.model_dump(mode="json"))
    ctx.db.commit()
    return out


@router.put("/import-mappings/{mapping_id}", response_model=ImportMappingOut)
def update_mapping(
    mapping_id: uuid.UUID, payload: ImportMappingIn, ctx: Ctx = Depends(require(PERM))
):
    _check_mapping(payload)
    mapping = _load_mapping(ctx, mapping_id)
    before = ImportMappingOut.model_validate(mapping).model_dump(mode="json")
    mapping.name, mapping.entity, mapping.config = (
        payload.name, payload.entity, payload.config.model_dump())
    try:
        ctx.db.flush()
    except IntegrityError as exc:
        ctx.db.rollback()
        raise HTTPException(status_code=409, detail="Esiste già una mappatura con questo nome") from exc
    ctx.db.refresh(mapping)
    out = ImportMappingOut.model_validate(mapping)
    audit.record(ctx, "import-mappings", mapping.id, "UPDATE", before, out.model_dump(mode="json"))
    ctx.db.commit()
    return out


@router.delete("/import-mappings/{mapping_id}", response_model=ImportMappingOut)
def deactivate_mapping(mapping_id: uuid.UUID, ctx: Ctx = Depends(require(PERM))):
    mapping = _load_mapping(ctx, mapping_id)
    mapping.active = False
    ctx.db.flush()
    ctx.db.refresh(mapping)
    out = ImportMappingOut.model_validate(mapping)
    audit.record(ctx, "import-mappings", mapping.id, "DEACTIVATE", None, out.model_dump(mode="json"))
    ctx.db.commit()
    return out


# --- file importati ----------------------------------------------------------------------
def _load_file(ctx: Ctx, file_id: uuid.UUID) -> ImportFile:
    file = ctx.db.scalar(select(ImportFile).where(
        ImportFile.id == file_id, ImportFile.tenant_id == ctx.tenant_id))
    if file is None:
        raise HTTPException(status_code=404, detail="Import non trovato")
    return file


@router.post("/op-imports", response_model=ImportFileOut, status_code=201)
async def upload_file(
    entity: str = Form(...),
    mapping_id: uuid.UUID | None = Form(None),
    mapping_json: str | None = Form(None, description="Mappatura al volo, in alternativa a mapping_id"),
    file: UploadFile = File(...),
    ctx: Ctx = Depends(require(PERM)),
):
    """Carica un file e ne produce l'anteprima riga per riga (nessuna operazione registrata)."""
    if entity not in ENTITIES:
        raise HTTPException(status_code=404, detail=f"Entità non importabile. Ammesse: {', '.join(ENTITIES)}")
    if mapping_id:
        mapping = _load_mapping(ctx, mapping_id)
        if mapping.entity != entity:
            raise HTTPException(status_code=422, detail="La mappatura è per un altro tipo di dati")
        config = ImportMappingConfig.model_validate(mapping.config)
    elif mapping_json:
        try:
            config = ImportMappingConfig.model_validate(json.loads(mapping_json))
        except (json.JSONDecodeError, ValidationError) as exc:
            raise HTTPException(status_code=422, detail=f"Mappatura non valida: {exc}") from exc
    else:
        raise HTTPException(status_code=422, detail="Indica una mappatura (mapping_id o mapping_json)")
    content = await file.read()
    created = op_import.create_preview(
        ctx, entity, mapping_id, config, file.filename or "file", content)
    out = ImportFileOut.model_validate(created)
    ctx.db.commit()
    return out


@router.get("/op-imports", response_model=list[ImportFileOut])
def list_files(
    entity: str | None = None,
    limit: int = Query(50, ge=1, le=200),
    ctx: Ctx = Depends(require(PERM)),
):
    stmt = select(ImportFile).where(ImportFile.tenant_id == ctx.tenant_id)
    if entity:
        stmt = stmt.where(ImportFile.entity == entity)
    return list(ctx.db.scalars(stmt.order_by(ImportFile.created_at.desc()).limit(limit)))


@router.get("/op-imports/{file_id}", response_model=ImportFileOut)
def get_file(file_id: uuid.UUID, ctx: Ctx = Depends(require(PERM))):
    return _load_file(ctx, file_id)


@router.get("/op-imports/{file_id}/rows", response_model=list[ImportRowOut])
def list_rows(
    file_id: uuid.UUID,
    status: str | None = None,
    limit: int = Query(200, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    ctx: Ctx = Depends(require(PERM)),
):
    _load_file(ctx, file_id)
    stmt = select(ImportRow).where(
        ImportRow.tenant_id == ctx.tenant_id, ImportRow.file_id == file_id)
    if status:
        stmt = stmt.where(ImportRow.status == status)
    return list(ctx.db.scalars(stmt.order_by(ImportRow.line).limit(limit).offset(offset)))


@router.post("/op-imports/{file_id}/confirm", response_model=ImportFileOut)
def confirm_file(
    file_id: uuid.UUID,
    strict: bool = Query(False, description="Tutto o niente: rifiuta l'import se una riga fallisce"),
    ctx: Ctx = Depends(require(PERM)),
):
    """Applica le righe valide in un'unica transazione; le righe in errore restano scartate."""
    applied = op_import.apply_file(ctx, file_id, strict=strict)
    out = ImportFileOut.model_validate(applied)
    ctx.db.commit()
    return out


@router.delete("/op-imports/{file_id}", response_model=ImportFileOut)
def discard_file(file_id: uuid.UUID, ctx: Ctx = Depends(require(PERM))):
    file = _load_file(ctx, file_id)
    if file.status != "PREVIEW":
        raise HTTPException(status_code=409, detail="Si può scartare solo un'anteprima")
    file.status = "DISCARDED"
    ctx.db.flush()
    ctx.db.refresh(file)
    out = ImportFileOut.model_validate(file)
    ctx.db.commit()
    return out


@router.get("/op-imports/{file_id}/download")
def download_original(file_id: uuid.UUID, ctx: Ctx = Depends(require(PERM))):
    """File d'origine, consultabile dopo l'import."""
    file = _load_file(ctx, file_id)
    return Response(
        content=file.content, media_type="application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{file.filename}"'},
    )


@router.get("/op-imports/{file_id}/report")
def download_report(file_id: uuid.UUID, ctx: Ctx = Depends(require(PERM))):
    """Riepilogo righe ok/scartate in CSV."""
    file = _load_file(ctx, file_id)
    rows = list(ctx.db.scalars(select(ImportRow).where(
        ImportRow.tenant_id == ctx.tenant_id, ImportRow.file_id == file_id).order_by(ImportRow.line)))
    return Response(
        content="﻿" + op_import.report_csv(file, rows), media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="riepilogo-{file.id}.csv"'},
    )
