import uuid
from datetime import UTC, date, datetime
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select

from app import audit
from app.deps import Ctx, require
from app.idempotency import run_idempotent
from app.models import DestinationLot, Discharge
from app.schemas import DestinationLotOut
from app.schemas_discharge import (
    DestinationSummaryOut,
    DischargeIn,
    DischargeOut,
    ReasonIn,
)
from app.schemas_stock import StornoIn
from app.services import discharge as service
from domain.permissions import Permission

router = APIRouter(tags=["discharges"])
ROME = ZoneInfo("Europe/Rome")


@router.post("/discharges", response_model=DischargeOut, status_code=201)
def post_discharge(
    payload: DischargeIn, ctx: Ctx = Depends(require(Permission.MOVEMENTS_WRITE))
):
    """Scarico da un contenitore a un lotto di destinazione (o luogo), per data o periodo.

    Idempotente su `operation_id`."""
    return run_idempotent(
        ctx, payload.operation_id, "DISCHARGE",
        lambda op: service.create_discharge(ctx, payload, op),
    )


@router.get("/discharges", response_model=list[DischargeOut])
def list_discharges(
    destination_lot_id: uuid.UUID | None = None,
    container_id: uuid.UUID | None = None,
    location_id: uuid.UUID | None = None,
    status: str | None = None,
    date_from: date | None = Query(None, description="Periodo di competenza: da"),
    date_to: date | None = Query(None, description="Periodo di competenza: a"),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    ctx: Ctx = Depends(require(Permission.STOCK_READ)),
):
    stmt = select(Discharge).where(Discharge.tenant_id == ctx.tenant_id)
    if destination_lot_id:
        stmt = stmt.where(Discharge.destination_lot_id == destination_lot_id)
    if container_id:
        stmt = stmt.where(Discharge.container_id == container_id)
    if location_id:
        stmt = stmt.where(Discharge.location_id == location_id)
    if status:
        stmt = stmt.where(Discharge.status == status)
    if date_from:
        stmt = stmt.where(Discharge.period_to >= date_from)
    if date_to:
        stmt = stmt.where(Discharge.period_from <= date_to)
    rows = ctx.db.scalars(
        stmt.order_by(Discharge.period_to.desc(), Discharge.created_at.desc())
        .limit(limit).offset(offset)
    )
    return [service.discharge_out(ctx, d) for d in rows]


@router.get("/discharges/{discharge_id}", response_model=DischargeOut)
def get_discharge(discharge_id: uuid.UUID, ctx: Ctx = Depends(require(Permission.STOCK_READ))):
    discharge = ctx.db.scalar(
        select(Discharge).where(Discharge.id == discharge_id, Discharge.tenant_id == ctx.tenant_id)
    )
    if discharge is None:
        raise HTTPException(status_code=404, detail="Scarico non trovato")
    return service.discharge_out(ctx, discharge)


@router.post("/discharges/{discharge_id}/storno", response_model=DischargeOut, status_code=201)
def storno_discharge(
    discharge_id: uuid.UUID, payload: StornoIn,
    ctx: Ctx = Depends(require(Permission.INVENTORY_WRITE)),
):
    return run_idempotent(
        ctx, payload.operation_id, "STORNO_DISCHARGE",
        lambda op: service.storno_discharge(ctx, discharge_id, payload, op),
    )


# --- lotti di destinazione: chiusura, riapertura, riepilogo (RF-05) -----------------------
def _load_lot(ctx: Ctx, lot_id: uuid.UUID) -> DestinationLot:
    lot = ctx.db.scalar(
        select(DestinationLot).where(
            DestinationLot.id == lot_id, DestinationLot.tenant_id == ctx.tenant_id
        )
    )
    if lot is None:
        raise HTTPException(status_code=404, detail="Lotto di destinazione non trovato")
    return lot


@router.post("/destination-lots/{lot_id}/close", response_model=DestinationLotOut)
def close_destination_lot(
    lot_id: uuid.UUID, ctx: Ctx = Depends(require(Permission.MASTERDATA_WRITE))
):
    """Chiude il lotto: nessun nuovo scarico (salvo riapertura motivata)."""
    lot = _load_lot(ctx, lot_id)
    if lot.status == "CHIUSO":
        raise HTTPException(status_code=409, detail="Il lotto è già chiuso")
    before = audit.snapshot(DestinationLotOut, lot)
    lot.status = "CHIUSO"
    if lot.end_date is None:
        lot.end_date = datetime.now(UTC).astimezone(ROME).date()
    ctx.db.flush()
    ctx.db.refresh(lot)
    audit.record(ctx, "destination-lots", lot.id, "CLOSE", before, audit.snapshot(DestinationLotOut, lot))
    result = DestinationLotOut.model_validate(lot)
    ctx.db.commit()
    return result


@router.post("/destination-lots/{lot_id}/reopen", response_model=DestinationLotOut)
def reopen_destination_lot(
    lot_id: uuid.UUID, payload: ReasonIn,
    ctx: Ctx = Depends(require(Permission.MASTERDATA_WRITE)),
):
    lot = _load_lot(ctx, lot_id)
    if lot.status != "CHIUSO":
        raise HTTPException(status_code=409, detail="Il lotto non è chiuso")
    before = audit.snapshot(DestinationLotOut, lot)
    lot.status = "APERTO"
    ctx.db.flush()
    ctx.db.refresh(lot)
    after = audit.snapshot(DestinationLotOut, lot)
    audit.record(ctx, "destination-lots", lot.id, "REOPEN", before, {**after, "reason": payload.reason})
    result = DestinationLotOut.model_validate(lot)
    ctx.db.commit()
    return result


@router.get("/destination-lots/{lot_id}/summary", response_model=DestinationSummaryOut)
def destination_summary(lot_id: uuid.UUID, ctx: Ctx = Depends(require(Permission.STOCK_READ))):
    return service.destination_summary(ctx, _load_lot(ctx, lot_id))
