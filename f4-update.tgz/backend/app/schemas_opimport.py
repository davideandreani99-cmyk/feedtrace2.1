"""Schemi dell'import di operazioni da file (RF-06): mappature e file importati."""

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class ImportMappingConfig(BaseModel):
    """Come leggere un formato di file: colonne, date, decimali, codici esterni."""

    # campo canonico -> intestazione di colonna del file (maiuscole/minuscole indifferenti)
    columns: dict[str, str] = {}
    date_format: str | None = Field(None, max_length=40)  # strptime; vuoto = riconoscimento auto
    decimal_separator: Literal["auto", ",", "."] = "auto"
    default_unit: Literal["kg", "t", "l"] = "kg"
    defaults: dict[str, str] = {}  # valori fissi al posto di una colonna (es. sito, impianto)
    # corrispondenza codici esterni -> interni, per campo (es. {"location": {"V12": "Sala 3"}})
    code_maps: dict[str, dict[str, str]] = {}
    natural_key: list[str] = []  # campi che identificano la riga; vuoto = tutta la riga


class ImportMappingIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    entity: str
    config: ImportMappingConfig


class ImportMappingOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    entity: str
    config: ImportMappingConfig
    active: bool
    created_at: datetime


class ImportFileOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    entity: str
    filename: str
    sha256: str
    mapping_id: uuid.UUID | None
    status: str  # PREVIEW | APPLIED | DISCARDED
    total: int
    ok_count: int
    error_count: int
    duplicate_count: int
    applied_count: int
    failed_count: int
    created_at: datetime
    applied_at: datetime | None


class ImportRowOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    line: int
    status: str  # OK | ERROR | DUPLICATE | APPLIED | FAILED
    message: str | None
    natural_key: str
    payload: dict | None
    raw: dict
    operation_id: uuid.UUID | None
    result_ref: dict | None
