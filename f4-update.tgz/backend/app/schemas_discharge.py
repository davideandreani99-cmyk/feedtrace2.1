"""Schemi della Fase 4: scarichi e lotti di destinazione (RF-05)."""

import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, Field, model_validator

from app.schemas_stock import Qty, Reason, WarningOut


class DischargeIn(BaseModel):
    operation_id: uuid.UUID | None = None
    container_id: uuid.UUID
    # lotto di destinazione esplicito, oppure luogo (valvola/sala) risolto con le occupazioni
    destination_lot_id: uuid.UUID | None = None
    location_id: uuid.UUID | None = None
    period_from: date | None = None  # assente = scarico a data singola
    period_to: date
    quantity: Qty
    unit: Literal["kg", "t"] = "kg"
    notes: str | None = Field(None, max_length=500)

    @model_validator(mode="after")
    def una_sola_destinazione(self) -> "DischargeIn":
        if (self.destination_lot_id is None) == (self.location_id is None):
            raise ValueError("Indica il lotto di destinazione oppure il luogo (uno solo)")
        return self


class DischargeAllocationOut(BaseModel):
    lot_id: uuid.UUID
    lot_code: str
    quantity: Decimal
    kind: str  # CERTO | POSSIBILE


class DischargeOut(BaseModel):
    id: uuid.UUID
    container_id: uuid.UUID
    container_code: str
    destination_lot_id: uuid.UUID
    destination_code: str
    external_code: str | None
    location_id: uuid.UUID | None
    period_from: date
    period_to: date
    quantity: Decimal
    status: str
    source: str
    allocations: list[DischargeAllocationOut]
    warnings: list[WarningOut] = []
    notes: str | None = None
    reversal_reason: str | None = None


class ReasonIn(BaseModel):
    reason: Reason


class SummaryRecipeOut(BaseModel):
    recipe_code: str | None
    phase: str | None
    description: str
    kg: Decimal


class SummaryMonthOut(BaseModel):
    month: str  # AAAA-MM
    kg: Decimal


class SummaryLotOut(BaseModel):
    lot_id: uuid.UUID
    lot_code: str
    kind: str
    kg: Decimal


class DestinationSummaryOut(BaseModel):
    destination_lot_id: uuid.UUID
    code: str
    external_code: str | None
    status: str
    head_count: int | None
    discharges_count: int
    total_kg: Decimal
    by_recipe: list[SummaryRecipeOut]
    by_phase: list[dict]
    by_month: list[SummaryMonthOut]
    mix_lots: list[SummaryLotOut]
    material_lots: list[SummaryLotOut]
    # riempiti dalle fasi successive (costi F6, medicati F6)
    cost_eur: Decimal | None = None
    has_medicated: bool = False
    withdrawal_end: date | None = None
