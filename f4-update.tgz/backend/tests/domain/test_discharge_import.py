"""Regole di scarico e import (RF-05, RF-06): luogo→lotto, istante dello scarico, mappature, chiavi."""

import uuid
from datetime import UTC, date, datetime
from decimal import Decimal as D

import pytest

from domain.discharge import ensure_not_future, validate_period
from domain.importing import (
    ENTITIES,
    apply_code_map,
    file_sha256,
    natural_key,
    operation_id_for,
    parse_amount,
    parse_when,
    row_hash,
    validate_mapping,
)
from domain.occupancy import resolve_occupancy

# --- luogo -> lotto di destinazione tramite occupazione (SPEC §6.5) -------------------
OCC = [("L1", date(2026, 1, 1), date(2026, 1, 31)), ("L2", date(2026, 2, 1), None)]


def test_luogo_occupato_nel_periodo_risolve_il_lotto():
    assert resolve_occupancy(date(2026, 1, 10), date(2026, 1, 16), OCC) == ("L1", None)
    assert resolve_occupancy(date(2026, 2, 5), date(2026, 2, 5), OCC) == ("L2", None)
    assert resolve_occupancy(date(2026, 3, 1), date(2026, 3, 8), OCC) == ("L2", None)


def test_luogo_non_occupato_nel_periodo_errore():
    lot, error = resolve_occupancy(date(2025, 12, 1), date(2025, 12, 7), OCC)
    assert lot is None and "non è occupato" in error
    assert resolve_occupancy(date(2026, 1, 1), date(2026, 1, 5), [])[0] is None


def test_periodo_a_cavallo_di_due_occupazioni_errore():
    lot, error = resolve_occupancy(date(2026, 1, 28), date(2026, 2, 3), OCC)
    assert lot is None and "dividi" in error


def test_periodo_coperto_solo_in_parte_errore():
    lot, error = resolve_occupancy(date(2025, 12, 28), date(2026, 1, 3), OCC)
    assert lot is None and "dividi" in error


# --- periodo dello scarico ---------------------------------------------------------------------
def test_scarico_di_oggi_e_di_ieri_ammessi():
    now = datetime(2026, 3, 10, 10, 0, tzinfo=UTC)
    ensure_not_future(date(2026, 3, 10), now)
    ensure_not_future(date(2026, 3, 9), now)


def test_scarico_nel_futuro_non_valido():
    with pytest.raises(ValueError):
        ensure_not_future(date(2026, 3, 12), datetime(2026, 3, 10, 10, 0, tzinfo=UTC))


def test_giorno_italiano_a_cavallo_della_mezzanotte_utc():
    # 23:30 UTC del 10/03 sono già le 00:30 dell'11/03 in Italia
    now = datetime(2026, 3, 10, 23, 30, tzinfo=UTC)
    ensure_not_future(date(2026, 3, 11), now)

def test_periodo_valido():
    assert validate_period(None, date(2026, 3, 1)) == (date(2026, 3, 1), date(2026, 3, 1))
    assert validate_period(date(2026, 3, 1), date(2026, 3, 7)) == (date(2026, 3, 1), date(2026, 3, 7))
    with pytest.raises(ValueError):
        validate_period(date(2026, 3, 8), date(2026, 3, 1))


# --- mappature (SPEC §6.6) -----------------------------------------------------------------
def test_mappatura_scarichi_valida():
    cols = {"date": "Data", "container": "Silo", "quantity": "Kg", "location": "Valvola"}
    assert validate_mapping("discharges", cols, {}) == []


def test_mappatura_con_default_al_posto_della_colonna():
    cols = {"date": "Data", "quantity": "Kg", "destination_lot": "Lotto"}
    assert validate_mapping("discharges", cols, {}) == ["Campo obbligatorio non mappato: container"]
    assert validate_mapping("discharges", cols, {"container": "SILO-1"}) == []


def test_mappatura_campo_sconosciuto_ed_entita_sconosciuta():
    errors = validate_mapping("discharges", {"date": "D", "container": "C", "quantity": "Q",
                                            "location": "V", "colore": "X"}, {})
    assert any("colore" in e for e in errors)
    assert validate_mapping("animali", {}, {}) == ["Entità non importabile: animali"]
    assert set(ENTITIES) == {"receipts", "productions", "discharges", "inventories"}


def test_mappatura_alternative_data_o_data_fine():
    cols = {"date_to": "Al", "container": "C", "quantity": "Q", "destination_lot": "L"}
    assert validate_mapping("discharges", cols, {}) == []


# --- parsing di valori nei file ----------------------------------------------------------
def test_quantita_con_separatore_configurato():
    assert parse_amount("1.234,5", ",") == D("1234.5")
    assert parse_amount("1,234.5", ".") == D("1234.5")
    assert parse_amount("12,5", "auto") == D("12.5")
    assert parse_amount("  7 ", ",") == D("7")
    with pytest.raises(ValueError):
        parse_amount("abc", ",")


def test_data_con_formato_configurato_e_automatico():
    assert parse_when("10/03/2026", None) == datetime(2026, 3, 10)
    assert parse_when("2026-03-10", None) == datetime(2026, 3, 10)
    assert parse_when("10/03/2026 14:30", None) == datetime(2026, 3, 10, 14, 30)
    assert parse_when("10.03.26", "%d.%m.%y") == datetime(2026, 3, 10)
    with pytest.raises(ValueError):
        parse_when("31/02/2026", None)


def test_codici_esterni_tradotti_in_interni():
    cmap = {"Silo 3": "SILO-03"}
    assert apply_code_map("silo 3", cmap) == "SILO-03"
    assert apply_code_map("SILO-09", cmap) == "SILO-09"


# --- idempotenza: hash del file, chiave naturale, id operazione -------------------------------
def test_hash_file_stabile_e_sensibile_al_contenuto():
    assert file_sha256(b"abc") == file_sha256(b"abc") != file_sha256(b"abd")
    assert len(file_sha256(b"")) == 64


def test_chiave_naturale_normalizzata():
    assert natural_key([" 10/03/2026 ", "V12", "Silo 1"]) == "10/03/2026|v12|silo 1"
    assert natural_key(["a", "b"]) != natural_key(["b", "a"])


def test_hash_riga_indipendente_dall_ordine_delle_colonne():
    assert row_hash({"a": "1", "b": "2"}) == row_hash({"b": "2", "a": "1"})
    assert row_hash({"a": "1"}) != row_hash({"a": "2"})


def test_id_operazione_deterministico_per_tenant_entita_e_chiave():
    tenant, other = uuid.uuid4(), uuid.uuid4()
    first = operation_id_for(tenant, "discharges", "k1")
    assert first == operation_id_for(tenant, "discharges", "k1")
    assert first != operation_id_for(tenant, "discharges", "k2")
    assert first != operation_id_for(other, "discharges", "k1")
    assert first != operation_id_for(tenant, "receipts", "k1")
