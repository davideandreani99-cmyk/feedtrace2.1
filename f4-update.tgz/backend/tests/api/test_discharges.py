"""Fase 4 (RF-05): lotti di destinazione, occupazioni, scarichi, riepilogo."""

import uuid
from datetime import UTC, datetime, timedelta
from decimal import Decimal as D
from zoneinfo import ZoneInfo

import pytest

from tests.api.conftest import API, create_material, create_site
from tests.api.test_production import create_plant, create_recipe, links, produce
from tests.api.test_stock import (
    create_container,
    create_supplier,
    get_stock,
    post_op,
    post_receipt,
)


# --- helper ------------------------------------------------------------------------
def today():
    return datetime.now(ZoneInfo("Europe/Rome")).date()


def create_dest(client, acc, site, code=None, external=None, **extra):
    body = {"site_id": site["id"], "internal_code": code or f"LD-{uuid.uuid4().hex[:5]}",
            "external_code": external, "phase": "INGRASSO", **extra}
    r = client.post(f"{API}/destination-lots", json=body, headers=acc.headers)
    assert r.status_code == 201, r.text
    return r.json()


def discharge(client, acc, container, dest=None, kg="1000", period_to=None, **extra):
    body = {"container_id": container["id"], "quantity": str(kg),
            "period_to": (period_to or today()).isoformat(), "operation_id": str(uuid.uuid4()),
            **extra}
    if dest is not None:
        body["destination_lot_id"] = dest["id"]
    return client.post(f"{API}/discharges", json=body, headers=acc.headers)


@pytest.fixture
def farm(client, make_account):
    """Due lotti di mangime finito acquistato (A 10 t, B 5 t) in un silo, due lotti di destinazione."""
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    feed = create_material(client, acc, code="PRESTARTER", type="MANGIME_FINITO")
    silo = create_container(client, acc, site, code="SILO-PF", policy="FIFO")
    post_receipt(client, acc, site, silo, feed, "10", supplier, unit="t")
    post_receipt(client, acc, site, silo, feed, "5", supplier, unit="t")
    return {"acc": acc, "site": site, "supplier": supplier, "feed": feed, "silo": silo,
            "lot1": create_dest(client, acc, site, "LD-1", "PIG-001"),
            "lot2": create_dest(client, acc, site, "LD-2", "PIG-002")}


# --- scarico base e legami ----------------------------------------------------------
def test_scarico_consuma_secondo_la_politica_e_crea_i_legami(client, farm):
    acc = farm["acc"]
    r = discharge(client, acc, farm["silo"], farm["lot1"], "12000")
    assert r.status_code == 201, r.text
    out = r.json()
    assert out["destination_code"] == "LD-1" and out["external_code"] == "PIG-001"
    assert sorted((a["kind"], D(a["quantity"])) for a in out["allocations"]) == [
        ("CERTO", D("2000")), ("CERTO", D("10000"))]
    assert D(get_stock(client, acc, farm["silo"])["total"]) == D("3000")
    first_lot = max(out["allocations"], key=lambda a: D(a["quantity"]))["lot_id"]
    destinations = links(client, acc, first_lot)["destinations"]
    assert [(d["destination_code"], d["kind"], D(d["quantity"])) for d in destinations] == [
        ("LD-1", "CERTO", D("10000"))]


def test_scarico_da_tutti_presenti_produce_anche_legami_possibili(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    feed = create_material(client, acc, code="FEED", type="MANGIME_FINITO")
    silo = create_container(client, acc, site, policy="TUTTI_PRESENTI")
    post_receipt(client, acc, site, silo, feed, "10", supplier, unit="t")
    post_receipt(client, acc, site, silo, feed, "5", supplier, unit="t")
    dest = create_dest(client, acc, site)
    out = discharge(client, acc, silo, dest, "6000").json()
    kinds = [a["kind"] for a in out["allocations"]]
    assert kinds.count("CERTO") == 2 and kinds.count("POSSIBILE") == 2
    possible = sum(D(a["quantity"]) for a in out["allocations"] if a["kind"] == "POSSIBILE")
    assert possible == D("6000")


def test_scarico_periodico_registrabile_dopo_altri_movimenti(client, farm):
    acc = farm["acc"]
    week = today() - timedelta(days=7)
    r = discharge(client, acc, farm["silo"], farm["lot1"], "500",
                  period_from=week.isoformat(), period_to=(today() - timedelta(days=1)).isoformat())
    assert r.status_code == 201, r.text
    assert r.json()["period_from"] == week.isoformat()
    # periodo (e data singola) restano un dato dello scarico
    single = discharge(client, acc, farm["silo"], farm["lot1"], "100",
                       period_to=(today() - timedelta(days=3)).isoformat())
    assert single.json()["period_from"] == single.json()["period_to"]


def test_periodo_non_valido(client, farm):
    acc = farm["acc"]
    future = discharge(client, acc, farm["silo"], farm["lot1"], "100",
                       period_to=(today() + timedelta(days=2)).isoformat())
    assert future.status_code == 422
    inverted = discharge(client, acc, farm["silo"], farm["lot1"], "100",
                         period_from=today().isoformat(),
                         period_to=(today() - timedelta(days=2)).isoformat())
    assert inverted.status_code == 422


def test_destinazione_obbligatoria_e_unica(client, farm):
    acc = farm["acc"]
    neither = discharge(client, acc, farm["silo"], None, "100")
    both = discharge(client, acc, farm["silo"], farm["lot1"], "100", location_id=str(uuid.uuid4()))
    assert neither.status_code == 422 and both.status_code == 422


def test_scarico_idempotente(client, farm):
    acc = farm["acc"]
    op = str(uuid.uuid4())
    first = discharge(client, acc, farm["silo"], farm["lot1"], "1000", operation_id=op)
    second = discharge(client, acc, farm["silo"], farm["lot1"], "1000", operation_id=op)
    assert first.status_code == 201 and second.status_code == 200
    assert second.json() == first.json()
    assert D(get_stock(client, acc, farm["silo"])["total"]) == D("14000")


def test_giacenza_insufficiente_avviso_non_blocco(client, farm):
    acc = farm["acc"]
    r = discharge(client, acc, farm["silo"], farm["lot1"], "20000")
    assert r.status_code == 201
    assert "NEGATIVE_STOCK" in [w["code"] for w in r.json()["warnings"]]
    assert D(get_stock(client, acc, farm["silo"])["total"]) == D("-5000")


def test_avviso_periodo_fuori_dalle_date_del_lotto(client, farm):
    acc, site = farm["acc"], farm["site"]
    lot = create_dest(client, acc, site, "LD-OLD", end_date=(today() - timedelta(days=30)).isoformat())
    r = discharge(client, acc, farm["silo"], lot, "100")
    assert r.status_code == 201
    assert "PERIOD_OUTSIDE_LOT" in [w["code"] for w in r.json()["warnings"]]


def test_contenitore_e_lotto_di_siti_diversi_rifiutato(client, farm):
    acc = farm["acc"]
    other_site = create_site(client, acc)
    far_lot = create_dest(client, acc, other_site)
    assert discharge(client, acc, farm["silo"], far_lot, "100").status_code == 422


# --- lotto chiuso, riapertura motivata ------------------------------------------------
def test_lotto_chiuso_nessuno_scarico_salvo_riapertura_con_motivazione(client, farm):
    acc, lot = farm["acc"], farm["lot1"]
    closed = client.post(f"{API}/destination-lots/{lot['id']}/close", headers=acc.headers)
    assert closed.status_code == 200 and closed.json()["status"] == "CHIUSO"
    assert closed.json()["end_date"] == today().isoformat()
    blocked = discharge(client, acc, farm["silo"], lot, "100")
    assert blocked.status_code == 409 and "chiuso" in blocked.json()["detail"]
    no_reason = client.post(f"{API}/destination-lots/{lot['id']}/reopen", json={"reason": ""},
                            headers=acc.headers)
    assert no_reason.status_code == 422
    reopened = client.post(f"{API}/destination-lots/{lot['id']}/reopen",
                           json={"reason": "Capi rientrati in stalla"}, headers=acc.headers)
    assert reopened.status_code == 200 and reopened.json()["status"] == "APERTO"
    assert discharge(client, acc, farm["silo"], lot, "100").status_code == 201
    actions = [a["action"] for a in client.get(
        f"{API}/audit-log", params={"entity": "destination-lots", "entity_id": lot["id"]},
        headers=acc.headers).json()]
    assert "CLOSE" in actions and "REOPEN" in actions


def test_lo_stato_del_lotto_non_si_cambia_con_patch(client, farm):
    acc, lot = farm["acc"], farm["lot1"]
    r = client.patch(f"{API}/destination-lots/{lot['id']}", json={"status": "CHIUSO", "head_count": 40},
                     headers=acc.headers)
    assert r.status_code == 200 and r.json()["status"] == "APERTO" and r.json()["head_count"] == 40


# --- luogo -> lotto tramite occupazione (SPEC §6.5) -----------------------------------
def make_location(client, acc, site, name="Sala 1"):
    r = client.post(f"{API}/locations", json={"site_id": site["id"], "name": name}, headers=acc.headers)
    assert r.status_code == 201, r.text
    return r.json()


def occupy(client, acc, location, lot, date_from, date_to=None):
    body = {"location_id": location["id"], "destination_lot_id": lot["id"],
            "date_from": date_from.isoformat(), "date_to": date_to.isoformat() if date_to else None}
    r = client.post(f"{API}/occupancies", json=body, headers=acc.headers)
    assert r.status_code == 201, r.text


def test_scarico_per_luogo_risolve_il_lotto_con_l_occupazione(client, farm):
    acc, site = farm["acc"], farm["site"]
    sala = make_location(client, acc, site)
    occupy(client, acc, sala, farm["lot1"], today() - timedelta(days=30), today() - timedelta(days=10))
    occupy(client, acc, sala, farm["lot2"], today() - timedelta(days=9))
    r = discharge(client, acc, farm["silo"], None, "300", location_id=sala["id"])
    assert r.status_code == 201, r.text
    assert r.json()["destination_code"] == "LD-2" and r.json()["location_id"] == sala["id"]
    old = discharge(client, acc, farm["silo"], None, "200", location_id=sala["id"],
                    period_to=(today() - timedelta(days=15)).isoformat())
    assert old.json()["destination_code"] == "LD-1"


def test_luogo_non_occupato_o_periodo_a_cavallo_riga_in_errore(client, farm):
    acc, site = farm["acc"], farm["site"]
    sala = make_location(client, acc, site)
    occupy(client, acc, sala, farm["lot1"], today() - timedelta(days=30), today() - timedelta(days=10))
    occupy(client, acc, sala, farm["lot2"], today() - timedelta(days=9))
    empty = make_location(client, acc, site, "Sala vuota")
    free = discharge(client, acc, farm["silo"], None, "100", location_id=empty["id"])
    assert free.status_code == 422 and "non è occupato" in free.json()["detail"]
    straddle = discharge(client, acc, farm["silo"], None, "100", location_id=sala["id"],
                         period_from=(today() - timedelta(days=12)).isoformat(),
                         period_to=(today() - timedelta(days=8)).isoformat())
    assert straddle.status_code == 422 and "dividi" in straddle.json()["detail"]


# --- storno ---------------------------------------------------------------------------
def test_storno_scarico_ripristina_giacenza_e_compensa_i_legami(client, farm, make_account):
    acc = farm["acc"]
    out = discharge(client, acc, farm["silo"], farm["lot1"], "12000").json()
    operatore = make_account("OPERATORE", acc.tenant_id)
    assert post_op(client, operatore, f"/discharges/{out['id']}/storno", {"reason": "errore"}).status_code == 403
    r = post_op(client, acc, f"/discharges/{out['id']}/storno", {"reason": "Quantità sbagliata"})
    assert r.status_code == 201, r.text
    assert r.json()["status"] == "STORNATO"
    assert D(get_stock(client, acc, farm["silo"])["total"]) == D("15000")
    lot_id = out["allocations"][0]["lot_id"]
    assert links(client, acc, lot_id)["destinations"] == []
    summary = client.get(f"{API}/destination-lots/{farm['lot1']['id']}/summary", headers=acc.headers).json()
    assert D(summary["total_kg"]) == D("0") and summary["discharges_count"] == 0
    assert post_op(client, acc, f"/discharges/{out['id']}/storno", {"reason": "di nuovo"}).status_code == 409


# --- scarico contestuale da produzione (carro / broda) --------------------------------------
def broda_setup(client, acc):
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    mais = create_material(client, acc, code="MAIS")
    silo = create_container(client, acc, site)
    post_receipt(client, acc, site, silo, mais, "30", supplier, unit="t")
    plant = create_plant(client, acc, site, ptype="BRODA", rule="GIORNALIERO_PER_RICETTA", code="BRO")
    recipe = create_recipe(client, acc, "R1", [(mais, 1000, silo)], ptype="BRODA")
    return site, mais, silo, plant, recipe


def test_scarico_contestuale_della_produzione_su_due_lotti(client, make_account):
    acc = make_account("ADMIN")
    site, mais, silo, plant, recipe = broda_setup(client, acc)
    l1, l2 = create_dest(client, acc, site, "LD-1"), create_dest(client, acc, site, "LD-2")
    out = produce(client, acc, plant, recipe, 2, direct_discharges=[
        {"destination_lot_id": l1["id"], "quantity": "1200"},
        {"destination_lot_id": l2["id"], "quantity": "0.8", "unit": "t"}])
    assert out.status_code == 201, out.text
    body = out.json()
    assert {d["destination_code"]: D(d["quantity"]) for d in body["discharges"]} == {
        "LD-1": D("1200"), "LD-2": D("800")}
    virtual = client.get(f"{API}/containers/{body['destination_container_id']}/stock",
                         headers=acc.headers).json()
    assert D(virtual["total"]) == D("0")  # tutta la miscela è stata scaricata
    summary = client.get(f"{API}/destination-lots/{l1['id']}/summary", headers=acc.headers).json()
    assert D(summary["total_kg"]) == D("1200")
    assert summary["by_recipe"][0]["recipe_code"] == "R1" and D(summary["by_recipe"][0]["kg"]) == D("1200")
    assert [m["lot_code"] for m in summary["mix_lots"]] == [body["mix_lot_code"]]
    assert [m["kg"] for m in summary["material_lots"]] and summary["material_lots"][0]["kind"] == "MATERIA_PRIMA"


def test_scarichi_contestuali_solo_senza_contenitore_di_destinazione(client, make_account):
    acc = make_account("ADMIN")
    site, mais, silo, plant, recipe = broda_setup(client, acc)
    lot = create_dest(client, acc, site)
    tank = create_container(client, acc, site, code="VASCA")
    r = produce(client, acc, plant, recipe, 1, destination_container_id=tank["id"],
                direct_discharges=[{"destination_lot_id": lot["id"], "quantity": "500"}])
    assert r.status_code == 422


def test_storno_della_produzione_storna_anche_gli_scarichi_contestuali(client, make_account):
    acc = make_account("ADMIN")
    site, mais, silo, plant, recipe = broda_setup(client, acc)
    lot = create_dest(client, acc, site)
    out = produce(client, acc, plant, recipe, 2, direct_discharges=[
        {"destination_lot_id": lot["id"], "quantity": "2000"}]).json()
    r = post_op(client, acc, f"/productions/{out['id']}/storno", {"reason": "Ciclo registrato per errore"})
    assert r.status_code == 201, r.text
    assert [d["status"] for d in r.json()["discharges"]] == ["STORNATO"]
    assert D(get_stock(client, acc, silo)["total"]) == D("30000")
    summary = client.get(f"{API}/destination-lots/{lot['id']}/summary", headers=acc.headers).json()
    assert D(summary["total_kg"]) == D("0") and summary["mix_lots"] == []


# --- riepilogo del lotto di destinazione ----------------------------------------------------
def test_riepilogo_per_ricetta_fase_e_mese(client, make_account):
    acc = make_account("ADMIN")
    site, mais, silo, plant, recipe = broda_setup(client, acc)
    lot = create_dest(client, acc, site, "LD-1", "PIG-9", head_count=100)
    supplier = create_supplier(client, acc)
    feed = create_material(client, acc, code="PRE", type="MANGIME_FINITO")
    silo_pf = create_container(client, acc, site, code="SILO-PF")
    post_receipt(client, acc, site, silo_pf, feed, "2", supplier, unit="t")
    produce(client, acc, plant, recipe, 2, direct_discharges=[{"destination_lot_id": lot["id"], "quantity": "1500"}])
    discharge(client, acc, silo_pf, lot, "400")
    summary = client.get(f"{API}/destination-lots/{lot['id']}/summary", headers=acc.headers).json()
    assert D(summary["total_kg"]) == D("1900") and summary["discharges_count"] == 2
    assert summary["external_code"] == "PIG-9" and summary["head_count"] == 100
    by_recipe = {r["description"]: D(r["kg"]) for r in summary["by_recipe"]}
    assert by_recipe == {"R1 v1": D("1500"), "PRE (mangime acquistato)": D("400")}
    phases = {p["phase"]: D(p["kg"]) for p in summary["by_phase"]}
    assert phases == {"INGRASSO": D("1500"), "ACQUISTATO": D("400")}
    assert [(m["month"], D(m["kg"])) for m in summary["by_month"]] == [
        (today().strftime("%Y-%m"), D("1900"))]
    assert summary["cost_eur"] is None and summary["has_medicated"] is False


# --- elenco, permessi, isolamento -----------------------------------------------------------
def test_elenco_scarichi_con_filtri(client, farm):
    acc = farm["acc"]
    discharge(client, acc, farm["silo"], farm["lot1"], "100", period_to=(today() - timedelta(days=20)).isoformat())
    discharge(client, acc, farm["silo"], farm["lot2"], "200")
    everything = client.get(f"{API}/discharges", headers=acc.headers).json()
    assert len(everything) == 2
    by_lot = client.get(f"{API}/discharges", params={"destination_lot_id": farm["lot2"]["id"]},
                        headers=acc.headers).json()
    assert [D(d["quantity"]) for d in by_lot] == [D("200")]
    recent = client.get(f"{API}/discharges", params={"date_from": (today() - timedelta(days=5)).isoformat()},
                        headers=acc.headers).json()
    assert len(recent) == 1


def test_permessi_e_isolamento_tra_aziende(client, farm, make_account):
    acc = farm["acc"]
    auditor = make_account("AUDITOR", acc.tenant_id)
    assert discharge(client, auditor, farm["silo"], farm["lot1"], "10").status_code == 403
    operatore = make_account("OPERATORE", acc.tenant_id)
    out = discharge(client, operatore, farm["silo"], farm["lot1"], "10")
    assert out.status_code == 201
    intruder = make_account("ADMIN")
    assert client.get(f"{API}/discharges/{out.json()['id']}", headers=intruder.headers).status_code == 404
    assert client.get(f"{API}/discharges", headers=intruder.headers).json() == []
    assert discharge(client, intruder, farm["silo"], farm["lot1"], "10").status_code == 422
    assert client.get(f"{API}/destination-lots/{farm['lot1']['id']}/summary",
                      headers=intruder.headers).status_code == 404
    assert client.post(f"{API}/destination-lots/{farm['lot1']['id']}/close",
                       headers=intruder.headers).status_code == 404
    assert client.get(f"{API}/discharges", headers=auditor.headers).status_code == 200
