"""Fase 4 (RF-06): import di ingressi, produzioni, scarichi, inventari con mappature."""

import io
import json
import uuid
from datetime import datetime, timedelta
from decimal import Decimal as D
from zoneinfo import ZoneInfo

import pytest
from openpyxl import Workbook

from tests.api.conftest import API, create_material, create_site
from tests.api.test_discharges import create_dest, make_location, occupy
from tests.api.test_production import create_plant, create_recipe
from tests.api.test_stock import create_container, create_supplier, get_stock, post_receipt

ROME = ZoneInfo("Europe/Rome")


def day(offset=0):
    return (datetime.now(ROME).date() + timedelta(days=offset)).strftime("%d/%m/%Y")


DISCHARGE_MAPPING = {
    "columns": {"date": "Data", "container": "Silo", "location": "Valvola", "quantity": "Kg"},
    "code_maps": {"location": {"V12": "Sala 3"}},
}


def csv_bytes(*lines):
    return ("\n".join(lines) + "\n").encode()


def upload(client, acc, entity, content, mapping=None, filename="export.csv", mapping_id=None):
    data = {"entity": entity}
    if mapping_id:
        data["mapping_id"] = mapping_id
    else:
        data["mapping_json"] = json.dumps(mapping)
    return client.post(f"{API}/op-imports", data=data,
                       files={"file": (filename, content, "application/octet-stream")},
                       headers=acc.headers)


def confirm(client, acc, file_id, strict=False):
    return client.post(f"{API}/op-imports/{file_id}/confirm", params={"strict": strict},
                       headers=acc.headers)


def rows_of(client, acc, file_id, status=None):
    params = {"status": status} if status else None
    r = client.get(f"{API}/op-imports/{file_id}/rows", params=params, headers=acc.headers)
    assert r.status_code == 200, r.text
    return r.json()


@pytest.fixture
def plant_farm(client, make_account):
    """Silo di mangime finito, lotti di destinazione con codice Pig'UP, valvola occupata."""
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    feed = create_material(client, acc, code="PRESTARTER", type="MANGIME_FINITO")
    silo = create_container(client, acc, site, code="SILO-A")
    post_receipt(client, acc, site, silo, feed, "20", supplier, unit="t")
    lot = create_dest(client, acc, site, "LD-1", "PIG-001")
    sala = make_location(client, acc, site, "Sala 3")
    occupy(client, acc, sala, lot, datetime.now(ROME).date() - timedelta(days=30))
    return {"acc": acc, "site": site, "supplier": supplier, "feed": feed, "silo": silo,
            "lot": lot, "sala": sala}


# --- mappature ----------------------------------------------------------------------------
def test_mappatura_salvabile_e_validata(client, plant_farm):
    acc = plant_farm["acc"]
    bad = client.post(f"{API}/import-mappings", headers=acc.headers, json={
        "name": "Incompleta", "entity": "discharges", "config": {"columns": {"date": "Data"}}})
    assert bad.status_code == 422 and "obbligatorio" in bad.json()["detail"]
    ok = client.post(f"{API}/import-mappings", headers=acc.headers, json={
        "name": "Export broda impianto X", "entity": "discharges", "config": DISCHARGE_MAPPING})
    assert ok.status_code == 201, ok.text
    again = client.post(f"{API}/import-mappings", headers=acc.headers, json={
        "name": "Export broda impianto X", "entity": "discharges", "config": DISCHARGE_MAPPING})
    assert again.status_code == 409
    listed = client.get(f"{API}/import-mappings", params={"entity": "discharges"}, headers=acc.headers).json()
    assert [m["name"] for m in listed] == ["Export broda impianto X"]
    assert listed[0]["config"]["code_maps"]["location"]["V12"] == "Sala 3"


def test_mappatura_salvata_usata_per_l_import(client, plant_farm):
    acc = plant_farm["acc"]
    mapping = client.post(f"{API}/import-mappings", headers=acc.headers, json={
        "name": "Export V1", "entity": "discharges", "config": DISCHARGE_MAPPING}).json()
    content = csv_bytes("Data;Silo;Valvola;Kg", f"{day()};SILO-A;V12;500")
    r = upload(client, acc, "discharges", content, mapping_id=mapping["id"])
    assert r.status_code == 201, r.text
    assert r.json()["ok_count"] == 1 and r.json()["mapping_id"] == mapping["id"]


# --- scarichi: anteprima, conferma, riepilogo ---------------------------------------------------
def test_import_scarichi_anteprima_conferma_e_report(client, plant_farm):
    acc, silo = plant_farm["acc"], plant_farm["silo"]
    content = csv_bytes(
        "Data;Silo;Valvola;Kg",
        f"{day()};SILO-A;V12;1000",
        f"{day()};SILO-A;V99;500",
        f"{day(-1)};SILO-A;V12;250,5",
    )
    preview = upload(client, acc, "discharges", content, DISCHARGE_MAPPING)
    assert preview.status_code == 201, preview.text
    info = preview.json()
    assert (info["total"], info["ok_count"], info["error_count"], info["status"]) == (3, 2, 1, "PREVIEW")
    errors = rows_of(client, acc, info["id"], "ERROR")
    assert len(errors) == 1 and errors[0]["line"] == 3 and "V99" in errors[0]["message"]
    assert D(get_stock(client, acc, silo)["total"]) == D("20000")  # l'anteprima non registra nulla

    done = confirm(client, acc, info["id"])
    assert done.status_code == 200, done.text
    assert (done.json()["status"], done.json()["applied_count"], done.json()["failed_count"]) == ("APPLIED", 2, 0)
    assert D(get_stock(client, acc, silo)["total"]) == D("20000") - D("1000") - D("250.5")
    discharges = client.get(f"{API}/discharges", headers=acc.headers).json()
    assert len(discharges) == 2 and {d["source"] for d in discharges} == {"IMPORT"}
    assert {d["destination_code"] for d in discharges} == {"LD-1"}

    applied = rows_of(client, acc, info["id"], "APPLIED")
    assert len(applied) == 2 and all(r["result_ref"]["discharge_id"] for r in applied)
    report = client.get(f"{API}/op-imports/{info['id']}/report", headers=acc.headers)
    assert report.status_code == 200 and "ERROR" in report.text and "APPLIED" in report.text
    original = client.get(f"{API}/op-imports/{info['id']}/download", headers=acc.headers)
    assert original.content == content  # il file d'origine resta consultabile


def test_stesso_file_importato_due_volte_nessun_duplicato(client, plant_farm):
    acc, silo = plant_farm["acc"], plant_farm["silo"]
    content = csv_bytes("Data;Silo;Valvola;Kg", f"{day()};SILO-A;V12;1000")
    first = upload(client, acc, "discharges", content, DISCHARGE_MAPPING).json()
    assert confirm(client, acc, first["id"]).status_code == 200
    again = upload(client, acc, "discharges", content, DISCHARGE_MAPPING)
    assert again.status_code == 409 and "già stato importato" in again.json()["detail"]
    assert D(get_stock(client, acc, silo)["total"]) == D("19000")
    assert len(client.get(f"{API}/discharges", headers=acc.headers).json()) == 1
    # confermare due volte la stessa anteprima non è possibile
    assert confirm(client, acc, first["id"]).status_code == 409


def test_riga_gia_importata_in_un_altro_file_e_duplicato(client, plant_farm):
    acc, silo = plant_farm["acc"], plant_farm["silo"]
    row = f"{day()};SILO-A;V12;1000"
    one = upload(client, acc, "discharges", csv_bytes("Data;Silo;Valvola;Kg", row), DISCHARGE_MAPPING).json()
    confirm(client, acc, one["id"])
    two = upload(client, acc, "discharges",
                 csv_bytes("Data;Silo;Valvola;Kg", row, f"{day()};SILO-A;V12;300"), DISCHARGE_MAPPING)
    info = two.json()
    assert (info["ok_count"], info["duplicate_count"]) == (1, 1)
    assert "già importata" in rows_of(client, acc, info["id"], "DUPLICATE")[0]["message"]
    done = confirm(client, acc, info["id"]).json()
    assert done["applied_count"] == 1
    assert D(get_stock(client, acc, silo)["total"]) == D("18700")


def test_riga_ripetuta_nello_stesso_file_e_duplicato(client, plant_farm):
    acc = plant_farm["acc"]
    row = f"{day()};SILO-A;V12;1000"
    r = upload(client, acc, "discharges", csv_bytes("Data;Silo;Valvola;Kg", row, row), DISCHARGE_MAPPING)
    assert (r.json()["ok_count"], r.json()["duplicate_count"]) == (1, 1)


def test_chiave_naturale_configurabile_distingue_righe_simili(client, plant_farm):
    acc = plant_farm["acc"]
    mapping = {**DISCHARGE_MAPPING,
               "columns": {**DISCHARGE_MAPPING["columns"], "notes": "Ciclo"},
               "natural_key": ["date", "location", "notes"]}
    content = csv_bytes("Data;Silo;Valvola;Kg;Ciclo",
                        f"{day()};SILO-A;V12;1000;1", f"{day()};SILO-A;V12;1000;2",
                        f"{day()};SILO-A;V12;999;1")
    r = upload(client, acc, "discharges", content, mapping).json()
    # la terza riga ha la stessa chiave (data, valvola, ciclo 1) della prima
    assert (r["ok_count"], r["duplicate_count"]) == (2, 1)


def test_formato_data_e_separatore_decimale_configurati(client, plant_farm):
    acc, silo = plant_farm["acc"], plant_farm["silo"]
    d = datetime.now(ROME).date()
    mapping = {**DISCHARGE_MAPPING, "date_format": "%d.%m.%y", "decimal_separator": ","}
    content = csv_bytes("Data;Silo;Valvola;Kg", f"{d:%d.%m.%y};SILO-A;V12;1.250,5")
    r = upload(client, acc, "discharges", content, mapping).json()
    assert r["ok_count"] == 1
    confirm(client, acc, r["id"])
    assert D(get_stock(client, acc, silo)["total"]) == D("20000") - D("1250.5")


def test_codici_esterni_pig_up_e_unita_di_default(client, plant_farm):
    acc, silo = plant_farm["acc"], plant_farm["silo"]
    mapping = {"columns": {"date": "Giorno", "container": "Silo", "destination_lot": "Lotto Pig'UP",
                           "quantity": "Quantità"}, "default_unit": "t"}
    content = csv_bytes("Giorno;Silo;Lotto Pig'UP;Quantità", f"{day()};SILO-A;PIG-001;1,5")
    r = upload(client, acc, "discharges", content, mapping).json()
    assert r["ok_count"] == 1, rows_of(client, acc, r["id"])
    confirm(client, acc, r["id"])
    assert D(get_stock(client, acc, silo)["total"]) == D("18500")


def test_import_xlsx(client, plant_farm):
    acc = plant_farm["acc"]
    wb = Workbook()
    ws = wb.active
    ws.append(["Data", "Silo", "Valvola", "Kg"])
    ws.append([datetime.now(ROME).date(), "SILO-A", "V12", 700])
    buffer = io.BytesIO()
    wb.save(buffer)
    r = upload(client, acc, "discharges", buffer.getvalue(), DISCHARGE_MAPPING, "scarichi.xlsx")
    assert r.status_code == 201 and r.json()["ok_count"] == 1, r.text
    assert confirm(client, acc, r.json()["id"]).json()["applied_count"] == 1


def test_confermare_applica_le_righe_valide_e_segnala_quelle_fallite(client, plant_farm):
    acc, lot = plant_farm["acc"], plant_farm["lot"]
    closed = create_dest(client, acc, plant_farm["site"], "LD-CHIUSO", "PIG-CLOSED")
    mapping = {"columns": {"date": "Data", "container": "Silo", "destination_lot": "Lotto",
                           "quantity": "Kg"}}
    content = csv_bytes("Data;Silo;Lotto;Kg", f"{day()};SILO-A;PIG-001;100", f"{day()};SILO-A;PIG-CLOSED;200")
    r = upload(client, acc, "discharges", content, mapping).json()
    assert r["ok_count"] == 2
    client.post(f"{API}/destination-lots/{closed['id']}/close", headers=acc.headers)  # dopo l'anteprima
    done = confirm(client, acc, r["id"]).json()
    assert (done["applied_count"], done["failed_count"]) == (1, 1)
    failed = rows_of(client, acc, r["id"], "FAILED")
    assert len(failed) == 1 and "chiuso" in failed[0]["message"]
    assert len(client.get(f"{API}/discharges", headers=acc.headers).json()) == 1
    assert lot["internal_code"] == "LD-1"


def test_modalita_rigorosa_tutto_o_niente(client, plant_farm):
    acc, silo = plant_farm["acc"], plant_farm["silo"]
    closed = create_dest(client, acc, plant_farm["site"], "LD-CHIUSO", "PIG-CLOSED")
    mapping = {"columns": {"date": "Data", "container": "Silo", "destination_lot": "Lotto", "quantity": "Kg"}}
    content = csv_bytes("Data;Silo;Lotto;Kg", f"{day()};SILO-A;PIG-001;100", f"{day()};SILO-A;PIG-CLOSED;200")
    r = upload(client, acc, "discharges", content, mapping).json()
    client.post(f"{API}/destination-lots/{closed['id']}/close", headers=acc.headers)
    strict = confirm(client, acc, r["id"], strict=True)
    assert strict.status_code == 409 and "annullato" in strict.json()["detail"]
    assert D(get_stock(client, acc, silo)["total"]) == D("20000")  # nulla è stato registrato
    assert client.get(f"{API}/op-imports/{r['id']}", headers=acc.headers).json()["status"] == "PREVIEW"
    # con righe in errore già in anteprima la modalità rigorosa rifiuta subito
    bad = upload(client, acc, "discharges", csv_bytes("Data;Silo;Lotto;Kg", f"{day()};SILO-A;XXX;5"), mapping).json()
    assert confirm(client, acc, bad["id"], strict=True).status_code == 409


def test_anteprima_scartabile(client, plant_farm):
    acc = plant_farm["acc"]
    r = upload(client, acc, "discharges", csv_bytes("Data;Silo;Valvola;Kg", f"{day()};SILO-A;V12;5"),
               DISCHARGE_MAPPING).json()
    gone = client.delete(f"{API}/op-imports/{r['id']}", headers=acc.headers)
    assert gone.status_code == 200 and gone.json()["status"] == "DISCARDED"
    assert confirm(client, acc, r["id"]).status_code == 409


# --- ingressi -------------------------------------------------------------------------------
def test_import_ingressi(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    create_supplier(client, acc)
    silo = create_container(client, acc, site, code="SILO-M")
    create_material(client, acc, code="MAIS")
    supplier = client.get(f"{API}/suppliers", headers=acc.headers).json()[0]
    mapping = {"columns": {"date": "Data DDT", "ddt_number": "DDT", "supplier": "Fornitore",
                           "material": "Merce", "quantity": "Quantità", "container": "Silo",
                           "supplier_lot": "Lotto forn."}, "default_unit": "t",
               "natural_key": ["ddt_number", "material"]}
    content = csv_bytes(
        "Data DDT;DDT;Fornitore;Merce;Quantità;Silo;Lotto forn.",
        f"{day()};D-100;{supplier['name']};MAIS;12,5;SILO-M;LF-1",
        f"{day()};D-101;{supplier['name']};GRANO;3;SILO-M;LF-2",
    )
    r = upload(client, acc, "receipts", content, mapping).json()
    assert (r["ok_count"], r["error_count"]) == (1, 1)
    assert "GRANO" in rows_of(client, acc, r["id"], "ERROR")[0]["message"]
    assert confirm(client, acc, r["id"]).json()["applied_count"] == 1
    assert D(get_stock(client, acc, silo)["total"]) == D("12500")
    lots = client.get(f"{API}/lots", headers=acc.headers).json()
    assert lots[0]["supplier_lot"] == "LF-1" and lots[0]["ddt_number"] == "D-100"
    receipts = client.get(f"{API}/receipts", headers=acc.headers).json()
    assert receipts[0]["ddt_number"] == "D-100"


def test_ingresso_senza_fornitore_ne_autoprodotta_in_errore(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    create_container(client, acc, site, code="SILO-M")
    create_material(client, acc, code="MAIS")
    mapping = {"columns": {"date": "Data", "material": "Merce", "quantity": "Kg", "container": "Silo"}}
    r = upload(client, acc, "receipts", csv_bytes("Data;Merce;Kg;Silo", f"{day()};MAIS;100;SILO-M"), mapping)
    assert r.json()["error_count"] == 1
    mapping["defaults"] = {"self_produced": "sì"}
    again = upload(client, acc, "receipts", csv_bytes("Data;Merce;Kg;Silo", f"{day()};MAIS;200;SILO-M"), mapping)
    assert again.json()["ok_count"] == 1


# --- produzioni -----------------------------------------------------------------------------
def test_import_produzioni_con_codici_ricetta_esterni(client, make_account):
    acc = make_account("ADMIN")
    site = create_site(client, acc)
    supplier = create_supplier(client, acc)
    mais = create_material(client, acc, code="MAIS")
    silo = create_container(client, acc, site, code="SILO-M")
    post_receipt(client, acc, site, silo, mais, "20", supplier, unit="t")
    create_plant(client, acc, site, ptype="BRODA", rule="GIORNALIERO_PER_RICETTA", code="BRO")
    create_recipe(client, acc, "R1", [(mais, 1000, silo)], ptype="BRODA")
    mapping = {"columns": {"datetime": "Data", "plant": "Impianto", "recipe": "Ricetta",
                           "quantity": "Kg", "notes": "Ciclo"},
               "code_maps": {"recipe": {"RICETTA 7": "R1"}},
               "natural_key": ["datetime", "recipe", "notes"]}
    content = csv_bytes(
        "Data;Impianto;Ricetta;Kg;Ciclo",
        f"{day()};BRO;Ricetta 7;2000;1",
        f"{day()};BRO;Ricetta 7;1000;2",
    )
    r = upload(client, acc, "productions", content, mapping).json()
    assert r["ok_count"] == 2, rows_of(client, acc, r["id"])
    done = confirm(client, acc, r["id"]).json()
    assert done["applied_count"] == 2 and done["failed_count"] == 0, rows_of(client, acc, r["id"])
    productions = client.get(f"{API}/productions", headers=acc.headers).json()
    assert len(productions) == 2
    assert len({p["mix_lot_id"] for p in productions}) == 1  # lotto giornaliero per ricetta
    assert D(get_stock(client, acc, silo)["total"]) == D("17000")

# --- inventari ------------------------------------------------------------------------------
def test_import_inventari_solo_con_permesso_di_inventario(client, plant_farm, make_account):
    acc, silo = plant_farm["acc"], plant_farm["silo"]
    mapping = {"columns": {"date": "Data", "container": "Silo", "measured_quantity": "Misurato"},
               "default_unit": "kg", "defaults": {"reason": "Inventario mensile"}}
    content = csv_bytes("Data;Silo;Misurato", f"{day()};SILO-A;19500")
    operatore = make_account("OPERATORE", acc.tenant_id)
    preview = upload(client, operatore, "inventories", content, mapping).json()
    assert preview["ok_count"] == 1
    assert confirm(client, operatore, preview["id"]).status_code == 403
    responsabile = make_account("RESPONSABILE", acc.tenant_id)
    done = confirm(client, responsabile, preview["id"])
    assert done.status_code == 200 and done.json()["applied_count"] == 1, done.text
    assert D(get_stock(client, acc, silo)["total"]) == D("19500")


# --- permessi e isolamento ------------------------------------------------------------------
def test_permessi_e_isolamento_tra_aziende(client, plant_farm, make_account):
    acc = plant_farm["acc"]
    content = csv_bytes("Data;Silo;Valvola;Kg", f"{day()};SILO-A;V12;100")
    auditor = make_account("AUDITOR", acc.tenant_id)
    assert upload(client, auditor, "discharges", content, DISCHARGE_MAPPING).status_code == 403
    operatore = make_account("OPERATORE", acc.tenant_id)
    r = upload(client, operatore, "discharges", content, DISCHARGE_MAPPING)
    assert r.status_code == 201
    assert confirm(client, operatore, r.json()["id"]).json()["applied_count"] == 1
    intruder = make_account("ADMIN")
    assert client.get(f"{API}/op-imports/{r.json()['id']}", headers=intruder.headers).status_code == 404
    assert client.get(f"{API}/op-imports", headers=intruder.headers).json() == []
    assert client.get(f"{API}/op-imports/{r.json()['id']}/download", headers=intruder.headers).status_code == 404
    mapping = client.post(f"{API}/import-mappings", headers=acc.headers, json={
        "name": "Mia", "entity": "discharges", "config": DISCHARGE_MAPPING}).json()
    assert client.get(f"{API}/import-mappings", headers=intruder.headers).json() == []
    bad = upload(client, intruder, "discharges", content, mapping_id=mapping["id"])
    assert bad.status_code == 404
    # contenitori e luoghi di un'altra azienda non sono risolvibili
    foreign = upload(client, intruder, "discharges", content, DISCHARGE_MAPPING).json()
    assert foreign["ok_count"] == 0 and foreign["error_count"] == 1


def test_entita_o_file_non_validi(client, plant_farm):
    acc = plant_farm["acc"]
    assert upload(client, acc, "animali", b"a\n1\n", DISCHARGE_MAPPING).status_code == 404
    assert upload(client, acc, "discharges", b"x", DISCHARGE_MAPPING, "dati.txt").status_code == 422
    assert upload(client, acc, "discharges", b"Data;Silo\n", DISCHARGE_MAPPING).status_code == 422
    no_mapping = client.post(f"{API}/op-imports", data={"entity": "discharges"},
                             files={"file": ("a.csv", b"a\n1\n", "text/csv")}, headers=acc.headers)
    assert no_mapping.status_code == 422
    broken = {"columns": {"date": "Data"}}
    assert upload(client, acc, "discharges", b"Data\n1\n", broken).status_code == 422
    assert str(uuid.uuid4())  # evita warning di import inutilizzato
