"""Fase 4: scarichi, legami verso lotti di destinazione, import di operazioni.

Idempotente rispetto alle colonne e ai vincoli (le migrazioni precedenti creano le tabelle dai
modelli correnti). NB: nessun carattere percento nelle istruzioni SQL.

Revision ID: 0004
Revises: 0003
"""

from alembic import op

from app.models import Base

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None

APP_ROLE = "feedtrace_app"
F4_TABLES = {"discharge", "import_mapping", "import_file", "import_row"}


def upgrade() -> None:
    bind = op.get_bind()

    def run(sql: str) -> None:
        bind.exec_driver_sql(sql)

    f4 = [t for t in Base.metadata.sorted_tables if t.name in F4_TABLES]
    Base.metadata.create_all(bind=bind, tables=f4)

    # trace_link: destinazione = lotto (miscela) OPPURE lotto di destinazione (scarico)
    run("ALTER TABLE trace_link ALTER COLUMN to_lot_id DROP NOT NULL")
    run("ALTER TABLE trace_link ADD COLUMN IF NOT EXISTS to_destination_lot_id uuid")
    run("ALTER TABLE trace_link ADD COLUMN IF NOT EXISTS discharge_id uuid")
    run("ALTER TABLE trace_link DROP CONSTRAINT IF EXISTS trace_link_dest_fk")
    run(
        "ALTER TABLE trace_link ADD CONSTRAINT trace_link_dest_fk "
        "FOREIGN KEY (to_destination_lot_id) REFERENCES destination_lot(id)"
    )
    run("ALTER TABLE trace_link DROP CONSTRAINT IF EXISTS trace_link_discharge_fk")
    run(
        "ALTER TABLE trace_link ADD CONSTRAINT trace_link_discharge_fk "
        "FOREIGN KEY (discharge_id) REFERENCES discharge(id)"
    )
    run("ALTER TABLE trace_link DROP CONSTRAINT IF EXISTS trace_link_target_check")
    run(
        "ALTER TABLE trace_link ADD CONSTRAINT trace_link_target_check "
        "CHECK ((to_lot_id IS NOT NULL) <> (to_destination_lot_id IS NOT NULL))"
    )
    run(
        "CREATE INDEX IF NOT EXISTS ix_trace_link_dest ON trace_link "
        "(tenant_id, to_destination_lot_id)"
    )

    for table in f4:
        run(f"ALTER TABLE {table.name} ENABLE ROW LEVEL SECURITY")
        run(f"ALTER TABLE {table.name} FORCE ROW LEVEL SECURITY")
        run(f"DROP POLICY IF EXISTS tenant_isolation ON {table.name}")
        run(
            f"CREATE POLICY tenant_isolation ON {table.name} "
            "USING (tenant_id = app_current_tenant()) "
            "WITH CHECK (tenant_id = app_current_tenant())"
        )
        run(f"GRANT SELECT, INSERT, UPDATE ON {table.name} TO {APP_ROLE}")


def downgrade() -> None:
    raise NotImplementedError("Downgrade non supportato")
