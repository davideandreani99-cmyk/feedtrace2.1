"""Import di operazioni da file (RF-06): mappature, parsing, chiavi di idempotenza."""

import hashlib
import json
import uuid
from datetime import datetime
from decimal import Decimal

from domain.parsing import parse_decimal_it

# campo canonico -> gruppi obbligatori: in ogni gruppo basta UNO dei campi (colonna o default)
REQUIRED_GROUPS: dict[str, list[list[str]]] = {
    "discharges": [["date", "date_to"], ["container"], ["quantity"],
                   ["destination_lot", "location"]],
    "receipts": [["date"], ["material"], ["quantity"], ["container"]],
    "productions": [["date", "datetime"], ["plant"], ["recipe"], ["quantity"]],
    "inventories": [["date"], ["container"], ["measured_quantity"]],
}
OPTIONAL_FIELDS: dict[str, list[str]] = {
    "discharges": ["date_from", "unit", "notes", "site"],
    "receipts": ["supplier", "ddt_number", "plate", "supplier_lot", "unit", "price_eur_t", "site",
                 "self_produced"],
    "productions": ["unit", "destination_container", "site", "notes"],
    "inventories": ["unit", "reason", "site"],
}
ENTITIES = list(REQUIRED_GROUPS)


def allowed_fields(entity: str) -> set[str]:
    required = {f for group in REQUIRED_GROUPS[entity] for f in group}
    return required | set(OPTIONAL_FIELDS[entity])


def validate_mapping(entity: str, columns: dict[str, str], defaults: dict[str, str]) -> list[str]:
    if entity not in REQUIRED_GROUPS:
        return [f"Entità non importabile: {entity}"]
    errors: list[str] = []
    allowed = allowed_fields(entity)
    for name in [*columns, *defaults]:
        if name not in allowed:
            errors.append(f"Campo sconosciuto per {entity}: {name}")
    for group in REQUIRED_GROUPS[entity]:
        if not any(f in columns or f in defaults for f in group):
            errors.append(f"Campo obbligatorio non mappato: {' oppure '.join(group)}")
    return errors


def parse_amount(text: str, decimal_separator: str) -> Decimal:
    """Numero con separatore decimale configurato (',' | '.' | 'auto')."""
    value = text.strip()
    if decimal_separator == ",":
        value = value.replace(".", "").replace(",", ".")
    elif decimal_separator == ".":
        value = value.replace(",", "")
    else:
        return parse_decimal_it(value)
    return parse_decimal_it(value)


_AUTO_FORMATS = ("%d/%m/%Y %H:%M", "%d/%m/%Y", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%d-%m-%Y")


def parse_when(text: str, date_format: str | None) -> datetime:
    value = text.strip()
    formats = (date_format,) if date_format else _AUTO_FORMATS
    for fmt in formats:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    raise ValueError(f"Data non valida: {text!r}")


def apply_code_map(value: str, code_map: dict[str, str]) -> str:
    """Codice esterno (es. 'Silo 3', valvola) → codice interno; senza voce resta invariato."""
    lowered = {k.strip().lower(): v for k, v in code_map.items()}
    return lowered.get(value.strip().lower(), value.strip())


def file_sha256(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def natural_key(values: list[str]) -> str:
    return "|".join(v.strip().lower() for v in values)


def row_hash(row: dict[str, str]) -> str:
    return hashlib.sha1(json.dumps(row, sort_keys=True).encode()).hexdigest()  # noqa: S324


def operation_id_for(tenant_id: uuid.UUID, entity: str, key: str) -> uuid.UUID:
    """Id operazione deterministico: la stessa riga rimportata riproduce la stessa operazione."""
    return uuid.uuid5(tenant_id, f"{entity}:{key}")
