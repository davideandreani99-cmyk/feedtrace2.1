"""Ruoli e permessi (SPEC §4). Politica unica usata da UI e API."""

from enum import StrEnum


class Role(StrEnum):
    ADMIN = "ADMIN"  # Amministratore azienda
    RESPONSABILE = "RESPONSABILE"  # Responsabile mangimificio
    OPERATORE = "OPERATORE"
    VETERINARIO = "VETERINARIO"  # Veterinario / consulente
    AUDITOR = "AUDITOR"  # Auditor / ente di controllo


class Permission(StrEnum):
    MASTERDATA_READ = "masterdata:read"
    MASTERDATA_WRITE = "masterdata:write"
    STOCK_READ = "stock:read"  # lotti, giacenze, movimenti
    MOVEMENTS_WRITE = "movements:write"  # ingressi, prelievi, travasi, uscite
    INVENTORY_WRITE = "inventory:write"  # inventari, svuotamenti, storni, date passate
    IMPORT_RUN = "import:run"  # import di anagrafiche (Responsabile e Amministratore)
    IMPORT_OPERATIONS = "import:operations"  # import di ingressi, produzioni, scarichi, inventari
    USERS_MANAGE = "users:manage"
    AUDIT_READ = "audit:read"


_ALL = frozenset(Permission)

_ROLE_PERMISSIONS: dict[Role, frozenset[Permission]] = {
    Role.ADMIN: _ALL,
    Role.RESPONSABILE: frozenset(
        {
            Permission.MASTERDATA_READ,
            Permission.MASTERDATA_WRITE,
            Permission.STOCK_READ,
            Permission.MOVEMENTS_WRITE,
            Permission.INVENTORY_WRITE,
            Permission.IMPORT_RUN,
            Permission.IMPORT_OPERATIONS,
            Permission.AUDIT_READ,
        }
    ),
    # Operatore: ingressi e movimenti, nessuna modifica ad anagrafiche critiche.
    Role.OPERATORE: frozenset(
        {
            Permission.MASTERDATA_READ,
            Permission.STOCK_READ,
            Permission.MOVEMENTS_WRITE,
            Permission.IMPORT_OPERATIONS,
        }
    ),
    Role.VETERINARIO: frozenset({Permission.MASTERDATA_READ, Permission.STOCK_READ}),
    Role.AUDITOR: frozenset(
        {Permission.MASTERDATA_READ, Permission.STOCK_READ, Permission.AUDIT_READ}
    ),
}


def permissions_for(role: Role) -> frozenset[Permission]:
    return _ROLE_PERMISSIONS[role]


def has_permission(role: Role, permission: Permission) -> bool:
    return permission in _ROLE_PERMISSIONS[role]
