"""Risoluzione luogo → lotto di destinazione tramite occupazione (RF-05, SPEC §6.5)."""

from collections.abc import Hashable, Sequence
from datetime import date

from domain.periods import ranges_overlap


def resolve_occupancy(
    period_from: date,
    period_to: date,
    occupancies: Sequence[tuple[Hashable, date, date | None]],
) -> tuple[Hashable | None, str | None]:
    """Restituisce (lotto, None) se UNA occupazione copre tutto il periodo, altrimenti
    (None, messaggio): luogo libero oppure periodo che copre più occupazioni solo in parte."""
    overlapping = [o for o in occupancies if ranges_overlap(period_from, period_to, o[1], o[2])]
    if not overlapping:
        return None, "Il luogo non è occupato nel periodo indicato"
    covering = [
        o for o in overlapping if o[1] <= period_from and (o[2] is None or o[2] >= period_to)
    ]
    if len(covering) == 1 and len(overlapping) == 1:
        return covering[0][0], None
    return None, "Il periodo copre più occupazioni o solo in parte: dividi lo scarico"
