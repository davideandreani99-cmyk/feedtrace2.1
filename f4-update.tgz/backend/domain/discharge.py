"""Periodo di competenza di uno scarico verso un lotto di destinazione (RF-05).

Il movimento di magazzino è datato alla registrazione (ADR D27); il periodo [da, a] a cui lo
scarico si riferisce è un dato dello scarico, usato da report, costi e tracciabilità.
"""

from datetime import date, datetime
from zoneinfo import ZoneInfo

ROME = ZoneInfo("Europe/Rome")


def validate_period(period_from: date | None, period_to: date) -> tuple[date, date]:
    """Scarico a data singola (da assente) o a periodo [da, a]."""
    start = period_from or period_to
    if start > period_to:
        raise ValueError("La data di inizio del periodo segue la data di fine")
    return start, period_to


def ensure_not_future(period_to: date, now: datetime) -> None:
    if period_to > now.astimezone(ROME).date():
        raise ValueError("La data dello scarico è nel futuro")
