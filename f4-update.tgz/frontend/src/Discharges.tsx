import { FormEvent, Fragment, useCallback, useEffect, useState } from "react";
import { api } from "./api";

type Row = Record<string, unknown>;
type Warning = { code: string; message: string };

const fmt = (value: unknown): string => {
  const n = Number(value);
  return Number.isFinite(n)
    ? n.toLocaleString("it-IT", { minimumFractionDigits: 0, maximumFractionDigits: 3 })
    : "";
};
const dec = (text: string): string => text.trim().replace(",", ".");
const errText = (e: unknown): string => (e instanceof Error ? e.message : "Errore");
const today = (): string => new Date().toISOString().slice(0, 10);

// ---------------------------------------------------------------- scarichi
export function DischargesPage({ perms }: { perms: string[] }) {
  const canWrite = perms.includes("movements:write");
  const canStorno = perms.includes("inventory:write");
  const [containers, setContainers] = useState<Row[]>([]);
  const [lots, setLots] = useState<Row[]>([]);
  const [locations, setLocations] = useState<Row[]>([]);
  const [rows, setRows] = useState<Row[]>([]);
  const [containerId, setContainerId] = useState("");
  const [by, setBy] = useState<"lot" | "location">("lot");
  const [target, setTarget] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState(today());
  const [quantity, setQuantity] = useState("");
  const [unit, setUnit] = useState("kg");
  const [notes, setNotes] = useState("");
  const [operationId, setOperationId] = useState(crypto.randomUUID());
  const [warnings, setWarnings] = useState<Warning[]>([]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [open, setOpen] = useState("");

  const load = useCallback(async () => {
    try {
      setContainers(await api<Row[]>("/stock/containers"));
      setLots(await api<Row[]>("/destination-lots?active=true"));
      setLocations(await api<Row[]>("/locations?active=true"));
      setRows(await api<Row[]>("/discharges?limit=40"));
    } catch (e) {
      setError(errText(e));
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setMessage("");
    const body: Record<string, unknown> = {
      operation_id: operationId,
      container_id: containerId,
      period_from: from || null,
      period_to: to,
      quantity: dec(quantity),
      unit,
      notes: notes || null,
    };
    if (by === "lot") body.destination_lot_id = target;
    else body.location_id = target;
    try {
      const out = await api<{ destination_code: string; warnings: Warning[] }>("/discharges", {
        method: "POST",
        body: JSON.stringify(body),
      });
      setWarnings(out.warnings);
      setMessage(`Scarico registrato verso ${out.destination_code}`);
      setQuantity("");
      setNotes("");
      setOperationId(crypto.randomUUID());
      await load();
    } catch (err) {
      setError(errText(err));
    }
  }

  async function storno(id: string) {
    const why = window.prompt("Motivazione dello storno (obbligatoria):");
    if (!why) return;
    try {
      await api(`/discharges/${id}/storno`, {
        method: "POST",
        body: JSON.stringify({ operation_id: crypto.randomUUID(), reason: why }),
      });
      await load();
    } catch (err) {
      setError(errText(err));
    }
  }

  return (
    <section>
      <h2>Scarichi verso i lotti di destinazione</h2>
      {error && <p className="error">{error}</p>}
      {message && <p className="ok">{message}</p>}
      {warnings.length > 0 && <ul className="warnings">{warnings.map((w, i) => <li key={i}>⚠ {w.message}</li>)}</ul>}
      {canWrite && (
        <form className="card grid" onSubmit={submit}>
          <label>Da contenitore
            <select value={containerId} required onChange={(e) => setContainerId(e.target.value)}>
              <option value="">Seleziona…</option>
              {containers.map((c) => <option key={String(c.container_id)} value={String(c.container_id)}>{String(c.code)} ({fmt(c.total)} kg)</option>)}
            </select>
          </label>
          <label>Destinazione
            <select value={by} onChange={(e) => { setBy(e.target.value as "lot" | "location"); setTarget(""); }}>
              <option value="lot">Lotto di destinazione</option>
              <option value="location">Luogo (valvola / sala)</option>
            </select>
          </label>
          <label>{by === "lot" ? "Lotto" : "Luogo"}
            <select value={target} required onChange={(e) => setTarget(e.target.value)}>
              <option value="">Seleziona…</option>
              {(by === "lot" ? lots : locations).map((x) => (
                <option key={String(x.id)} value={String(x.id)}>
                  {String(by === "lot" ? x.internal_code : x.name)}{by === "lot" && x.external_code ? ` (${String(x.external_code)})` : ""}
                </option>
              ))}
            </select>
          </label>
          <label>Dal (vuoto = data singola)<input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></label>
          <label>Al<input type="date" required value={to} onChange={(e) => setTo(e.target.value)} /></label>
          <label>Quantità<input inputMode="decimal" required value={quantity} onChange={(e) => setQuantity(e.target.value)} /></label>
          <label>Unità<select value={unit} onChange={(e) => setUnit(e.target.value)}><option>kg</option><option>t</option></select></label>
          <label>Note<input value={notes} onChange={(e) => setNotes(e.target.value)} /></label>
          <button type="submit">Registra scarico</button>
        </form>
      )}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Periodo</th><th>Da</th><th>Verso</th><th>kg</th><th>Origine</th><th>Stato</th><th /></tr></thead>
          <tbody>
            {rows.map((d) => (
              <Fragment key={String(d.id)}>
                <tr onClick={() => setOpen(open === d.id ? "" : String(d.id))}>
                  <td>{String(d.period_from) === String(d.period_to) ? String(d.period_to) : `${String(d.period_from)} → ${String(d.period_to)}`}</td>
                  <td>{String(d.container_code)}</td>
                  <td>{String(d.destination_code)}{d.external_code ? ` (${String(d.external_code)})` : ""}</td>
                  <td>{fmt(d.quantity)}</td>
                  <td>{String(d.source)}</td>
                  <td>{String(d.status)}{(d.warnings as unknown[]).length > 0 ? " ⚠" : ""}</td>
                  <td>{canStorno && d.status === "REGISTRATO" && <button className="secondary" onClick={(e) => { e.stopPropagation(); void storno(String(d.id)); }}>Storna</button>}</td>
                </tr>
                {open === d.id && (
                  <tr><td colSpan={7}>
                    {(d.allocations as Row[]).map((a, i) => (
                      <div key={i}>{String(a.kind) === "CERTO" ? "Da" : "Possibile"}: <strong>{String(a.lot_code)}</strong> {fmt(a.quantity)} kg</div>
                    ))}
                    {(d.warnings as Warning[]).map((w, i) => <div key={i} className="error">⚠ {w.message}</div>)}
                  </td></tr>
                )}
              </Fragment>
            ))}
            {rows.length === 0 && <tr><td colSpan={7}>Nessuno scarico.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------- lotti di destinazione
export function DestinationLotsPage({ perms }: { perms: string[] }) {
  const canWrite = perms.includes("masterdata:write");
  const [lots, setLots] = useState<Row[]>([]);
  const [selected, setSelected] = useState("");
  const [summary, setSummary] = useState<Row | null>(null);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try {
      setLots(await api<Row[]>("/destination-lots"));
      if (selected) setSummary(await api<Row>(`/destination-lots/${selected}/summary`));
    } catch (e) {
      setError(errText(e));
    }
  }, [selected]);
  useEffect(() => {
    void load();
  }, [load]);

  async function close(id: string) {
    try {
      await api(`/destination-lots/${id}/close`, { method: "POST" });
      await load();
    } catch (err) {
      setError(errText(err));
    }
  }
  async function reopen(id: string) {
    const why = window.prompt("Motivazione della riapertura (obbligatoria):");
    if (!why) return;
    try {
      await api(`/destination-lots/${id}/reopen`, { method: "POST", body: JSON.stringify({ reason: why }) });
      await load();
    } catch (err) {
      setError(errText(err));
    }
  }

  return (
    <section>
      <h2>Lotti di destinazione</h2>
      <p>I lotti si creano in Anagrafiche. Seleziona una riga per il riepilogo dei consumi.</p>
      {error && <p className="error">{error}</p>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Codice</th><th>Pig'UP</th><th>Fase</th><th>Capi</th><th>Stato</th><th /></tr></thead>
          <tbody>
            {lots.map((l) => (
              <tr key={String(l.id)} className={l.id === selected ? "selected" : ""} onClick={() => setSelected(String(l.id))}>
                <td>{String(l.internal_code)}</td><td>{String(l.external_code ?? "")}</td><td>{String(l.phase)}</td>
                <td>{String(l.head_count ?? "")}</td><td>{String(l.status)}</td>
                <td>
                  {canWrite && l.status === "APERTO" && <button className="secondary" onClick={(e) => { e.stopPropagation(); void close(String(l.id)); }}>Chiudi</button>}
                  {canWrite && l.status === "CHIUSO" && <button className="secondary" onClick={(e) => { e.stopPropagation(); void reopen(String(l.id)); }}>Riapri</button>}
                </td>
              </tr>
            ))}
            {lots.length === 0 && <tr><td colSpan={6}>Nessun lotto.</td></tr>}
          </tbody>
        </table>
      </div>
      {summary && (
        <div className="card">
          <h3>Riepilogo {String(summary.code)}</h3>
          <p>Scarichi: {String(summary.discharges_count)} · Totale: <strong>{fmt(summary.total_kg)} kg</strong></p>
          <h4>Per ricetta</h4>
          <ul>{(summary.by_recipe as Row[]).map((r, i) => <li key={i}>{String(r.description)}: {fmt(r.kg)} kg</li>)}</ul>
          <h4>Per fase</h4>
          <ul>{(summary.by_phase as Row[]).map((p, i) => <li key={i}>{String(p.phase)}: {fmt(p.kg)} kg</li>)}</ul>
          <h4>Per mese</h4>
          <ul>{(summary.by_month as Row[]).map((m, i) => <li key={i}>{String(m.month)}: {fmt(m.kg)} kg</li>)}</ul>
          <h4>Lotti miscela coinvolti</h4>
          <ul>{(summary.mix_lots as Row[]).map((m, i) => <li key={i}>{String(m.lot_code)}: {fmt(m.kg)} kg</li>)}</ul>
          <h4>Lotti di materia prima a monte</h4>
          <ul>{(summary.material_lots as Row[]).map((m, i) => <li key={i}>{String(m.lot_code)}</li>)}</ul>
          <p><small>Costo e medicati: disponibili nella fase dedicata.</small></p>
        </div>
      )}
    </section>
  );
}
