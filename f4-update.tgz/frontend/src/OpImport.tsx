import { FormEvent, useCallback, useEffect, useState } from "react";
import { api, download } from "./api";

type Row = Record<string, unknown>;

interface FieldDef {
  name: string;
  label: string;
  required?: boolean;
}

// Campi canonici per tipo di dato (mirror di domain/importing.py)
const FIELDS: Record<string, { title: string; fields: FieldDef[] }> = {
  discharges: {
    title: "Scarichi",
    fields: [
      { name: "date", label: "Data (o data fine)", required: true },
      { name: "date_from", label: "Data inizio periodo" },
      { name: "container", label: "Contenitore / silo", required: true },
      { name: "quantity", label: "Quantità", required: true },
      { name: "destination_lot", label: "Lotto di destinazione (codice o Pig'UP)" },
      { name: "location", label: "Luogo (valvola / sala)" },
      { name: "unit", label: "Unità (kg/t)" },
      { name: "notes", label: "Note / ciclo" },
      { name: "site", label: "Sito" },
    ],
  },
  receipts: {
    title: "Ingressi",
    fields: [
      { name: "date", label: "Data DDT", required: true },
      { name: "material", label: "Materia prima", required: true },
      { name: "quantity", label: "Quantità", required: true },
      { name: "container", label: "Contenitore", required: true },
      { name: "supplier", label: "Fornitore (nome o P.IVA)" },
      { name: "ddt_number", label: "N. DDT" },
      { name: "plate", label: "Targa" },
      { name: "supplier_lot", label: "Lotto fornitore" },
      { name: "price_eur_t", label: "Prezzo €/t" },
      { name: "unit", label: "Unità (kg/t/l)" },
      { name: "self_produced", label: "Autoprodotta (sì/no)" },
      { name: "site", label: "Sito" },
    ],
  },
  productions: {
    title: "Produzioni",
    fields: [
      { name: "datetime", label: "Data e ora (o solo data)", required: true },
      { name: "plant", label: "Impianto", required: true },
      { name: "recipe", label: "Ricetta", required: true },
      { name: "quantity", label: "Quantità", required: true },
      { name: "unit", label: "Unità (kg/t)" },
      { name: "destination_container", label: "Contenitore di destinazione" },
      { name: "notes", label: "Note / ciclo" },
      { name: "site", label: "Sito" },
    ],
  },
  inventories: {
    title: "Inventari",
    fields: [
      { name: "date", label: "Data", required: true },
      { name: "container", label: "Contenitore", required: true },
      { name: "measured_quantity", label: "Giacenza misurata", required: true },
      { name: "unit", label: "Unità (kg/t)" },
      { name: "reason", label: "Motivazione" },
      { name: "site", label: "Sito" },
    ],
  },
};

const errText = (e: unknown): string => (e instanceof Error ? e.message : "Errore");

function parsePairs(text: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const line of text.split("\n")) {
    const i = line.indexOf("=");
    if (i > 0) out[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  }
  return out;
}

/** "campo: esterno=interno" una per riga. */
function parseCodeMaps(text: string): Record<string, Record<string, string>> {
  const out: Record<string, Record<string, string>> = {};
  for (const line of text.split("\n")) {
    const m = line.match(/^\s*([a-z_]+)\s*:\s*(.+?)\s*=\s*(.+?)\s*$/);
    if (m) (out[m[1]] ??= {})[m[2]] = m[3];
  }
  return out;
}

function MappingEditor({ entity, onSaved }: { entity: string; onSaved: () => void }) {
  const [name, setName] = useState("");
  const [columns, setColumns] = useState<Record<string, string>>({});
  const [dateFormat, setDateFormat] = useState("");
  const [separator, setSeparator] = useState("auto");
  const [unit, setUnit] = useState("kg");
  const [defaults, setDefaults] = useState("");
  const [codeMaps, setCodeMaps] = useState("");
  const [key, setKey] = useState("");
  const [error, setError] = useState("");

  async function save(e: FormEvent) {
    e.preventDefault();
    setError("");
    const cleaned = Object.fromEntries(Object.entries(columns).filter(([, v]) => v.trim() !== ""));
    try {
      await api("/import-mappings", {
        method: "POST",
        body: JSON.stringify({
          name,
          entity,
          config: {
            columns: cleaned,
            date_format: dateFormat || null,
            decimal_separator: separator,
            default_unit: unit,
            defaults: parsePairs(defaults),
            code_maps: parseCodeMaps(codeMaps),
            natural_key: key.split(",").map((k) => k.trim()).filter(Boolean),
          },
        }),
      });
      setName("");
      onSaved();
    } catch (err) {
      setError(errText(err));
    }
  }

  return (
    <form className="card" onSubmit={save}>
      <h3>Nuova mappatura per {FIELDS[entity].title.toLowerCase()}</h3>
      {error && <p className="error">{error}</p>}
      <label>Nome del formato (es. "Export broda impianto X")
        <input required value={name} onChange={(e) => setName(e.target.value)} />
      </label>
      <p>Scrivi il nome della colonna del file per ogni dato (* = obbligatorio, basta uno tra le alternative).</p>
      <div className="grid">
        {FIELDS[entity].fields.map((f) => (
          <label key={f.name}>{f.label}{f.required ? " *" : ""}
            <input value={columns[f.name] ?? ""} onChange={(e) => setColumns({ ...columns, [f.name]: e.target.value })} />
          </label>
        ))}
      </div>
      <div className="grid">
        <label>Formato data (vuoto = automatico, es. %d/%m/%Y)<input value={dateFormat} onChange={(e) => setDateFormat(e.target.value)} /></label>
        <label>Separatore decimale
          <select value={separator} onChange={(e) => setSeparator(e.target.value)}>
            <option value="auto">automatico</option><option value=",">virgola</option><option value=".">punto</option>
          </select>
        </label>
        <label>Unità predefinita
          <select value={unit} onChange={(e) => setUnit(e.target.value)}><option>kg</option><option>t</option><option>l</option></select>
        </label>
        <label>Campi che identificano la riga (es. date, location, notes)
          <input value={key} onChange={(e) => setKey(e.target.value)} />
        </label>
      </div>
      <label>Valori fissi (uno per riga, es. site=Allevamento Demo 1)
        <textarea rows={2} value={defaults} onChange={(e) => setDefaults(e.target.value)} />
      </label>
      <label>Corrispondenza codici (uno per riga: campo: codice esterno = codice interno, es. location: V12 = Sala 3)
        <textarea rows={3} value={codeMaps} onChange={(e) => setCodeMaps(e.target.value)} />
      </label>
      <div className="row"><button type="submit">Salva mappatura</button></div>
    </form>
  );
}

export function OpImportPage() {
  const [entity, setEntity] = useState("discharges");
  const [mappings, setMappings] = useState<Row[]>([]);
  const [mappingId, setMappingId] = useState("");
  const [showEditor, setShowEditor] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [current, setCurrent] = useState<Row | null>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const [filter, setFilter] = useState("");
  const [history, setHistory] = useState<Row[]>([]);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const load = useCallback(async () => {
    try {
      setMappings(await api<Row[]>(`/import-mappings?entity=${entity}`));
      setHistory(await api<Row[]>("/op-imports?limit=15"));
    } catch (e) {
      setError(errText(e));
    }
  }, [entity]);
  useEffect(() => {
    void load();
  }, [load]);

  const loadRows = useCallback(async (id: string, status: string) => {
    setRows(await api<Row[]>(`/op-imports/${id}/rows?limit=500${status ? `&status=${status}` : ""}`));
  }, []);

  async function preview() {
    if (!file || !mappingId) return;
    setError("");
    setMessage("");
    const data = new FormData();
    data.append("entity", entity);
    data.append("mapping_id", mappingId);
    data.append("file", file);
    try {
      const out = await api<Row>("/op-imports", { method: "POST", body: data });
      setCurrent(out);
      setFilter("");
      await loadRows(String(out.id), "");
      await load();
    } catch (err) {
      setCurrent(null);
      setRows([]);
      setError(errText(err));
    }
  }

  async function confirm(strict: boolean) {
    if (!current) return;
    setError("");
    try {
      const out = await api<Row>(`/op-imports/${String(current.id)}/confirm?strict=${strict}`, { method: "POST" });
      setCurrent(out);
      setMessage(`Import applicato: ${String(out.applied_count)} righe registrate, ${String(out.failed_count)} fallite.`);
      await loadRows(String(out.id), filter);
      await load();
    } catch (err) {
      setError(errText(err));
    }
  }

  async function discard() {
    if (!current) return;
    try {
      await api(`/op-imports/${String(current.id)}`, { method: "DELETE" });
      setCurrent(null);
      setRows([]);
      await load();
    } catch (err) {
      setError(errText(err));
    }
  }

  return (
    <section>
      <h2>Importa operazioni da file</h2>
      {error && <p className="error">{error}</p>}
      {message && <p className="ok">{message}</p>}
      <div className="card grid">
        <label>Cosa importare
          <select value={entity} onChange={(e) => { setEntity(e.target.value); setMappingId(""); setCurrent(null); setRows([]); }}>
            {Object.entries(FIELDS).map(([k, v]) => <option key={k} value={k}>{v.title}</option>)}
          </select>
        </label>
        <label>Formato (mappatura)
          <select value={mappingId} onChange={(e) => setMappingId(e.target.value)}>
            <option value="">Seleziona…</option>
            {mappings.map((m) => <option key={String(m.id)} value={String(m.id)}>{String(m.name)}</option>)}
          </select>
        </label>
        <label>File (CSV o Excel)
          <input type="file" accept=".csv,.xlsx" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
        </label>
        <button onClick={() => void preview()} disabled={!file || !mappingId}>Anteprima</button>
        <button className="secondary" onClick={() => setShowEditor(!showEditor)}>{showEditor ? "Chiudi editor" : "Nuova mappatura"}</button>
      </div>
      {showEditor && <MappingEditor entity={entity} onSaved={() => { setShowEditor(false); void load(); }} />}

      {current && (
        <div className="card">
          <h3>{String(current.filename)} — {String(current.status)}</h3>
          <p>
            Righe: {String(current.total)} · valide: {String(current.ok_count)} · errori: {String(current.error_count)} ·
            duplicate: {String(current.duplicate_count)} · registrate: {String(current.applied_count)} · fallite: {String(current.failed_count)}
          </p>
          <div className="row">
            {current.status === "PREVIEW" && (
              <>
                <button onClick={() => void confirm(false)} disabled={Number(current.ok_count) === 0}>Conferma (righe valide)</button>
                <button className="secondary" onClick={() => void confirm(true)} disabled={Number(current.ok_count) === 0}>Conferma tutto o niente</button>
                <button className="secondary" onClick={() => void discard()}>Scarta</button>
              </>
            )}
            <button className="secondary" onClick={() => void download(`/op-imports/${String(current.id)}/report`, "riepilogo.csv")}>Scarica riepilogo</button>
            <button className="secondary" onClick={() => void download(`/op-imports/${String(current.id)}/download`, String(current.filename))}>Scarica file originale</button>
            <select value={filter} onChange={(e) => { setFilter(e.target.value); void loadRows(String(current.id), e.target.value); }}>
              <option value="">Tutte le righe</option>
              {["OK", "ERROR", "DUPLICATE", "APPLIED", "FAILED"].map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Riga</th><th>Stato</th><th>Messaggio</th><th>Dati letti</th></tr></thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={String(r.id)}>
                    <td>{String(r.line)}</td><td>{String(r.status)}</td><td>{String(r.message ?? "")}</td>
                    <td><code>{JSON.stringify(r.raw).slice(0, 110)}</code></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <h3>Ultimi import</h3>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Data</th><th>Tipo</th><th>File</th><th>Stato</th><th>Registrate</th></tr></thead>
          <tbody>
            {history.map((h) => (
              <tr key={String(h.id)}>
                <td>{String(h.created_at).slice(0, 16).replace("T", " ")}</td>
                <td>{FIELDS[String(h.entity)]?.title ?? String(h.entity)}</td>
                <td>{String(h.filename)}</td><td>{String(h.status)}</td><td>{String(h.applied_count)}/{String(h.total)}</td>
              </tr>
            ))}
            {history.length === 0 && <tr><td colSpan={5}>Nessun import.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}
