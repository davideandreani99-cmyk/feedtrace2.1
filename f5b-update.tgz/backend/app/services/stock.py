"""Giacenze per lotto derivate dal registro movimenti (ADR D18).

Nessuna tabella di saldi: composizione, giacenza corrente e a data passata sono somme dei
movimenti (RF-03). Le operazioni che modificano un contenitore ne bloccano la riga
(SELECT ... FOR UPDATE) per serializzare gli scarichi concorrenti.
"""

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import case, func, or_, select
from sqlalchemy.orm import Session

from app.deps import Ctx
from app.models import Container, Lot, Movement
from domain.consumption import Allocation, LotStock, consume
from domain.enums import ConsumptionPolicy, LotKind, MovementType
from domain.permissions import Permission, has_permission

BACKDATE_DAYS = 7  # D8
FUTURE_TOLERANCE = timedelta(minutes=5)
_MAX_DT = datetime.max.replace(tzinfo=UTC)
_MAX_SEQ = 2**62


@dataclass
class StockRow:
    lot_id: uuid.UUID
    quantity: Decimal
    entered: Decimal  # kg entrati dall'ultimo svuotamento
    first_key: tuple[datetime, int]  # ordine di carico nel contenitore (FIFO, D3)


def load_stock(
    db: Session, tenant_id: uuid.UUID, container_id: uuid.UUID, at: datetime | None = None
) -> list[StockRow]:
    """Composizione per lotto: somma dei movimenti fino a `at` (o ad oggi)."""
    conditions = [Movement.tenant_id == tenant_id, Movement.container_id == container_id]
    if at is not None:
        conditions.append(Movement.occurred_at <= at)
    epoch_seq = db.scalar(
        select(func.coalesce(func.max(Movement.seq), 0)).where(
            *conditions, Movement.closes_epoch.is_(True)
        )
    )
    positive = Movement.quantity > 0
    entered = func.coalesce(
        func.sum(case((positive & (Movement.seq > epoch_seq), Movement.quantity), else_=0)), 0
    )
    total = func.sum(Movement.quantity)
    stmt = (
        select(
            Movement.lot_id,
            total.label("qty"),
            func.min(case((positive, Movement.occurred_at))).label("first_at"),
            func.min(case((positive, Movement.seq))).label("first_seq"),
            entered.label("entered"),
        )
        .where(*conditions)
        .group_by(Movement.lot_id)
        .having(or_(total != 0, entered > 0))
    )
    return [
        StockRow(
            lot_id=r.lot_id,
            quantity=Decimal(r.qty),
            entered=Decimal(r.entered),
            first_key=(r.first_at or _MAX_DT, r.first_seq if r.first_seq is not None else _MAX_SEQ),
        )
        for r in db.execute(stmt)
    ]


def balances(ctx: Ctx) -> list[tuple[uuid.UUID, uuid.UUID, Decimal]]:
    """Giacenza per (contenitore, lotto) con quantità diversa da zero: una sola scansione dei
    movimenti, riusata da elenco contenitori, anomalie e cruscotto."""
    rows = ctx.db.execute(
        select(Movement.container_id, Movement.lot_id, func.sum(Movement.quantity))
        .where(Movement.tenant_id == ctx.tenant_id)
        .group_by(Movement.container_id, Movement.lot_id)
        .having(func.sum(Movement.quantity) != 0)
    )
    return [(container_id, lot_id, quantity) for container_id, lot_id, quantity in rows]


def to_domain(rows: list[StockRow]) -> list[LotStock]:
    ordered = sorted(rows, key=lambda r: r.first_key)
    return [LotStock(r.lot_id, r.quantity, i, r.entered) for i, r in enumerate(ordered)]


def total_of(rows: list[StockRow]) -> Decimal:
    return sum((r.quantity for r in rows), Decimal("0"))


def lock_containers(ctx: Ctx, ids: list[uuid.UUID]) -> dict[uuid.UUID, Container]:
    unique = sorted(set(ids))
    rows = ctx.db.scalars(
        select(Container)
        .where(Container.id.in_(unique), Container.tenant_id == ctx.tenant_id)
        .order_by(Container.id)
        .with_for_update()
    ).all()
    found = {c.id: c for c in rows}
    for container_id in unique:
        container = found.get(container_id)
        if container is None:
            raise HTTPException(status_code=422, detail="Contenitore non trovato")
        if not container.active:
            raise HTTPException(status_code=409, detail=f"Contenitore {container.code} disattivato")
    return found


def resolve_occurred_at(
    ctx: Ctx, occurred_at: datetime | None, container_ids: list[uuid.UUID]
) -> datetime:
    """Data/ora del movimento. Regole D8 + D18: nessun movimento successivo sul contenitore."""
    now = datetime.now(UTC)
    if occurred_at is None:
        return now
    if occurred_at.tzinfo is None:
        occurred_at = occurred_at.replace(tzinfo=UTC)
    if occurred_at > now + FUTURE_TOLERANCE:
        raise HTTPException(status_code=422, detail="La data del movimento è nel futuro")
    if occurred_at < now - timedelta(days=BACKDATE_DAYS) and not has_permission(
        ctx.role, Permission.INVENTORY_WRITE
    ):
        raise HTTPException(
            status_code=403,
            detail=f"Oltre {BACKDATE_DAYS} giorni indietro può registrare solo il Responsabile",
        )
    later = ctx.db.scalar(
        select(func.count())
        .select_from(Movement)
        .where(
            Movement.tenant_id == ctx.tenant_id,
            Movement.container_id.in_(container_ids),
            Movement.occurred_at > occurred_at,
        )
    )
    if later:
        raise HTTPException(
            status_code=409,
            detail="Esistono movimenti successivi su questo contenitore: "
            "per correggere usa uno storno",
        )
    return occurred_at


def get_na_lot(ctx: Ctx, container: Container) -> Lot:
    """Lotto sintetico NON ALLOCATO del contenitore (D7)."""
    code = f"NA-{container.code}"
    lot = ctx.db.scalar(
        select(Lot).where(
            Lot.tenant_id == ctx.tenant_id,
            Lot.site_id == container.site_id,
            Lot.internal_code == code,
            Lot.kind == LotKind.NON_ALLOCATO.value,
        )
    )
    if lot is None:
        lot = Lot(
            tenant_id=ctx.tenant_id,
            kind=LotKind.NON_ALLOCATO.value,
            site_id=container.site_id,
            internal_code=code,
            status="DISPONIBILE",
        )
        ctx.db.add(lot)
        ctx.db.flush()
    return lot


def add_movement(
    ctx: Ctx,
    *,
    container: Container,
    lot_id: uuid.UUID,
    quantity: Decimal,
    mtype: MovementType,
    occurred_at: datetime,
    operation_id: uuid.UUID,
    doc_type: str | None = None,
    doc_id: uuid.UUID | None = None,
    reason: str | None = None,
    closes_epoch: bool = False,
    reverses: uuid.UUID | None = None,
) -> Movement:
    movement = Movement(
        tenant_id=ctx.tenant_id,
        site_id=container.site_id,
        occurred_at=occurred_at,
        type=mtype.value,
        container_id=container.id,
        lot_id=lot_id,
        quantity=quantity,
        operation_id=operation_id,
        doc_type=doc_type,
        doc_id=doc_id,
        reason=reason,
        closes_epoch=closes_epoch,
        reverses_movement_id=reverses,
        user_id=ctx.user.id,
    )
    ctx.db.add(movement)
    return movement


@dataclass
class ConsumeOutcome:
    allocations: list[Allocation]
    shortfall: Decimal
    movements: list[Movement]
    total_before: Decimal
    possible_links: list[Allocation]


def consume_from_container(
    ctx: Ctx,
    container: Container,
    quantity: Decimal,
    mtype: MovementType,
    occurred_at: datetime,
    operation_id: uuid.UUID,
    *,
    doc_type: str | None = None,
    doc_id: uuid.UUID | None = None,
    reason: str | None = None,
) -> ConsumeOutcome:
    """Preleva secondo la politica del contenitore; l'eccedenza va sul lotto NON ALLOCATO."""
    rows = load_stock(ctx.db, ctx.tenant_id, container.id)
    result = consume(ConsumptionPolicy(container.consumption_policy), to_domain(rows), quantity)
    movements = [
        add_movement(
            ctx,
            container=container,
            lot_id=a.lot_id,
            quantity=-a.quantity,
            mtype=mtype,
            occurred_at=occurred_at,
            operation_id=operation_id,
            doc_type=doc_type,
            doc_id=doc_id,
            reason=reason,
        )
        for a in result.allocations
    ]
    if result.shortfall > 0:
        na = get_na_lot(ctx, container)
        movements.append(
            add_movement(
                ctx,
                container=container,
                lot_id=na.id,
                quantity=-result.shortfall,
                mtype=mtype,
                occurred_at=occurred_at,
                operation_id=operation_id,
                doc_type=doc_type,
                doc_id=doc_id,
                reason=reason,
            )
        )
    return ConsumeOutcome(
        list(result.allocations), result.shortfall, movements, total_of(rows),
        list(result.possible_links),
    )


def negative_warning(container: Container, total_after: Decimal, shortfall: Decimal) -> dict | None:
    """Giacenza negativa: consentita con avviso (RF-03, D7), mai bloccante."""
    if shortfall <= 0 and total_after >= 0:
        return None
    beyond = total_after < -container.negative_threshold_kg
    detail = "oltre la soglia consentita" if beyond else "entro la soglia"
    return {
        "code": "NEGATIVE_STOCK",
        "message": f"Giacenza negativa in {container.code} ({total_after} kg, {detail}): "
        "quantità non allocata a un lotto",
    }
